<?php
session_start();
include('../server/connection.php');

$period = $_GET['period'] ?? 'month';
$date = $_GET['date'] ?? date('Y-m-d');

$where = "";
if ($period == 'day') {
    $where = "DATE(created_at) = '" . $conn->real_escape_string($date) . "'";
} elseif ($period == 'week') {
    $week_start = date('Y-m-d', strtotime('monday this week', strtotime($date)));
    $week_end = date('Y-m-d', strtotime('sunday this week', strtotime($date)));
    $where = "DATE(created_at) BETWEEN '$week_start' AND '$week_end'";
} else { // month
    $month = date('m', strtotime($date));
    $year = date('Y', strtotime($date));
    $where = "MONTH(created_at) = '$month' AND YEAR(created_at) = '$year'";
}

// New users in period
$new_users = $conn->query("SELECT COUNT(*) as count FROM users WHERE $where")->fetch_assoc()['count'] ?? 0;

// Active users (placed orders in period)
$active_users = $conn->query("SELECT COUNT(DISTINCT user_id) as count FROM orders WHERE $where")->fetch_assoc()['count'] ?? 0;

// Most active users (by order count in period)
$most_active = $conn->query("SELECT users.user_name, COUNT(*) as orders FROM users JOIN orders ON users.user_id = orders.user_id WHERE " . str_replace('created_at', 'orders.created_at', $where) . " GROUP BY users.user_id ORDER BY orders DESC LIMIT 3");

?>
<p><strong>New Users:</strong> <?php echo $new_users; ?></p>
<p><strong>Active Users:</strong> <?php echo $active_users; ?></p>
<h6>Most Active Users:</h6>
<ul>
    <?php while($row = $most_active->fetch_assoc()): ?>
        <li><?php echo htmlspecialchars($row['user_name']); ?> (<?php echo $row['orders']; ?> orders)</li>
    <?php endwhile; ?>
</ul>