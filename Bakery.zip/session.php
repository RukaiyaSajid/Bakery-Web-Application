<?php
/**
 * Session management functions for Bakery Delivery Service
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    // Set secure session parameters
    ini_set('session.use_only_cookies', 1);
    ini_set('session.use_strict_mode', 1);
    
    // Set session cookie parameters for better security
    $cookieParams = session_get_cookie_params();
    session_set_cookie_params([
        'lifetime' => $cookieParams['lifetime'],
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'] ?? '',
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    
    session_start();
    
    // Set session to expire after 30 minutes of inactivity
    if (!isset($_SESSION['last_activity'])) {
        $_SESSION['last_activity'] = time();
    } elseif (time() - $_SESSION['last_activity'] > 1800) {
        // Session expired, destroy it
        session_unset();
        session_destroy();
        
        // Restart session
        session_start();
        
        // Set redirect flag
        $_SESSION['session_expired'] = true;
    }
    
    // Update last activity time stamp
    $_SESSION['last_activity'] = time();
    
    // Regenerate session ID periodically to prevent session fixation
    if (!isset($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } else if (time() - $_SESSION['created'] > 1800) {
        // Regenerate session ID every 30 minutes
        session_regenerate_id(true);
        $_SESSION['created'] = time();
    }
}

/**
 * Check if user is logged in
 * 
 * @return bool True if logged in, false otherwise
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if user is admin
 * 
 * @return bool True if admin, false otherwise
 */
function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Require user to be logged in, redirect to login if not
 */
function requireLogin() {
    if (!isLoggedIn()) {
        // Store current URL for redirect after login
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header("Location: login.php");
        exit;
    }
}

/**
 * Require user to be admin, redirect to access denied if not
 */
function requireAdmin() {
    if (!isLoggedIn()) {
        // Store current URL for redirect after login
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header("Location: ../login.php");
        exit;
    } elseif (!isAdmin()) {
        // User is logged in but not admin
        header("Location: ../access_denied.php");
        exit;
    }
}

// Check for "remember me" cookie login
if (!isLoggedIn() && isset($_COOKIE['remember_user']) && isset($_COOKIE['remember_token'])) {
    $userId = $_COOKIE['remember_user'];
    $token = $_COOKIE['remember_token'];
    
    // Include database connection if not already included
    if (!isset($conn)) {
        require_once __DIR__ . '/../includes/config.php';
    }
    
    // Verify the remember token
    $sql = "SELECT u.user_id, u.user_name, u.email 
            FROM users u 
            JOIN remember_tokens rt ON u.user_id = rt.user_id 
            WHERE u.user_id = ? AND rt.token = ? AND rt.expires_at > NOW()";
    
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("is", $userId, $token);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['user_name'];
            $_SESSION['email'] = $user['email'];
            
            // Refresh token
            $newToken = bin2hex(random_bytes(32));
            
            // Update token in database
            $updateSql = "UPDATE remember_tokens SET token = ?, expires_at = DATE_ADD(NOW(), INTERVAL 30 DAY) WHERE user_id = ? AND token = ?";
            $updateStmt = $conn->prepare($updateSql);
            if ($updateStmt) {
                $updateStmt->bind_param("sis", $newToken, $userId, $token);
                $updateStmt->execute();
                
                // Update cookie
                setcookie("remember_token", $newToken, time() + (30 * 24 * 60 * 60), "/");
            }
        } else {
            // Invalid remember token, clear cookies
            setcookie("remember_user", "", time() - 3600, "/");
            setcookie("remember_token", "", time() - 3600, "/");
        }
    }
}
?>