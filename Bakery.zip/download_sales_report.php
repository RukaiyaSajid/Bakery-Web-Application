<?php
session_start();
include('../server/connection.php');

$period = $_GET['period'] ?? 'month';
$date = $_GET['date'] ?? date('Y-m-d');

$where = "";
if ($period == 'day') {
    $where = "DATE(created_at) = '" . $conn->real_escape_string($date) . "'";
} elseif ($period == 'week') {
    $week_start = date('Y-m-d', strtotime('monday this week', strtotime($date)));
    $week_end = date('Y-m-d', strtotime('sunday this week', strtotime($date)));
    $where = "DATE(created_at) BETWEEN '$week_start' AND '$week_end'";
} else { // month
    $month = date('m', strtotime($date));
    $year = date('Y', strtotime($date));
    $where = "MONTH(created_at) = '$month' AND YEAR(created_at) = '$year'";
}

$query = "SELECT order_id, user_id, total_amount, status, created_at FROM orders WHERE status='Completed' AND $where ORDER BY created_at DESC";
$result = $conn->query($query);

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=sales_report.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['Order ID', 'User ID', 'Total Amount', 'Status', 'Created At']);

while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}
fclose($output);
exit;