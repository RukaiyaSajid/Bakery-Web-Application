<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bakery Web App</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>

</style>  
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.html"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li class="active-nav"><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.html">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>


  <div class="banner">
    <img src="img/chocolate-cake-with-dried-fruit.jpg" alt="Banner" />
    <div class="overlay">
      <h1>Welcome to The Butterhedge</h1>
      <p>We offer a great range of different flavored bite-size Savories and cakes.</p>
      <button><a href="Products- cakes.php">Order Now</a> </button>
    </div>
  </div>

  <div class="featured-products">
    <h2>Featured Products</h2>
    <h3>Cake</h3>
    <div class="product-grid" id="featured-cakes">
      <?php include('server/get_products_cake.php') ?>

      <?php while($row = $featured_products->fetch_assoc()){ ?>
  <div class="product-item" onclick="window.location.href='cake.php?products_id=<?php echo $row['products_id'];?>'" >
  <img src="img/<?php echo $row['products_image'];?>" alt="<?php echo $row ['products_name'] ?>">
  <p class="Name"><?php echo $row ['products_name'] ?></p>
  </div>
  <?php } ?>
  </div>
    

    <h3>Savory</h3>
    <div class="product-grid" id="featured-savories">
    <?php include('server/get_products_savory.php') ?>

<?php while($row = $featured_products->fetch_assoc()){ ?>
<div class="product-item" onclick="window.location.href='savory.php?products_id=<?php echo $row['products_id'];?>'">
<img src="img/<?php echo $row['products_image'];?>" alt="<?php echo $row ['products_name'] ?>">
<p class="Name"><?php echo $row ['products_name'] ?></p>
</div>
<?php } ?>
  </div>
  
        <!-- Footer -->
        <footer>
          <div class="footer-links">
            <a href="refund.html">Refund Policy</a>
            <a href="term.html">Terms & Conditions</a>
            <a href="privacy.html">Privacy Policy</a>
          </div>
          <div class="footer-social">
            <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
          </div>
          <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
        </footer>

<?php include 'chatbot.php'; ?>
  <script src="js.js"></script>
  <script>
 </script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>


