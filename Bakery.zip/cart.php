<?php
session_start();

// Check if Giftbox exists in localStorage (sent via POST from JS)
if (isset($_POST['add_giftbox_to_cart'])) {
    $giftPack = json_decode($_POST['giftPack'], true);
    if ($giftPack) {
        $product_id = 'giftbox_' . time(); // Unique ID for the giftbox
        $_SESSION['cart'][$product_id] = array(
            'products_id' => $product_id,
            'products_image' => 'giftbox.jpg', // Use a default image or first item's image
            'products_name' => 'Giftbox',
            'products_price' => $giftPack['price'],
            'product_quantity' => $giftPack['quantity'],
            'card_number' => $giftPack['cardNumber'],
            'greeting_message' => $giftPack['greetingMessage'],
            'delivery_date' => $giftPack['deliveryDate']
        );
    }
}

if(isset($_POST['add_to_cart'])){

  
  //if user has alredy add to cart
  if(isset($_SESSION['cart'])){

    
    $product_array_ids = array_column($_SESSION['cart'], "products_id");

    //if product has alredy being added to the cart or not
    if( !in_array($_POST['products_id'], $product_array_ids)){

          $product_id = $_POST['products_id'] ?? null;
          $product_image = $_POST['products_image']; 
          $product_name = $_POST['products_name'] ?? 'Unknown';
          $product_price = $_POST['products_price'] ?? 0;
          $product_quantity = $_POST['product_quantity'] ?? 1;


          $product_array = array(
            'products_id' => $product_id,
            'products_image' => $product_image,
            'products_name' => $product_name,
            'products_price' => $product_price,
            'product_quantity' => $product_quantity
    ); 

    $_SESSION['cart'][$product_id] = $product_array;


    }
//if the prouct has already being added
    else{

      echo '<script>alert("Product has already added to cart.");</script>';

    }


  }

  //if user is adding  for the first time to the cart
  else{
      $product_id = $_POST['products_id'];
      $product_image = $_POST['products_image'];
      $product_name = $_POST['products_name'];
      $product_price = $_POST['products_price'];
      $product_quantity = $_POST['product_quantity'];

      $product_array = array(
              'products_id' => $product_id,
              'products_image' => $product_image,
              'products_name' => $product_name,
              'products_price' => $product_price,
              'product_quantity' => $product_quantity
      ); 

      $_SESSION['cart'][$product_id] = $product_array;

  }
//remove products from the cart
}else if(isset($_POST['remove_product'])){

  $product_id = $_POST['products_id'];
  unset($_SESSION['cart'][$product_id]);




}else{
 }

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cart</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
<style>
    body {
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      font-size: medium;
    }

 
    .icons {
      position: relative;
      margin-right: 20px;
    }

    /* Cart Icon Counter */
    .cart-icon {
      position: relative;
    }

    

    /* Cart Container */
    .cart-container {
      flex-grow: 1;
      width: 80%;
      margin: auto;
      padding: 20px;
      margin-top: 100px;
    }

    /* Cart Table */
    .cart-title {
      color: #96783A;
      padding: 10px;
      font-size: 24px;
      font-weight: bold;
      width: 200px;
      text-align: center;
      border-radius: 5px 5px 0 0;
    }

    .cart-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
      border: 1px solid #ccc;
    }

    .cart-table th, .cart-table td {
      padding: 10px;
      text-align: center;
      vertical-align: middle;
    }

    .product-info {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 20px;
}

.product-info img {
  width: 70px;
  height: 70px;
  object-fit: cover;
  border: 1px solid #ccc;
  margin-right: 5px;
}

    

    input[type="number"], select {
      padding: 10px;
      margin: 5px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
      width: 20%;

    }
    

    /* Cart Summary Before Footer */
    .cart-summary {
      margin-top: 20px;
      padding: 15px;
      border: 1px solid #ccc;
      width: 300px;
      background-color: #f9f9f9;
      float: right;
    }

    /* Summary Price */
    .cart-summary p {
      display: flex;
      justify-content: space-between;
      margin: 10px 0;
    }

    /* Buttons */
    .cart-summary .checkout-btn,
    .cart-summary .continue-btn {
      width: 100%;
      padding: 10px;
      border: none;
      background-color: #BA954D;
      color: white;
      cursor: pointer;
      font-size: 16px;
      margin-top: 10px;
    }

    .cart-summary .checkout-btn:hover,
    .cart-summary .continue-btn:hover {
      background-color: #96783A;
    }

    .remove-btn {
      color: #BA954D;
      background-color : white;
      border: none;
      padding: 5px 10px;
      cursor: pointer;
      border-radius: 5px;
    }
    .remove-btn:hover {
      background-color: #96783A;
      color: white;
    }

    /* Footer */
    .footer {
      background-color: #76703F;
      color: white;
      padding: 20px;
      text-align: center;
      width: 100%;
      margin-top: auto;
    }

    

  </style>
</head>
<body>

<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.php">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
  <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>


  <!-- Shopping Cart -->
  <div class="cart-container" id="cart-container">
    <div class="cart-title">Shopping Cart</div>
    <table class="cart-table">
      <thead>
        <tr>
          <th>Product</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Total</th>
          <th>Action</th>
        </tr>
      </thead>



      <tbody id="cart-items">
      <?php
          if(isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
              foreach($_SESSION['cart'] as $key => $value) {
          ?>
                <tr>
                  <td class="product-info">
                    <img src="img/<?php echo $value['products_image'];  ?>" alt="<?php echo $value['products_name'];  ?>">
                    <span><?php echo $value['products_name'];  ?></span>
                    <?php if(!empty($value['kilogram']) || !empty($value['customize_message'])): ?>
                      <div style="font-size:0.92em; color:#83666e; margin-top:4px;">
                        <?php if(!empty($value['kilogram'])): ?>
                          <span><i class="fas fa-balance-scale"></i> <?php echo htmlspecialchars($value['kilogram']); ?> kg</span>
                        <?php endif; ?>
                        <?php if(!empty($value['customize_message'])): ?>
                          <span style="margin-left:8px;"><i class="fas fa-comment-dots"></i> "<?php echo htmlspecialchars($value['customize_message']); ?>"</span>
                        <?php endif; ?>
                      </div>
                    <?php endif; ?>
                    <?php if($value['products_name'] === 'Giftbox'): ?>
                      <div>
                        <small>Card: <?php echo htmlspecialchars($value['card_number'] ?? ''); ?></small><br>
                        <small>Greeting: <?php echo htmlspecialchars($value['greeting_message'] ?? ''); ?></small><br>
                        <small>Delivery: <?php echo htmlspecialchars($value['delivery_date'] ?? ''); ?></small>
                      </div>
                    <?php endif; ?>
                  </td>
                  <td>LKR <?php echo $value['products_price'];  ?> </td>
                  <td class="quantity-control">
                    <input type="number" name="product_quantity" value="<?php echo $value['product_quantity'];  ?>" />
                    <input type="hidden" name="products_id" value="<?php echo $value['products_id'];  ?>" />
                  </td>
                  <td class="total-price">LKR </td>
                  <td>
                    <form method="POST" action="cart.php" style="display:inline;">
                      <input type="hidden" name="products_id" value="<?php echo $value['products_id'];  ?>" />   
                      <input type="submit" name="remove_product" class="remove-btn" value="remove"/>
                    </form>
                  </td>
                </tr>
          <?php 
              }
          } else {
              echo '<tr><td colspan="5">Your cart is empty.</td></tr>';
          }
        ?>
      </tbody>
    </table>

    <div class="cart-summary">
      <p><strong>Sub Total:</strong> <span id="subTotal">LKR 0</span></p>
      <p><strong>Delivery:</strong> <span id="delivery">LKR 0</span></p>
      <p><strong>Order Total:</strong> <span id="orderTotal">LKR 0</span></p>
      <button class="continue-btn" onclick="window.location.href='home.php'">Continue Shopping</button>
      <button class="checkout-btn" onclick="proceedToCheckout()">Checkout</button>
    </div>
  </div>

  <footer>
    <div class="footer-links">
      <a href="refund.html">Refund Policy</a>
      <a href="term.html">Terms & Conditions</a>
      <a href="privacy.html">Privacy Policy</a>
    </div>
    <div class="footer-social">
      <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
      <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
      <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
    </div>
    <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
  </footer>


  <script>
document.addEventListener("DOMContentLoaded", function() {
    calculateTotals();
    
    // Add event listeners for quantity changes
    document.querySelectorAll('input[name="product_quantity"]').forEach(input => {
        input.addEventListener('change', function() {
            updateQuantity(this);
        });
    });
});

function calculateTotals() {
    let subTotal = 0;
    
    // Calculate subtotal
    document.querySelectorAll('tbody tr').forEach(row => {
        const price = parseFloat(row.querySelector('td:nth-child(2)').textContent.replace('LKR ', ''));
        const quantity = parseInt(row.querySelector('input[name="product_quantity"]').value);
        const total = price * quantity;
        
        row.querySelector('td:nth-child(4)').textContent = 'LKR ' + total.toFixed(2);
        subTotal += total;
    });
    
    // Update subtotal
    document.getElementById('subTotal').textContent = 'LKR ' + subTotal.toFixed(2);
    
    // Calculate delivery (example: free for orders over 1000, else 350)
    const delivery = subTotal > 1000 ? 0 : 350;
    document.getElementById('delivery').textContent = 'LKR ' + delivery.toFixed(2);
    
    // Calculate order total
    const orderTotal = subTotal + delivery;
    document.getElementById('orderTotal').textContent = 'LKR ' + orderTotal.toFixed(2);
}

function updateQuantity(input) {
    const row = input.closest('tr');
    const price = parseFloat(row.querySelector('td:nth-child(2)').textContent.replace('LKR ', ''));
    const quantity = parseInt(input.value);
    const total = price * quantity;
    
    row.querySelector('td:nth-child(4)').textContent = 'LKR ' + total.toFixed(2);
    calculateTotals();
    
    // Optional: Send AJAX request to update quantity on server
    const productId = input.closest('tr').querySelector('input[name="products_id"]').value;
    
    fetch('update_quantity.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `products_id=${productId}&product_quantity=${quantity}`
    });
}

function proceedToCheckout() {
    // Convert PHP session cart to JSON
    const cart = <?php echo json_encode($_SESSION['cart'] ?? []); ?>;
    
    // Calculate totals
    const subTotal = calculateSubTotal(cart);
    const delivery = subTotal > 1000 ? 0 : 350;
    const orderTotal = subTotal + delivery;
    
    // Store in sessionStorage for checkout page
    sessionStorage.setItem('cart', JSON.stringify(cart));
    sessionStorage.setItem('orderTotal', orderTotal);
    
    // Redirect to checkout
    window.location.href = 'checkout.php';
}

function calculateSubTotal(cart) {
    return Object.values(cart).reduce((total, item) => {
        return total + (parseFloat(item.products_price) * parseInt(item.product_quantity));
    }, 0);
}

const cartContainer = document.getElementById('cart-container');
const giftPack = JSON.parse(localStorage.getItem('giftPack'));
// Add this function in your JS
function addGiftboxToCart() {
    const giftPack = JSON.parse(localStorage.getItem('giftPack'));
    if (!giftPack) return;

    const formData = new FormData();
    formData.append('add_giftbox_to_cart', '1');
    formData.append('giftPack', JSON.stringify(giftPack));

    fetch('cart.php', {
        method: 'POST',
        body: formData
    }).then(() => {
        // Reload to show in cart
        window.location.reload();
    });
}

// Call addGiftboxToCart() when user clicks "Add to Cart" or "Finish"

</script>
   
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>
