<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Create a debug log function
function debug_log($message) {
    file_put_contents('checkout_debug.log', date('Y-m-d H:i:s')." - $message\n", FILE_APPEND);
}

debug_log('=== Starting checkout process ===');

require_once 'connection.php';

// Verify database connection
if ($conn->connect_error) {
    $error = "Database connection failed: " . $conn->connect_error;
    debug_log($error);
    die(json_encode(['success' => false, 'message' => $error]));
}

debug_log('Database connection successful');

// Validate required fields from POST
$required = [
    'firstName' => 'First Name',
    'lastName' => 'Last Name',
    'country' => 'Country',
    'town' => 'Town/City',
    'postalCode' => 'Postal Code',
    'phone' => 'Phone Number',
    'orderDate' => 'Order Date',
    'preOrderDate' => 'Pre-Order Date'
];

$errors = [];
foreach ($required as $field => $label) {
    if (empty($_POST[$field])) {
        $errors[] = "$label is required.";
    }
}

if (!empty($errors)) {
    debug_log('Validation errors: ' . print_r($errors, true));
    $_SESSION['checkout_errors'] = $errors;
    header('Location: /Bakery/checkout.php');
    exit;
}

debug_log('Form validation passed');

// Verify cart is present
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    $error = 'Your cart is empty.';
    debug_log($error);
    $_SESSION['checkout_error'] = $error;
    header('Location: /Bakery/cart.php');
    exit;
}

debug_log('Cart exists. Beginning transaction.');

try {
    $conn->begin_transaction();

    // Order summary values
    $orderNumber = 'ORD-' . date('YmdHis') . '-' . rand(100, 999);
    $userId = !empty($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    $sessionId = session_id();

    // Calculate subtotal
    $subTotal = 0;
    foreach ($_SESSION['cart'] as $item) {
        $subTotal += $item['products_price'] * $item['product_quantity'];
    }
    $delivery = $subTotal > 1000 ? 0 : 350;
    $totalAmount = $subTotal + $delivery;

    debug_log("Generated order number: $orderNumber, Total: $totalAmount");

    // Extract all fields from cart
    $card_number = null;
    $greeting_message = null;
    $delivery_date = null;
    $flavor = null;
    $greeting = null;
    $greetColor = null;
    $image_path = null;

    foreach ($_SESSION['cart'] as $item) {
        if ($item['products_name'] === 'Giftbox') {
            $card_number = $item['card_number'] ?? null;
            $greeting_message = $item['greeting_message'] ?? null;
            $delivery_date = $item['delivery_date'] ?? null;
        }
        if ($item['products_name'] === 'Customize Cake') {
            $flavor = $item['flavor'] ?? null;
            $greeting = $item['greeting'] ?? null;
            $greetColor = $item['greetColor'] ?? null;
            $image_path = $item['products_image'] ?? null;
        }
    }

    // Insert one order with all fields
    $stmt = $conn->prepare("INSERT INTO orders 
        (order_number, user_id, session_id, total_amount, status, card_number, greeting_message, delivery_date, flavor, greeting, greetColor, products_image)
        VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisdsssssss", $orderNumber, $userId, $sessionId, $totalAmount, $card_number, $greeting_message, $delivery_date, $flavor, $greeting, $greetColor, $image_path);
    $stmt->execute();
    $orderId = $conn->insert_id;


    if ($stmt->affected_rows === 0 || $orderId == 0) {
    throw new Exception("Failed to insert order. Insert ID is 0.");
}
    $orderId = $conn->insert_id;
if ($orderId == 0) {
    throw new Exception("Order insertion failed - got 0 for insert ID");
}

    // Insert order items
    $stmtItems = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, kilogram, customize_message)
                             VALUES (?, ?, ?, ?, ?, ?)");

    foreach ($_SESSION['cart'] as $productId => $item) {
        $kilogram = $item['kilogram'] ?? null;
        $customize_message = $item['customize_message'] ?? null;
        $stmtItems->bind_param(
            "iiidss",
            $orderId,
            $productId,
            $item['product_quantity'],
            $item['products_price'],
            $kilogram,
            $customize_message
        );
        $stmtItems->execute();
    }

    debug_log("Inserted " . count($_SESSION['cart']) . " order items.");

    // Read user billing info from $_POST
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $country = $_POST['country'];
    $address = $_POST['address'] ?? '';
    $apartment = $_POST['apartment'] ?? '';
    $town = $_POST['town'];
    $postalCode = $_POST['postalCode'];
    $phone = $_POST['phone'];
    $orderDate = $_POST['orderDate'];
    $preOrderDate = $_POST['preOrderDate'];
    $notes = $_POST['notes'] ?? '';

    // Insert into order_details table
    $stmtDetails = $conn->prepare("INSERT INTO order_details 
        (order_id, first_name, last_name, country, address, apartment, town, postal_code, phone, order_date, pre_order_date, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmtDetails->bind_param("isssssssssss", $orderId, $firstName, $lastName, $country, $address, $apartment, $town, $postalCode, $phone, $orderDate, $preOrderDate, $notes);
    $stmtDetails->execute();

    debug_log("Order details inserted.");

    
    debug_log("Inserted order with customize cake details.");

    // Finalize transaction
    $conn->commit();

    // Clear session cart
    unset($_SESSION['cart']);
    debug_log("Cart cleared from session. Redirecting to payment page.");

    // Redirect to payment
    header("Location: /Bakery/server/payment.php?order_id=$orderId");
    exit;

} catch (Exception $e) {
    $conn->rollback();
    $error = "Checkout failed: " . $e->getMessage();
    debug_log("ERROR: $error");
    $_SESSION['checkout_error'] = $error;
    header('Location: /Bakery/checkout.php');
    exit;
}
