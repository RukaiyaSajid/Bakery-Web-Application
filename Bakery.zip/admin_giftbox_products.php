<?php
// filepath: c:\xampp\htdocs\Bakery\admindashboard\admin_giftbox_products.php
session_start();
require_once '../server/connection.php';

// Fetch all giftbox products from the giftbox_products table
$products = $conn->query("SELECT * FROM giftbox_products ORDER BY giftbox_product_id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Manage Giftbox Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
        body { background-color: #f8f9fa; }
        .sidebar {min-height: 100vh; background-color: #343a40; position: fixed; top: 0; z-index: 1020;}
        .sidebar .nav-link { color: rgba(255,255,255,0.75); }
        .sidebar .nav-link.active, .sidebar .nav-link:hover { color: #fff; background-color: #495057; }
        .main-content { padding: 20px; }
        .stat-card { min-height: 120px; }
        .low-stock { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar Navigation -->
        <nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar py-4">
            <div class="position-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item mb-2">
                        <a class="nav-link " href="admin_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="admin_blog.php">
                            <i class="fas fa-blog me-2"></i>Blog Posts
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="admin_products.php">
                            <i class="fas fa-box-open me-2"></i>Products - Cakes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="admin_savory_products.php">
                            <i class="fas fa-drumstick-bite me-2"></i>Products - Savory
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="admin_giftbox_products.php">
                            <i class="fas fa-gift me-2"></i>Products - Giftbox
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_tutorial.php">
                            <i class="fas fa-chalkboard-teacher me-2"></i>Tutorials
                        </a>
                    </li>
                    <li class="nav-item mt-3">
                        <a class="nav-link text-danger" href="/Bakery/admin_logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="container mt-5">
                <h2>Manage Giftbox Products</h2>
                <!-- Create Form -->
                <form method="POST" action="add_giftbox_product.php" enctype="multipart/form-data" class="mb-4">
                    <div class="row g-2">
                        <div class="col"><input type="text" name="name" class="form-control" placeholder="Giftbox Name" required></div>
                        <div class="col"><input type="number" name="price" class="form-control" placeholder="Price" required></div>
                        <div class="col"><input type="number" name="stock" class="form-control" placeholder="Stock" required></div>
                        <div class="col"><input type="file" name="image" class="form-control" accept="image/*" required></div>
                        <div class="col">
                            <select name="category" class="form-control" required>
                                <option value="">Select Category</option>
                                <option value="snacks">Snacks</option>
                                <option value="chocolates">Chocolates</option>
                                <option value="cake">Cake</option>
                                <option value="savory">Savory</option>
                                <!-- Add more categories as needed -->
                            </select>
                        </div>
                        <div class="col-12 mt-2">
                            <textarea name="description" class="form-control" placeholder="Giftbox Description" rows="2" required></textarea>
                        </div>
                        <div class="col">
                            <select name="status" class="form-control">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="col"><button type="submit" class="btn btn-success">Add Giftbox</button></div>
                    </div>
                </form>
                <!-- Products Table -->
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Price (LKR)</th>
                            <th>Stock</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while($row = $products->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['giftbox_product_id']; ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                            <td><?php echo number_format($row['price'],2); ?></td>
                            <td><?php echo $row['stock']; ?></td>
                            <td>
                                <?php if($row['image']): ?>
                                    <img src="../img/<?php echo $row['image']; ?>" alt="Giftbox" style="width:60px;">
                                <?php endif; ?>
                            </td>
                            <td><?php echo ucfirst($row['status']); ?></td>
                            <td>
                                <a href="edit_giftbox_product.php?giftbox_product_id=<?php echo $row['giftbox_product_id']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                <form method="POST" action="delete_giftbox_product.php" style="display:inline;">
                                    <input type="hidden" name="giftbox_product_id" value="<?php echo $row['giftbox_product_id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Delete this giftbox?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>
<!-- Font Awesome for icons -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
</body>
</html>