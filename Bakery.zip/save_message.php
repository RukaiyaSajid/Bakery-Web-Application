<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['message'])) {
    include('server/connection.php');
    $message = trim($_POST['message']); 
    $created_at = date('Y-m-d H:i:s');
    $stmt = $conn->prepare("INSERT INTO contact_messages (contact_message, created_at) VALUES (?, ?)");
    $stmt->bind_param("ss", $message, $created_at);
    if (!$stmt->execute()) {
            error_log('Error: ' . $stmt->error);
        die('Error: ' . $stmt->error);
    }
}
header('Location: contact.php?sent=1');
exit;