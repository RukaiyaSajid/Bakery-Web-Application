<?php
/**
 * General helper functions for Bakery Delivery Service
 */

/**
 * Format price with currency symbol
 * 
 * @param float $price The price to format
 * @param string $currency The currency symbol
 * @return string Formatted price
 */
function formatPrice($price, $currency = '$') {
    return $currency . number_format($price, 2);
}

/**
 * Generate a random order number
 * 
 * @return string Random order number
 */
function generateOrderNumber() {
    return 'BAK-' . date('Y') . '-' . mt_rand(1000, 9999);
}

/**
 * Get product by ID
 * 
 * @param int $id Product ID
 * @return array|null Product data or null if not found
 */
function getProduct($id) {
    global $conn;
    
    $sql = "SELECT * FROM products WHERE products_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Get featured bakery products
 * 
 * @param int $limit Number of products to return
 * @return array Array of featured products
 */
function getFeaturedProducts($limit = 8) {
    global $conn;
    
    $sql = "SELECT * FROM products WHERE status = 'active' ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Get bakery recipes
 * 
 * @param int $limit Number of recipes to return
 * @return array Array of recipes
 */
function getRecipes($limit = 3) {
    global $conn;
    
    $sql = "SELECT * FROM recipes ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Get baking tips
 * 
 * @param int $limit Number of tips to return
 * @return array Array of baking tips
 */
function getBakingTips($limit = 3) {
    global $conn;
    
    $sql = "SELECT * FROM baking_tips ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Get order by number
 * 
 * @param string $orderNumber Order number
 * @param int $userId User ID (optional)
 * @return array|null Order data or null if not found
 */
function getOrderByNumber($orderNumber, $userId = null) {
    global $conn;
    
    $sql = "SELECT * FROM orders WHERE order_number = ?";
    $params = [$orderNumber];
    $types = "s";
    
    if ($userId) {
        $sql .= " AND user_id = ?";
        $params[] = $userId;
        $types .= "i";
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

/**
 * Get user's recent orders
 * 
 * @param int $userId User ID
 * @param int $limit Number of orders to return
 * @return array Array of orders
 */
function getUserRecentOrders($userId, $limit = 5) {
    global $conn;
    
    $sql = "SELECT order_id as order_number, status, total_amount, created_at 
            FROM orders 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $userId, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Get order status color
 * 
 * @param string $status Order status
 * @return string Bootstrap color class
 */
function getOrderStatusColor($status) {
    $colors = [
        'pending' => 'warning',
        'processing' => 'info',
        'shipped' => 'primary',
        'delivered' => 'success',
        'completed' => 'secondary',
        'cancelled' => 'danger'
    ];
    
    return $colors[$status] ?? 'secondary';
}

/**
 * Get site settings
 * 
 * @param string $key Optional setting key
 * @return mixed Setting value or array of all settings
 */
function getSiteSettings($key = null) {
    global $config;
    
    // In a real application, you might fetch these from a database
    $settings = [
        'site_name' => $config['site_name'],
        'site_email' => $config['admin_email'],
        'site_phone' => $config['site_phone'],
        'site_address' => $config['site_address'],
        'free_shipping_threshold' => $config['free_shipping_threshold'],
        'currency' => $config['currency'],
        'supported_languages' => $config['supported_languages'],
        'default_shipping_cost' => $config['default_shipping_cost']
    ];
    
    if ($key !== null) {
        return $settings[$key] ?? null;
    }
    
    return $settings;
}

/**
 * Get cart item count
 * 
 * @return int Number of items in cart
 */
function getCartItemCount() {
    return isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
}

/**
 * Calculate cart total
 * 
 * @return float Total cart amount
 */
function calculateCartTotal() {
    $total = 0;
    
    if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $total += $item['price'] * $item['quantity'];
        }
    }
    
    return $total;
}

/**
 * Add product to cart
 * 
 * @param int $productId Product ID
 * @param int $quantity Quantity to add
 * @return bool Success status
 */
function addToCart($productId, $quantity = 1) {
    $product = getProduct($productId);
    
    if (!$product) {
        return false;
    }
    
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Check if product already in cart
    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $productId) {
            $item['quantity'] += $quantity;
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        $_SESSION['cart'][] = [
            'id' => $productId,
            'name' => $product['products_name'],
            'price' => $product['products_price'],
            'quantity' => $quantity,
            'image' => $product['products_image']
        ];
    }
    
    return true;
}

/**
 * Remove product from cart
 * 
 * @param int $productId Product ID to remove
 * @return bool Success status
 */
function removeFromCart($productId) {
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        return false;
    }
    
    foreach ($_SESSION['cart'] as $key => $item) {
        if ($item['id'] == $productId) {
            unset($_SESSION['cart'][$key]);
            // Re-index array
            $_SESSION['cart'] = array_values($_SESSION['cart']);
            return true;
        }
    }
    
    return false;
}

/**
 * Update cart item quantity
 * 
 * @param int $productId Product ID
 * @param int $quantity New quantity
 * @return bool Success status
 */
function updateCartQuantity($productId, $quantity) {
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        return false;
    }
    
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $productId) {
            $item['quantity'] = max(1, $quantity); // Ensure at least 1
            return true;
        }
    }
    
    return false;
}

/**
 * Get user by ID
 * 
 * @param int $userId User ID
 * @return array|null User data or null if not found
 */
function getUser($userId) {
    global $conn;
    
    $sql = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Format date in a friendly way
 * 
 * @param string $date Date string
 * @return string Formatted date
 */
function formatDate($date) {
    return date('F j, Y', strtotime($date));
}

/**
 * Check if email exists in database
 * 
 * @param string $email Email to check
 * @return bool True if exists, false otherwise
 */
function emailExists($email) {
    global $conn;
    
    $sql = "SELECT user_id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0;
}

/**
 * Get all bakery product categories
 * 
 * @return array Array of categories
 */
function getBakeryCategories() {
    global $conn;
    
    $sql = "SELECT DISTINCT category FROM products";
    $result = $conn->query($sql);
    
    $categories = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row['category'];
        }
    }
    
    return $categories;
}

/**
 * Get products by category
 * 
 * @param string $category Category name
 * @param int $limit Number of products to return
 * @return array Array of products
 */
function getProductsByCategory($category, $limit = 0) {
    global $conn;
    
    $sql = "SELECT * FROM products WHERE category = ?";
    if ($limit > 0) {
        $sql .= " LIMIT ?";
    }
    
    $stmt = $conn->prepare($sql);
    
    if ($limit > 0) {
        $stmt->bind_param("si", $category, $limit);
    } else {
        $stmt->bind_param("s", $category);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    
    return $products;
}
?>