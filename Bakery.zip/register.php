<?php session_start(); ?>
<?php
require_once 'functions.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    // Validate inputs
    if (empty($fullname)) {
        $errors['fullname'] = 'Full name is required';
    }

    if (empty($email)) {
        $errors['email'] = 'Email is required';
    } elseif (!validateEmail($email)) {
        $errors['email'] = 'Please enter a valid email address with @ symbol';
    }

    if (empty($password)) {
        $errors['password'] = 'Password is required';
    } elseif (!validatePassword($password)) {
        $errors['password'] = 'Password must be at least 8 characters long and contain at least 1 number';
    }

    if (empty($confirm_password)) {
        $errors['confirm_password'] = 'Please confirm your password';
    } elseif ($password !== $confirm_password) {
        $errors['confirm_password'] = 'Passwords do not match';
    }

    // Check if email already exists
    if (empty($errors)) {
        global $conn;
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $errors['email'] = 'Email already registered';
        }
    }

    // If no errors, register user
    if (empty($errors)) {
        $hashed_password = hashPassword($password);
        $is_admin = 0; // Regular user by default
        
        // Check if this is the admin (you would have a specific admin email)
        $admin_email = 'admin@butterhedge.com'; // Replace with your admin email
        if ($email === $admin_email) {
            $is_admin = 1;
        }

        $stmt = $conn->prepare("INSERT INTO users (user_name, email, password, is_admin) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $fullname, $email, $hashed_password, $is_admin);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $success = true;
            
            // Automatically log in the user after registration
            $user_id = $stmt->insert_id;
            $_SESSION['user_id'] = $user_id;
            $_SESSION['user_name'] = $fullname;
            $_SESSION['email'] = $email;
            $_SESSION['is_admin'] = $is_admin;
            
            // Redirect to login page after successful registration
            redirect('login.php');
        } else {
            $errors['general'] = 'Registration failed. Please try again.';
        }
    }
}
?>
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
  <style>
    .error-message {
      color: red;
      margin-bottom: 15px;
      padding: 10px;
      border: 1px solid red;
      border-radius: 5px;
      background-color: #ffeeee;
    }
    .success-message {
      color: green;
      margin-bottom: 15px;
      padding: 10px;
      border: 1px solid green;
      border-radius: 5px;
      background-color: #eeffee;
    }
    .register-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: calc(100vh - 100px);
      background-color: #fff;
      padding: 20px;
      margin-top: 40px;
    }
    .register-box {
      background-color: white;
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 20px;
      width: 400px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      margin-bottom: 100px;
    }
    .register-box h2 {
      margin-bottom: 20px;
      color: #BA954D;
      text-align: center;
    }
    .register-box label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }
    .register-box input[type="text"],
    .register-box input[type="email"],
    .register-box input[type="password"] {
      width: 100%;
      padding: 8px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .register-box p {
      font-size: 12px;
      color: #666;
      margin-bottom: 15px;
    }
    .register-box a{
        text-decoration: none;
        color: #96783A;
        font-weight: bold;
    }
    .register-box a:hover{
        text-decoration: underline;
        color: #96783A;
    }
    .register-box button {
      width: 100%;
      background-color: #BA954D;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }
    .register-box button:hover {
      background-color: #96783A;
    }
    .register-box .links {
      text-align: center;
      margin-top: 10px;
    }
    .register-box .links a {
      text-decoration: none;
      color: #BA954D;
    }
    .register-box .links a:hover {
      text-decoration: underline;
    }
    .invalid {
      border-color: red !important;
    }
  </style>
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.php">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
    <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
      </div>
    </div>    
  </nav>
</header>

<div class="login-header">Register</div>
  <div class="register-container">
    <div class="register-box">
      <?php if (!empty($errors['general'])): ?>
        <div class="alert alert-danger"><?php echo $errors['general']; ?></div>
      <?php endif; ?>
      
      <form method="post" action="register.php">
        <label for="fullname">Full Name</label>
        <input type="text" id="fullname" name="fullname" value="<?php echo isset($fullname) ? htmlspecialchars($fullname) : ''; ?>" required>
        <?php if (!empty($errors['fullname'])): ?>
          <div class="error-message"><?php echo $errors['fullname']; ?></div>
        <?php endif; ?>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>
        <?php if (!empty($errors['email'])): ?>
          <div class="error-message"><?php echo $errors['email']; ?></div>
        <?php endif; ?>

        <label for="password">Password</label>
        <div style="position:relative;">
          <input type="password" id="password" name="password" required style="padding-right:35px;">
          <span id="togglePassword" style="position:absolute; right:10px; top:50%; transform:translateY(-50%); cursor:pointer;">
            <i class="fas fa-eye"></i>
          </span>
        </div>
        <?php if (!empty($errors['password'])): ?>
          <div class="error-message"><?php echo $errors['password']; ?></div>
        <?php endif; ?>
        <p>Minimum 8 characters, at least 1 number</p>

        <label for="confirm-password">Confirm Password</label>
        <div style="position:relative;">
          <input type="password" id="confirm-password" name="confirm-password" required style="padding-right:35px;">
          <span id="toggleConfirmPassword" style="position:absolute; right:10px; top:50%; transform:translateY(-50%); cursor:pointer;">
            <i class="fas fa-eye"></i>
          </span>
        </div>
        <?php if (!empty($errors['confirm_password'])): ?>
          <div class="error-message"><?php echo $errors['confirm_password']; ?></div>
        <?php endif; ?>

        <p>Your personal data will be used to support your experience throughout this website, to manage access 
          to your account, and for other purposes described in our <a href="privacy.html">privacy policy</a>.</p>

        <button type="submit">Register</button>

        <div class="links">
          Already a member? <a href="login.php">Login</a>
        </div>
      </form>
    </div>
  </div>
<footer>
  <div class="footer-links">
    <a href="refund.html">Refund Policy</a>
    <a href="term.html">Terms & Conditions</a>
    <a href="privacy.html">Privacy Policy</a>
  </div>
  <div class="footer-social">
    <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
  </div>
  <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script>
   function validateForm() {
    // Reset previous error states
    document.getElementById('email').classList.remove('invalid');
    document.getElementById('password').classList.remove('invalid');
    document.getElementById('confirm-password').classList.remove('invalid');
    
    // Get form values
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    // Validate email
    if (!email.includes('@')) {
      alert('Please enter a valid email address with @ symbol');
      document.getElementById('email').classList.add('invalid');
      return false;
    }
    
    // Validate password length and number
    if (password.length < 8) {
      alert('Password must be at least 8 characters long');
      document.getElementById('password').classList.add('invalid');
      return false;
    }
    
    if (!/\d/.test(password)) {
      alert('Password must contain at least one number');
      document.getElementById('password').classList.add('invalid');
      return false;
    }
    
    // Validate password match
    if (password !== confirmPassword) {
      alert('Passwords do not match');
      document.getElementById('confirm-password').classList.add('invalid');
      return false;
    }
    
    return true;
  }
  // Real-time validation for password
  document.getElementById('password').addEventListener('input', function() {
    const password = this.value;
    const hasNumber = /\d/.test(password);
    const hasMinLength = password.length >= 8;
    
    if (!hasNumber || !hasMinLength) {
      this.classList.add('invalid');
    } else {
      this.classList.remove('invalid');
    }
  });

  // Real-time validation for email
  document.getElementById('email').addEventListener('blur', function() {
    const email = this.value;
    if (email && !email.includes('@')) {
      this.classList.add('invalid');
    } else {
      this.classList.remove('invalid');
    }
  });

  // Real-time validation for confirm password
  document.getElementById('confirm-password').addEventListener('input', function() {
    const password = document.getElementById('password').value;
    const confirmPassword = this.value;
    
    if (confirmPassword && password !== confirmPassword) {
      this.classList.add('invalid');
    } else {
      this.classList.remove('invalid');
    }
  });

 document.getElementById('togglePassword').addEventListener('click', function () {
    const passwordInput = document.getElementById('password');
    const icon = this.querySelector('i');
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      icon.classList.remove('fa-eye');
      icon.classList.add('fa-eye-slash');
    } else {
      passwordInput.type = 'password';
      icon.classList.remove('fa-eye-slash');
      icon.classList.add('fa-eye');
    }
  });

  document.getElementById('toggleConfirmPassword').addEventListener('click', function () {
    const passwordInput = document.getElementById('confirm-password');
    const icon = this.querySelector('i');
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      icon.classList.remove('fa-eye');
      icon.classList.add('fa-eye-slash');
    } else {
      passwordInput.type = 'password';
      icon.classList.remove('fa-eye-slash');
      icon.classList.add('fa-eye');
    }
  }); 
</script>
</body>
</html>