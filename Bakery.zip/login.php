<?php session_start(); ?>
<?php
require_once 'functions.php';

// Define admin credentials (change these as needed)
$admin_email = 'admin@butterhedge.com';
$admin_password_hash = password_hash('admin123', PASSWORD_DEFAULT); // Set your admin password here

$errors = [];

// Check for remember me cookie
if (isset($_COOKIE['remember_me']) && !isLoggedIn()) {
    list($user_id, $token) = explode(':', $_COOKIE['remember_me']);
    
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ? AND remember_token = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("is", $user_id, $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['user_name'] = $user['user_name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['is_admin'] = $user['is_admin'];
        
        // Redirect to admin page
        redirect('login.php');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']) ? true : false;

    // Validate inputs
    if (empty($email)) {
        $errors['email'] = 'Email is required';
    }
    if (empty($password)) {
        $errors['password'] = 'Password is required';
    }

    // Check admin login first
    if (empty($errors) && $email === $admin_email && password_verify($password, $admin_password_hash)) {
        // Admin login successful
        $_SESSION['user_id'] = 0;
        $_SESSION['user_name'] = 'Admin';
        $_SESSION['email'] = $admin_email;
        $_SESSION['is_admin'] = 1;
        redirect('admindashboard/admin_dashboard.php');
        exit;
    }

    if (empty($errors)) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($user = $result->fetch_assoc()) {
            if (verifyPassword($password, $user['password'])) {
                // Login successful
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['user_name'] = $user['user_name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['is_admin'] = $user['is_admin'];
                
                // Handle remember me
                if ($remember) {
                    $token = generateToken();
                    $stmt = $conn->prepare("UPDATE users SET remember_token = ? WHERE user_id = ?");
                    $stmt->bind_param("si", $token, $user['user_id']);
                    $stmt->execute();
                    setRememberMeCookie($user['user_id'], $token);
                }
                
                // Redirect to home page
                redirect('home.php');
            } else {
                $errors['password'] = 'Incorrect password';
            }
        } else {
            $errors['email'] = 'Email not found';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
</head>
<body>

  <header>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.php">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
      <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>        
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>

      </div>
    </div>    
  </nav>
</header>


  <div class="login-header">Login</div>
  <div class="login-container">
    <div class="login-box">
      <?php if (isset($errors['login'])): ?>
        <div class="error" style="text-align: center; margin-bottom: 15px;"><?= $errors['login'] ?></div>
      <?php endif; ?>
      
      <form method="POST" action="login.php">
        <label for="email">Email</label>
        <input type="text" id="email" name="email" value="<?= htmlspecialchars($email ?? '') ?>" required>
        <?php if (isset($errors['email'])): ?>
          <div class="error"><?= $errors['email'] ?></div>
        <?php endif; ?>

        <label for="password">Password</label>
        <div style="position:relative;">
          <input type="password" id="password" name="password" required style="padding-right: 35px;">
          <span id="togglePassword" style="position:absolute; right:10px; top:50%; transform:translateY(-50%); cursor:pointer;">
            <i class="fas fa-eye"></i>
          </span>
        </div>
        <?php if (isset($errors['password'])): ?>
          <div class="error"><?= $errors['password'] ?></div>
        <?php endif; ?>

        <div class="remember-me">
          <input type="checkbox" id="remember" name="remember">
          <label for="remember">Remember me</label>
        </div>

        <button type="submit">Login</button>

        <div class="links">
          <a href="forgot_password.php" id="forgot-password-link">Lost your password?</a><br>
          <p>Not a member? <a href="register.php">Register</a></p>
        </div>
      </form>
    </div>
  </div>
<footer>
  <div class="footer-links">
    <a href="refund.html">Refund Policy</a>
    <a href="term.html">Terms & Conditions</a>
    <a href="privacy.html">Privacy Policy</a>
  </div>
  <div class="footer-social">
    <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
  </div>
  <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
</footer>
<script>
     document.getElementById('togglePassword').addEventListener('click', function () {
    const passwordInput = document.getElementById('password');
    const icon = this.querySelector('i');
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      icon.classList.remove('fa-eye');
      icon.classList.add('fa-eye-slash');
    } else {
      passwordInput.type = 'password';
      icon.classList.remove('fa-eye-slash');
      icon.classList.add('fa-eye');
    }
  });
</script>
</html>