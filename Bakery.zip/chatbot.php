<?php
require_once 'includes/config.php';
require_once 'includes/session.php';

// Direct session check to avoid function dependencies
if (!isset($_SESSION['user_id'])) {
    return;
}
?>

<div id="bakery-chatbot-widget" class="bakery-chatbot-widget">
    <div class="bakery-chatbot-toggle" onclick="toggleBakeryChatbot()">
        <i class="fas fa-comment-dots"></i>
        <span class="chat-notification" id="bakeryChatNotification" style="display: none;"></span>
    </div>
    
    <div class="bakery-chatbot-container" id="bakeryChatbotContainer" style="display: none;">
        <div class="bakery-chatbot-header">
            <div class="d-flex align-items-center">
                <img src="img/robo.jpg" alt="Bakery Assistant" class="bakery-chatbot-avatar" onerror="this.src='assets/images/default-avatar.png'">
                <div>
                    <h6 class="mb-0">Bakery Assistant</h6>
                    <small class="text-muted" id="bakeryChatStatus">Online</small>
                </div>
            </div>
            <div>
                <button class="btn btn-sm" onclick="toggleBakeryChatbotFullscreen()" title="Fullscreen">
                    <i class="fas fa-expand"></i>
                </button>
                <button class="btn btn-sm" onclick="toggleBakeryChatbot()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
        
        <div class="bakery-chatbot-messages" id="bakeryChatbotMessages">
            <div class="message bot-message">
                <div class="message-content">
                    <p>Hello! I'm your Bakery Assistant. How can I help you today?</p>
                    <div class="quick-actions">
                        <button class="btn btn-sm btn-outline-primary" onclick="sendBakeryQuickMessage('Track my order')">
                            <i class="fas fa-truck"></i> Track Order
                        </button>
                        <button class="btn btn-sm btn-outline-primary" onclick="sendBakeryQuickMessage('Product recommendations')">
                            <i class="fas fa-bread-slice"></i> Recommendations
                        </button>
                        <button class="btn btn-sm btn-outline-primary" onclick="sendBakeryQuickMessage('Recipe ideas')">
                            <i class="fas fa-book"></i> Recipes
                        </button>
                    </div>
                </div>
                <small class="message-time"><?php echo date('H:i'); ?></small>
            </div>
        </div>
        
        <div class="bakery-chatbot-input">
            <div class="input-group">
                <input type="text" class="form-control" id="bakeryChatInput" placeholder="Type your message..." onkeypress="handleBakeryChatKeyPress(event)">
                <button class="btn btn-primary" onclick="sendBakeryMessage()">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Recipe Modal -->
<div class="modal fade" id="bakeryRecipeModal" tabindex="-1" aria-labelledby="bakeryRecipeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="bakeryRecipeModalLabel">Recipe Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="closeBakeryRecipeModal()"></button>
      </div>
      <div class="modal-body" id="bakeryRecipeModalBody">
        <!-- Recipe content will be loaded here -->
      </div>
    </div>
  </div>
</div>

<style>
.bakery-chatbot-widget {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 1000;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.bakery-chatbot-toggle {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #BA954D 0%, #96783A 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    transition: all 0.3s ease;
    position: relative;
}

.bakery-chatbot-toggle:hover {
    transform: scale(1.1);
}

.bakery-chatbot-container {
    width: 350px;
    height: 500px;
    background: white;
    border-radius: 15px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    position: absolute;
    bottom: 80px;
    right: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    animation: slideUp 0.3s ease;
}

.bakery-chatbot-container.fullscreen {
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    border-radius: 0 !important;
    z-index: 2000 !important;
    box-shadow: none !important;
    animation: none !important;
}

.bakery-chatbot-header {
    background: linear-gradient(135deg, #BA954D 0%, #96783A 100%);
    color: white;
    padding: 15px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.bakery-chatbot-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.bakery-chatbot-messages {
    flex: 1;
    padding: 15px;
    overflow-y: auto;
    background: #f8f9fa;
}

.bakery-chatbot-input {
    padding: 15px;
    border-top: 1px solid #dee2e6;
    background: white;
}

/* Message styles (same as before) */
.message {
    margin-bottom: 15px;
    animation: fadeIn 0.3s ease;
}

.message-content {
    background: white;
    padding: 12px 15px;
    border-radius: 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    max-width: 80%;
}

.bot-message .message-content {
    background: #e3f2fd;
    margin-right: auto;
}

.user-message .message-content {
    background:rgb(194, 174, 133);
    color: white;
    margin-left: auto;
}

.message-time {
    display: block;
    color:rgb(87, 86, 77);
    font-size: 11px;
    margin-top: 5px;
}

.quick-actions {
    margin-top: 10px;
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}

.quick-actions .btn {
    font-size: 11px;
    padding: 5px 10px;
}

.typing-indicator {
    display: flex;
    align-items: center;
    padding: 10px 15px;
    color:rgb(125, 122, 108);
    font-style: italic;
}

.typing-dots {
    display: inline-flex;
    margin-left: 10px;
}

.typing-dots span {
    height: 8px;
    width: 8px;
    background:rgb(125, 120, 108);
    border-radius: 50%;
    display: inline-block;
    margin: 0 2px;
    animation: typing 1.4s infinite ease-in-out;
}

.typing-dots span:nth-child(1) { animation-delay: -0.32s; }
.typing-dots span:nth-child(2) { animation-delay: -0.16s; }

@keyframes typing {
    0%, 80%, 100% { transform: scale(0.8); opacity: 0.5; }
    40% { transform: scale(1); opacity: 1; }
}

@media (max-width: 768px) {
    .bakery-chatbot-container {
        width: 90vw;
        height: 70vh;
        bottom: 80px;
        right: 5vw;
    }
}

/* Additional styles for bakery-specific components */
.bakery-product-list {
    max-height: 200px;
    overflow-y: auto;
}

.bakery-product-item {
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 10px;
    margin: 5px 0;
    cursor: pointer;
    transition: all 0.2s ease;
}

.bakery-product-item:hover {
    background: #e9ecef;
    transform: translateY(-1px);
}

.bakery-recipe-card {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 10px;
}

.bakery-recipe-card h6 {
    color:rgb(207, 178, 119);
}

.bakery-tip-card {
    background: #fff9f9;
    border-left: 4px solid #BA954D;
    padding: 10px;
    margin-bottom: 10px;
}
</style>

<script>
let bakeryChatSession = null;
let bakeryMessageHistory = [];
let bakeryIsTyping = false;

function toggleBakeryChatbot() {
    const container = document.getElementById('bakeryChatbotContainer');
    const notification = document.getElementById('bakeryChatNotification');
    
    if (container.style.display === 'none') {
        container.style.display = 'flex';
        notification.style.display = 'none';
        initializeBakeryChatSession();
        markBakeryMessagesAsRead();
    } else {
        container.style.display = 'none';
    }
}

function initializeBakeryChatSession() {
    if (!bakeryChatSession) {
        bakeryChatSession = {
            id: 'bakery_session_' + Date.now(),
            userId: <?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'null'; ?>,
            startTime: new Date().toISOString()
        };
        
        // Save session to backend
        fetch('api/chat_session.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'create_session',
                session: bakeryChatSession
            })
        });
    }
}

function handleBakeryChatKeyPress(event) {
    if (event.key === 'Enter') {
        sendBakeryMessage();
    }
}

function sendBakeryMessage() {
    const input = document.getElementById('bakeryChatInput');
    const message = input.value.trim();
    
    if (message) {
        addBakeryMessage(message, 'user');
        input.value = '';
        processBakeryUserMessage(message);
    }
}

function sendBakeryQuickMessage(message) {
    addBakeryMessage(message, 'user');
    processBakeryUserMessage(message);
}

function addBakeryMessage(content, type, showTime = true) {
    const messagesContainer = document.getElementById('bakeryChatbotMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}-message`;
    
    const time = showTime ? `<small class="message-time">${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</small>` : '';
    
    messageDiv.innerHTML = `
        <div class="message-content">
            ${content}
        </div>
        ${time}
    `;
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Save message to history
    bakeryMessageHistory.push({
        content: content,
        type: type,
        timestamp: new Date().toISOString()
    });
    
    // Save to backend
    saveBakeryMessageToBackend(content, type);
}

function showBakeryTypingIndicator() {
    if (bakeryIsTyping) return;
    
    bakeryIsTyping = true;
    const messagesContainer = document.getElementById('bakeryChatbotMessages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'typing-indicator';
    typingDiv.id = 'bakeryTypingIndicator';
    typingDiv.innerHTML = `
        Assistant is typing
        <div class="typing-dots">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function hideBakeryTypingIndicator() {
    bakeryIsTyping = false;
    const typingIndicator = document.getElementById('bakeryTypingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function processBakeryUserMessage(message) {
    showBakeryTypingIndicator();
    
    // Send to backend for processing
    fetch('api/chatbot_response.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            message: message,
            session_id: bakeryChatSession?.id,
            user_id: <?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'null'; ?>
        })
    })
    .then(response => response.json())
    .then(data => {
        hideBakeryTypingIndicator();
        
        if (data.success) {
            addBakeryMessage(data.response, 'bot');
            
            // Handle special actions
            if (data.actions) {
                handleBakeryBotActions(data.actions);
            }
        } else {
            addBakeryMessage('Sorry, I encountered an error. Please try again.', 'bot');
        }
    })
    .catch(error => {
        hideBakeryTypingIndicator();
        addBakeryMessage('Connection error. Please check your internet connection.', 'bot');
    });
}

function handleBakeryBotActions(actions) {
    actions.forEach(action => {
        switch (action.type) {
            case 'show_orders':
                displayBakeryUserOrders(action.data);
                break;
            case 'show_products':
                displayBakeryProducts(action.data);
                break;
            case 'show_recipes':
                displayBakeryRecipes(action.data);
                break;
            case 'show_tips':
                displayBakeryTips(action.data);
                break;
            case 'track_order':
                displayBakeryOrderTracking(action.data);
                break;
        }
    });
}

function displayBakeryUserOrders(orders) {
    if (orders && orders.length > 0) {
        let ordersHtml = '<div class="bakery-orders-list">';
        orders.forEach(order => {
            ordersHtml += `
                <div class="bakery-order-item" onclick="trackBakeryOrder('${order.order_number}')">
                    <strong>Order #${order.order_number}</strong><br>
                    <small>Status: <span class="badge bg-${getBakeryStatusColor(order.status)}">${order.status}</span></small><br>
                    <small>Amount: $${order.total_amount}</small>
                </div>
            `;
        });
        ordersHtml += '</div>';
        
        addBakeryMessage(ordersHtml, 'bot', false);
    }
}

function displayBakeryOrderTracking(orderData) {
    if (orderData) {
        let trackingHtml = `
            <div class="bakery-order-tracking">
                <h6>Order #${orderData.order_number}</h6>
                <div class="tracking-status">
                    <div class="status-item ${orderData.status === 'pending' || orderData.status === 'processing' || orderData.status === 'shipped' || orderData.status === 'delivered' || orderData.status === 'completed' ? 'active' : ''}">
                        <i class="fas fa-circle"></i> Order Placed
                    </div>
                    <div class="status-item ${orderData.status === 'processing' || orderData.status === 'shipped' || orderData.status === 'delivered' || orderData.status === 'completed' ? 'active' : ''}">
                        <i class="fas fa-circle"></i> Processing
                    </div>
                    <div class="status-item ${orderData.status === 'shipped' || orderData.status === 'delivered' || orderData.status === 'completed' ? 'active' : ''}">
                        <i class="fas fa-circle"></i> Shipped
                    </div>
                    <div class="status-item ${orderData.status === 'delivered' || orderData.status === 'completed' ? 'active' : ''}">
                        <i class="fas fa-circle"></i> Delivered
                    </div>
                    <div class="status-item ${orderData.status === 'completed' ? 'active' : ''}">
                        <i class="fas fa-circle"></i> Completed
                    </div>
                </div>
                <p><strong>Current Status:</strong> ${orderData.status}</p>
                ${orderData.payment_method === 'cod' && orderData.payment_status === 'pending' ? 
                    '<p><small class="text-warning">⚠️ COD Payment Pending</small></p>' : ''}
            </div>
        `;
        
        addBakeryMessage(trackingHtml, 'bot', false);
    }
}

function trackBakeryOrder(orderNumber) {
    sendBakeryMessage(`Track order ${orderNumber}`);
}

function displayBakeryProducts(products) {
    if (products && products.length > 0) {
        let productsHtml = '<div class="bakery-product-list">';
        products.forEach(product => {
            productsHtml += `
                <div class="bakery-product-item">
                    <div class="d-flex">
                        <img src="img/${product.products_image}" 
                             style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px; margin-right: 10px;"
                             onerror="this.src='img/no-image.jpg'">
                        <div>
                            <strong>${product.products_name}</strong><br>
                            <small>LKR${parseFloat(product.products_price).toFixed(2)}</small>
                        </div>
                    </div>
                    <div class="mt-2">
                        <button class="btn btn-sm btn-primary" onclick="addBakeryProductToCart(${product.products_id})">
                            <i class="fas fa-cart-plus"></i> Add to Cart
                        </button>
                        <button class="btn btn-sm btn-outline-secondary ms-2" onclick="viewBakeryProduct(${product.products_id}, '${product.category}')">
                            <i class="fas fa-info-circle"></i> Details
                        </button>
                    </div>
                </div>
            `;
        });
        productsHtml += '</div>';
        addBakeryMessage(productsHtml, 'bot', false);
    }
}

function displayBakeryRecipes(recipes) {
    if (recipes && recipes.length > 0) {
        let recipesHtml = '';
        recipes.forEach(recipe => {
            const totalTime = recipe.prep_time + recipe.cook_time;
            recipesHtml += `
                <div class="bakery-recipe-card">
                    <h6>${recipe.title}</h6>
                    <small class="text-muted"><i class="fas fa-clock"></i> ${totalTime} mins | ${recipe.category}</small>
                    <p class="mt-2">${recipe.ingredients.substring(0, 1000)}...</p>
                    <button class="btn btn-sm btn-outline-primary mt-2" onclick="viewBakeryRecipe(${recipe.recipe_id})">
                        View Full Recipe
                    </button>
                </div>
            `;
        });
        
        addBakeryMessage(recipesHtml, 'bot', false);
    }
}

function displayBakeryTips(tips) {
    if (tips && tips.length > 0) {
        let tipsHtml = '';
        tips.forEach(tip => {
            tipsHtml += `
                <div class="bakery-tip-card">
                    <strong><i class="fas fa-lightbulb"></i> ${tip.category} Tip</strong>
                    <p class="mt-1 mb-0">${tip.tip_text}</p>
                </div>
            `;
        });
        
        addBakeryMessage(tipsHtml, 'bot', false);
    }
}

function getBakeryStatusColor(status) {
    const colors = {
        'pending': 'warning',
        'processing': 'info', 
        'shipped': 'primary',
        'delivered': 'warning',
        'completed': 'success',
        'cancelled': 'danger'
    };
    return colors[status] || 'secondary';
}

function saveBakeryMessageToBackend(content, type) {
    if (bakeryChatSession) {
        fetch('api/save_chat_message.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                session_id: bakeryChatSession.id,
                message: content,
                type: type,
                user_id: <?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'null'; ?>
            })
        });
    }
}

function markBakeryMessagesAsRead() {
    if (bakeryChatSession) {
        fetch('api/mark_messages_read.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                session_id: bakeryChatSession.id,
                user_id: <?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'null'; ?>
            })
        });
    }
}

// Check for new messages periodically
setInterval(() => {
    if (bakeryChatSession && document.getElementById('bakeryChatbotContainer').style.display === 'none') {
        checkBakeryNewMessages();
    }
}, 30000);

function checkBakeryNewMessages() {
    fetch(`api/check_new_messages.php?session_id=${bakeryChatSession.id}`)
    .then(response => response.json())
    .then(data => {
        if (data.hasNewMessages) {
            document.getElementById('bakeryChatNotification').style.display = 'flex';
            document.getElementById('bakeryChatNotification').textContent = data.count;
        }
    });
}

// Product and recipe functions
function addBakeryProductToCart(productId) {
    fetch('add_to_cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            product_id: productId,
            quantity: 1
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            addBakeryMessage('Product added to cart!', 'bot');
            // You might want to update the cart count in your UI here
        } else {
            addBakeryMessage('Failed to add product to cart: ' + data.error, 'bot');
        }
    });
}

function viewBakeryProduct(productId, category) {
    let page = '';
    if (category === 'cake') {
        page = 'cake.php';
    } else if (category === 'savory') {
        page = 'savory.php';
    } else {
        page = 'product.php'; // fallback for other categories
    }
    window.open(`${page}?products_id=${productId}`, '_blank');
}


function viewBakeryRecipe(recipeId) {
    // Fetch full recipe details from backend
    fetch(`api/get_recipe.php?id=${recipeId}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const recipe = data.recipe;
            let html = `<h5>${recipe.title}</h5>`;
            html += `<p><strong>Category:</strong> ${recipe.category}</p>`;
            html += `<p><strong>Prep Time:</strong> ${recipe.prep_time} mins</p>`;
            html += `<p><strong>Cook Time:</strong> ${recipe.cook_time} mins</p>`;
            html += `<p><strong>Ingredients:</strong><br>${recipe.ingredients.replace(/\n/g, '<br>')}</p>`;
            html += `<p><strong>Instructions:</strong><br>${recipe.instructions.replace(/\n/g, '<br>')}</p>`;
            document.getElementById('bakeryRecipeModalBody').innerHTML = html;
            openBakeryRecipeModal();
        } else {
            document.getElementById('bakeryRecipeModalBody').innerHTML = 'Recipe not found.';
            openBakeryRecipeModal();
        }
    })
    .catch(() => {
        document.getElementById('bakeryRecipeModalBody').innerHTML = 'Error loading recipe.';
        openBakeryRecipeModal();
    });
}

function openBakeryRecipeModal() {
    // For Bootstrap 5 modal
    const modal = new bootstrap.Modal(document.getElementById('bakeryRecipeModal'));
    modal.show();
}

function closeBakeryRecipeModal() {
    const modalEl = document.getElementById('bakeryRecipeModal');
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
}

function toggleBakeryChatbotFullscreen() {
    const container = document.getElementById('bakeryChatbotContainer');
    container.classList.toggle('fullscreen');
}
</script>