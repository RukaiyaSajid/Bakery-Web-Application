<?php
require_once '../includes/config.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid recipe ID']);
    exit;
}

$recipeId = intval($_GET['id']);

$sql = "SELECT * FROM recipes WHERE recipe_id = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $recipeId);
$stmt->execute();
$result = $stmt->get_result();
$recipe = $result->fetch_assoc();

if ($recipe) {
    echo json_encode(['success' => true, 'recipe' => $recipe]);
} else {
    echo json_encode(['success' => false, 'error' => 'Recipe not found']);
}
