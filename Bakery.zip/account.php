<?php session_start(); ?>
<?php
session_start();
require_once 'server/connection.php';

// Assume user is logged in and user_id is in session
$user_id = $_SESSION['user_id'] ?? 1; // For demo, fallback to 1

// Fetch user profile
$stmt = $conn->prepare("SELECT user_name, email, user_contact, avatar FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Fetch order history
$stmt = $conn->prepare("SELECT order_id, order_number, order_date, status, total_amount FROM orders WHERE user_id = ? ORDER BY order_date DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Account</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="styles.css"> 
  <style>
    body, html {
  font-family: 'Segoe UI', 'Arial', 'sans-serif';
}
      .navbar {    
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      padding: 10px 20px;
      background: #fff;
      position: fixed;
      top: 0;
      left: 0;
      z-index: 1000;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    
    
    .logo{
      margin-left: 10px;
    }
    
    .logo img {
      height: 65px; 
      width: 90px;
      display: flex;
    
    }
    
    .nav-links {
      list-style: none;
      display: flex;
      gap: 20px;
      margin: 0;
      padding: 5px;
    }
    
    .nav-links li {
      display: inline;
    }
    
    .nav-links a {
      text-decoration: none;
      color: #585858;
      font-weight: bold;
    }
    
    .nav-links a:hover {
      color: #BA954D;
    }
    
    
    .icons a {
      text-decoration: none;
      font-size: 18px;
      margin-right: 35px;
      color: #585858;
    
    }
    
    .icons :hover {
      color: #BA954D;
    }
    
    /* Dropdown Menu */
    .dropdown {
      display: none;
      position: absolute;
      background-color: white;
      box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
      min-width: 150px;
      z-index: 1000;
      border-radius: 5px;
    }
    
    .dropdown a {
      padding: 10px 15px;
      display: block;
      white-space: nowrap;
      color: #585858;
    }
    
    .nav-links .dropdown a:hover {
      background-color: #BA954D;
      color: white;
    }
    
    /* Show dropdown on hover */
    .nav-links li:hover .dropdown {
      display: block;
    }  
    .account-container { max-width: 900px; margin: 40px auto; background: #fff; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,0.07); padding: 32px 24px; }
    .profile-summary { display: flex; align-items: center; border-bottom: 1px solid #eee; padding-bottom: 24px; margin-bottom: 24px; }
    .profile-avatar { width: 90px; height: 90px; border-radius: 50%; background: #eee; object-fit: cover; margin-right: 28px; }
    .profile-info { flex: 1; }
    .profile-info h2 { margin: 0 0 8px 0; color: #96783A; }
    .profile-info p { margin: 2px 0; color: #555; }
    .edit-profile-btn { background: #BA954D; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 1rem; cursor: pointer; margin-top: 10px; }
    .edit-profile-btn:hover { background: #96783A; }
    .account-sections { display: flex; flex-wrap: wrap; gap: 32px; }
    .account-card { flex: 1 1 300px; background: #faf7f2; border-radius: 8px; padding: 22px 18px; box-shadow: 0 2px 8px rgba(186, 149, 77, 0.07); }
    .account-card h3 { color: #96783A; margin-bottom: 12px; }
    .account-card form label { display: block; margin: 10px 0 4px 0; color: #6d5c2c; }
    .account-card input[type="text"], .account-card input[type="email"], .account-card input[type="password"], .account-card input[type="tel"] {
      width: 100%; padding: 8px; border: 1px solid #d2b97c; border-radius: 5px; margin-bottom: 10px; background: #fffdfa;
    }
    .account-card button { background: #BA954D; color: #fff; border: none; border-radius: 5px; padding: 8px 16px; cursor: pointer; }
    .account-card button:hover { background: #96783A; }
    .order-history-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    .order-history-table th, .order-history-table td { padding: 10px 8px; border-bottom: 1px solid #e0d7c6; text-align: left; }
    .order-history-table th { background: #f4f1ea; color: #96783A; }
    .track-btn { background: #96783A; color: #fff; border: none; border-radius: 4px; padding: 5px 12px; cursor: pointer; font-size: 0.95rem; }
    .track-btn:hover { background: #BA954D; }
    @media (max-width: 900px) {
      .account-sections { flex-direction: column; gap: 18px; }
      .profile-summary { flex-direction: column; align-items: flex-start; }
      .profile-avatar { margin-bottom: 18px; margin-right: 0; }
    }

    /* Edit Profile Modal Styles */
    #editProfileModal { display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.4); z-index:1000; align-items:center; justify-content:center; }
    #editProfileModal > div { background:#fff; border-radius:10px; max-width:400px; width:90%; margin:auto; padding:28px 22px; position:relative; }
    #editProfileModal button.close { position:absolute; top:10px; right:16px; background:none; border:none; font-size:1.5rem; color:#96783A; cursor:pointer; }
    #editProfileModal h3 { color:#96783A; margin-bottom:18px; }
    #editProfileModal label { display:block; margin:10px 0 4px 0; color:#6d5c2c; }
    #editProfileModal input[type="text"], #editProfileModal input[type="email"], #editProfileModal input[type="tel"], #editProfileModal input[type="file"] {
      width:100%; padding:8px; border:1px solid #d2b97c; border-radius:5px; margin-bottom:10px; background:#fffdfa;
    }
    #editProfileModal button[type="submit"] { background:#BA954D; color:#fff; border:none; border-radius:5px; padding:8px 16px; cursor:pointer; }
    #editProfileModal button[type="submit"]:hover { background:#96783A; }

    /* Track Order Modal Styles */
    #trackOrderModal { display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.4); z-index:1001; align-items:center; justify-content:center; }
    #trackOrderModal > div { background:#fff; border-radius:10px; max-width:400px; width:90%; margin:auto; padding:28px 22px; position:relative; }
    #trackOrderModal button.close { position:absolute; top:10px; right:16px; background:none; border:none; font-size:1.5rem; color:#96783A; cursor:pointer; }
    #trackOrderModal h3 { color:#96783A; margin-bottom:18px; }
    #trackOrderModal #trackOrderContent { margin-top: 10px; }    
   
  </style>
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li class="active-nav"><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.html">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>

  <div class="account-container">
    <!-- Profile Summary -->
    <div class="profile-summary">
      <img src="<?php echo htmlspecialchars($user['avatar'] ?? 'img/avatar-default.png'); ?>" alt="Profile Photo" class="profile-avatar" id="profileAvatar">
      <div class="profile-info">
        <h2 id="profileName"><?php echo htmlspecialchars($user['user_name'] ?? ''); ?></h2>
        <p id="profileEmail"><?php echo htmlspecialchars($user['email'] ?? ''); ?></p>
        <p id="profilePhone"><?php echo htmlspecialchars($user['user_contact'] ?? ''); ?></p>
        <button class="edit-profile-btn" onclick="editProfile()">Edit Profile</button>
      <form action="/Bakery/logout.php" method="post" style="display:inline;">
      <button type="submit" style="background:#BA954D; color:#fff; border:none; border-radius:5px; padding:8px 16px; cursor:pointer;">Logout</button>
    </form>
      </div>
    </div>

    
      <!-- Order/Booking History -->
      <div class="account-card">
        <h3>Order History</h3>
        <table class="order-history-table">
          <thead>
            <tr>
              <th>Order #</th>
              <th>Date</th>
              <th>Status</th>
              <th>Total</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $order): ?>
            <tr>
              <td><?php echo htmlspecialchars($order['order_number']); ?></td>
              <td><?php echo htmlspecialchars($order['order_date']); ?></td>
              <td><?php echo htmlspecialchars(ucfirst($order['status'])); ?></td>
              <td>LKR <?php echo number_format($order['total_amount'], 2); ?></td>
              <td>
                <form method="GET" action="\Bakery\server\track_order.php" style="display:inline;">
                  <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                  <button class="track-btn" type="submit">Track</button>
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($orders)): ?>
            <tr><td colspan="5">No orders found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    
  <!-- Edit Profile Modal -->
  <div id="editProfileModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.4); z-index:1000; align-items:center; justify-content:center;">
    <div style="background:#fff; border-radius:10px; max-width:400px; width:90%; margin:auto; padding:28px 22px; position:relative;">
      <button onclick="closeEditProfile()" style="position:absolute; top:10px; right:16px; background:none; border:none; font-size:1.5rem; color:#96783A; cursor:pointer;">&times;</button>
      <h3 style="color:#96783A; margin-bottom:18px;">Edit Profile</h3>
      <form id="editProfileForm" method="POST" action="server/update_profile.php" enctype="multipart/form-data">
        <label for="editName">Name</label>
        <input type="text" id="editName" name="editName" value="<?php echo htmlspecialchars($user['user_name'] ?? ''); ?>" required>
        <label for="editEmail">Email</label>
        <input type="email" id="editEmail" name="editEmail" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
        <label for="editPhone">Phone</label>
        <input type="tel" id="editPhone" name="editPhone" maxlength="10" value="<?php echo htmlspecialchars($user['user_contact'] ?? ''); ?>" required>
        <label for="editAvatar">Profile Photo</label>
        <input type="file" id="editAvatar" name="editAvatar" accept="image/*">
        <label for="editPassword">New Password</label>
        <input type="password" id="editPassword" name="editPassword" autocomplete="new-password">
        <button type="submit" style="margin-top:14px;">Save Changes</button>
      </form>
    </div>
  </div>

  <!-- Track Order Modal -->
  <div id="trackOrderModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.4); z-index:1001; align-items:center; justify-content:center;">
    <div style="background:#fff; border-radius:10px; max-width:400px; width:90%; margin:auto; padding:28px 22px; position:relative;">
      <button onclick="closeTrackOrder()" style="position:absolute; top:10px; right:16px; background:none; border:none; font-size:1.5rem; color:#96783A; cursor:pointer;">&times;</button>
      <h3 style="color:#96783A; margin-bottom:18px;">Order Tracking</h3>
      <div id="trackOrderContent">
        <!-- Status will be loaded here -->
        <p>Loading...</p>
      </div>
    </div>
  </div>

  <script>
    function editProfile() {
      document.getElementById('editProfileModal').style.display = 'flex';
    }
    function closeEditProfile() {
      document.getElementById('editProfileModal').style.display = 'none';
    }

    function trackOrder(orderId) {
      document.getElementById('trackOrderModal').style.display = 'flex';
      const content = document.getElementById('trackOrderContent');
      content.innerHTML = "<p>Loading...</p>";

      fetch('server/track_order.php?order_id=' + encodeURIComponent(orderId))
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            content.innerHTML = `
              <p><strong>Order #:</strong> ${data.order_number}</p>
              <p><strong>Status:</strong> ${data.status}</p>
              <p><strong>Last Updated:</strong> ${data.updated_at}</p>
              <p><strong>Details:</strong> ${data.details}</p>
            `;
          } else {
            content.innerHTML = `<p style="color:red;">${data.message}</p>`;
          }
        })
        .catch(() => {
          content.innerHTML = "<p style='color:red;'>Could not fetch order status.</p>";
        });
    }

    function closeTrackOrder() {
      document.getElementById('trackOrderModal').style.display = 'none';
    }

    // Optional: Close modal when clicking outside the form
    document.getElementById('editProfileModal').addEventListener('click', function(e) {
      if (e.target === this) closeEditProfile();
    });

    document.getElementById('trackOrderModal').addEventListener('click', function(e) {
      if (e.target === this) closeTrackOrder();
    });
  </script>
</body>
</html>