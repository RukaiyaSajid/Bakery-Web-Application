<?php
session_start();


// Database connection
include('../server/connection.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $preview_text = $_POST['preview_text'];
    $full_content = $_POST['full_content'];
    
    // Handle image upload
    $target_dir = "img/"; // Directory to store images
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // Check if image file is valid
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false) {
        // Generate unique filename
        $new_filename = uniqid() . '.' . $imageFileType;
        $target_path = $target_dir . $new_filename;
        
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_path)) {
            // Insert into database
            $stmt = $conn->prepare("INSERT INTO blog_posts (title, image_path, preview_text, full_content) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $title, $target_path, $preview_text, $full_content);
            
            if ($stmt->execute()) {
                $success_message = "Blog post added successfully!";
            } else {
                $error_message = "Error saving to database: " . $conn->error;
            }
        } else {
            $error_message = "Sorry, there was an error uploading your file.";
        }
    } else {
        $error_message = "File is not an image.";
    }
}

// Get all blog posts for listing
$blog_posts = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Blog Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {min-height: 100vh; 
            background-color: #343a40; 
            position: fixed; 
            top: 0; 
            z-index: 1020;
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover {
            color: rgba(255, 255, 255, 1);
        }
        .main-content {
            padding: 20px;
        }
        .blog-image-preview {
            max-width: 100px;
            max-height: 100px;
        }
        .sidebar .nav-link.active, .sidebar .nav-link:hover { color: #fff; background-color: #495057; }
        .stat-card { min-height: 120px; }
        .low-stock { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar bg-dark">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="admin_blog.php">
                                <i class="fas fa-blog me-2"></i>Blog Posts
                            </a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link " href="admin_products.php">
                            <i class="fas fa-box-open me-2"></i>Products - Cakes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="admin_savory_products.php">
                            <i class="fas fa-drumstick-bite me-2"></i>Products - Savory
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  " href="admin_giftbox_products.php">
                            <i class="fas fa-gift me-2"></i>Products - Giftbox
                        </a>
                    </li>
                        <li class="nav-item">
                        <a class="nav-link" href="admin_tutorial.php">
                            <i class="fas fa-chalkboard-teacher me-2"></i>Tutorials
                        </a>
                    </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="/Bakery/admin_logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <h2 class="my-4">Blog Management</h2>
                
                <!-- Success/Error Messages -->
                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>
                <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <!-- Add New Blog Post Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Add New Blog Post</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <input type="text" class="form-control" id="title" name="title" required>
                            </div>
                            <div class="mb-3">
                                <label for="image" class="form-label">Featured Image</label>
                                <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                            </div>
                            <div class="mb-3">
                                <label for="preview_text" class="form-label">Preview Text</label>
                                <textarea class="form-control" id="preview_text" name="preview_text" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="full_content" class="form-label">Full Content</label>
                                <textarea class="form-control" id="full_content" name="full_content" rows="10" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Publish Post</button>
                        </form>
                    </div>
                </div>

                <!-- Existing Blog Posts -->
                <div class="card">
                    <div class="card-header">
                        <h5>Existing Blog Posts</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($post = $blog_posts->fetch_assoc()): ?>
                                    <tr>
                                        <td><img src="<?php echo $post['image_path']; ?>" class="blog-image-preview"></td>
                                        <td><?php echo $post['title']; ?></td>
                                        <td><?php echo date('M d, Y', strtotime($post['created_at'])); ?></td>
                                        <td>
                                            <a href="edit_blog.php?id=<?php echo $post['blog_id']; ?>" class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <a href="delete_blog.php?id=<?php echo $post['blog_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this post?');">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>