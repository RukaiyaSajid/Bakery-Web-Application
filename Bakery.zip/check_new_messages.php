<?php
require_once '../includes/config.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

$sessionId = $_GET['session_id'] ?? '';

if (empty($sessionId)) {
    echo json_encode(['success' => false, 'error' => 'Missing session ID']);
    exit;
}

$sql = "SELECT COUNT(*) as count FROM chat_messages WHERE session_id = ? AND type = 'bot' AND is_read = 0";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $sessionId);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

echo json_encode([
    'success' => true,
    'hasNewMessages' => $row['count'] > 0,
    'count' => $row['count']
]);
?>