<?php session_start(); ?>
<?php
require_once 'tutorial_functions.php';
$upcomingTutorials = getUpcomingTutorials();
$recordedTutorials = getRecordedTutorials();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tutorial</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="styles.css">  

<style>
  
.counter {
    background-color: #e74c3c;
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-weight: bold;
}

nav ul {
    display: flex;
    list-style: none;
}

nav ul li {
    margin-left: 1.5rem;
}

nav ul li a {
    color: white;
    text-decoration: none;
    transition: color 0.3s;
}

nav ul li a:hover {
    color: #BA954D;
}

main {
    padding: 2rem;
}

.tutorials-section h1 {
    font-size: 2.5rem;
    margin-bottom: 2rem;
    color: #2c3e50;
    text-align: center;
}

.upcoming-tutorials, .recorded-tutorials {
    background-color: white;
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.upcoming-tutorials h2, .recorded-tutorials h2 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: #BA954D;
    display: inline-block;
}

.join-button {
    background-color: #2ecc71;
    color: white;
    border: none;
    padding: 0.5rem 1.5rem;
    border-radius: 4px;
    float: right;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.3s;
}

.join-button:hover {
    background-color: #27ae60;
}

.tutorial-list {
    margin-top: 1.5rem;
}

.tutorial-item {
    background-color: #f9f9f9;
    padding: 1rem;
    margin-bottom: 1rem;
    border-radius: 4px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-left: 4px solid #BA954D;
}

.tutorial-item h3 {
    font-size: 1.2rem;
    color: #2c3e50;
}

.play-button {
    background-color: #BA954D;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.play-button:hover {
    background-color: #96783A;
}

.live-badge {
    background-color: #e74c3c;
    color: white;
    padding: 0.3rem 0.6rem;
    border-radius: 4px;
    font-size: 0.8rem;
    font-weight: bold;
}

.copyright {
    font-size: 0.9rem;
    opacity: 0.8;
}

/* Video modal styles */
.video-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    z-index: 1000;
    justify-content: center;
    align-items: center;
}

.modal-content {
    background-color: white;
    padding: 1rem;
    border-radius: 8px;
    width: 80%;
    max-width: 800px;
    position: relative;
}

.close-modal {
    position: absolute;
    top: 10px;
    right: 15px;
    font-size: 1.5rem;
    cursor: pointer;
    color: #333;
}

/* Responsive styles */
@media (max-width: 768px) {
    header {
        flex-direction: column;
        text-align: center;
    }
    
    .logo, .counter {
        margin-bottom: 1rem;
    }
    
    nav ul {
        flex-direction: column;
        align-items: center;
    }
    
    nav ul li {
        margin: 0.5rem 0;
    }
    
    .join-button {
        float: none;
        display: block;
        margin: 1rem auto;
    }
    
    .tutorial-item {
        flex-direction: column;
        text-align: center;
    }
    
    .play-button {
        margin-top: 0.5rem;
    }
}
</style>
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li class="active-nav"><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.php">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>

<main>
        <section class="tutorials-section">
            <h1>TUTORIALS</h1>
            

            <div class="upcoming-tutorials">
                <h2>UP COMING SESSIONS</h2>
                <?php 
                $zoomLink = '';
                $scheduledTime = '';
                if (!empty($upcomingTutorials)) {
                    // Use the first upcoming tutorial for the join button
                    $firstTutorial = $upcomingTutorials[0];
                    $zoomLink = isset($firstTutorial['zoom_link']) ? $firstTutorial['zoom_link'] : '';
                    $scheduledTime = isset($firstTutorial['scheduled_time']) ? $firstTutorial['scheduled_time'] : '';
                }
                ?>
                <button class="join-button" 
                    data-zoom-link="<?php echo htmlspecialchars($zoomLink); ?>" 
                    data-scheduled-time="<?php echo htmlspecialchars($scheduledTime); ?>">
                    JOIN
                </button>
                
                <?php if (!empty($upcomingTutorials)): ?>
                    <div class="tutorial-list">
                        <?php foreach ($upcomingTutorials as $tutorial): ?>
                            <div class="tutorial-item">
                                <h3><?php echo htmlspecialchars($tutorial['name']); ?></h3>
                                <?php if ($tutorial['is_live']): ?>
                                    <span class="live-badge">LIVE</span>
                                <?php elseif ($tutorial['scheduled_time']): ?>
                                    <p>Scheduled: <?php echo date('M j, Y H:i', strtotime($tutorial['scheduled_time'])); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>No upcoming tutorials scheduled.</p>
                <?php endif; ?>
            </div>
            
            <div class="recorded-tutorials">
                <h2>RECORDED TUTORIALS</h2>
                
                <?php if (!empty($recordedTutorials)): ?>
                    <div class="tutorial-list">
                        <?php foreach ($recordedTutorials as $tutorial): ?>
                            <div class="tutorial-item">
                                <h3><?php echo htmlspecialchars($tutorial['name']); ?></h3>
                                <button class="play-button" data-video="<?php echo htmlspecialchars($tutorial['recording_path']); ?>">PLAY</button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>No recorded tutorials available.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>

<?php include 'chatbot.php'; ?>


    <div class="video-modal" id="video-modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <video controls id="modal-video-player" style="width: 100%;">
                Your browser does not support the video tag.
            </video>
        </div>
    </div>
    <footer>
  <div class="footer-links">
    <a href="refund.html">Refund Policy</a>
    <a href="term.html">Terms & Conditions</a>
    <a href="privacy.html">Privacy Policy</a>
  </div>
  <div class="footer-social">
    <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
  </div>
  <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
</footer>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    // Video modal functionality
    const playButtons = document.querySelectorAll('.play-button');
    const videoModal = document.getElementById('video-modal');
    const videoPlayer = document.getElementById('modal-video-player');
    const closeModal = document.querySelector('.close-modal');
    
    playButtons.forEach(button => {
        button.addEventListener('click', function() {
            const videoSrc = this.getAttribute('data-video');
            videoPlayer.src = videoSrc;
            videoModal.style.display = 'flex';
            videoPlayer.play();
        });
    });
    
    closeModal.addEventListener('click', function() {
        videoPlayer.pause();
        videoModal.style.display = 'none';
    });
    
    window.addEventListener('click', function(event) {
        if (event.target === videoModal) {
            videoPlayer.pause();
            videoModal.style.display = 'none';
        }
    });
    
    // Join button functionality for live sessions
    const joinButton = document.querySelector('.join-button');
    if (joinButton) {
        joinButton.addEventListener('click', function() {
            const zoomLink = this.getAttribute('data-zoom-link');
            const scheduledTime = this.getAttribute('data-scheduled-time');
            if (!zoomLink) {
                showWaitingRoom('No session link available.');
                return;
            }
            const now = new Date();
            const sessionTime = new Date(scheduledTime);
            if (scheduledTime && now >= sessionTime) {
                // Session started, redirect to Zoom
                window.location.href = zoomLink;
            } else {
                // Not started yet, show waiting room
                showWaitingRoom('Session is not started yet. Please wait for the host to start the session.');
            }
        });
    }

    // Waiting room modal
    function showWaitingRoom(message) {
        let waitingModal = document.getElementById('waiting-modal');
        if (!waitingModal) {
            waitingModal = document.createElement('div');
            waitingModal.id = 'waiting-modal';
            waitingModal.style.position = 'fixed';
            waitingModal.style.top = '0';
            waitingModal.style.left = '0';
            waitingModal.style.width = '100%';
            waitingModal.style.height = '100%';
            waitingModal.style.background = 'rgba(0,0,0,0.7)';
            waitingModal.style.display = 'flex';
            waitingModal.style.justifyContent = 'center';
            waitingModal.style.alignItems = 'center';
            waitingModal.style.zIndex = '2000';
            waitingModal.innerHTML = `<div style="background:#fff;padding:2rem 3rem;border-radius:8px;text-align:center;max-width:90vw;">
                <h2>Waiting Room</h2>
                <p id="waiting-message">${message}</p>
                <button id="close-waiting-modal" style="margin-top:1rem;padding:0.5rem 1.5rem;background:#BA954D;color:#fff;border:none;border-radius:4px;cursor:pointer;">Close</button>
            </div>`;
            document.body.appendChild(waitingModal);
            document.getElementById('close-waiting-modal').onclick = function() {
                waitingModal.style.display = 'none';
            };
        } else {
            document.getElementById('waiting-message').textContent = message;
            waitingModal.style.display = 'flex';
        }
    }
    
    // Simulate visitor counter (in a real app, this would come from a database)
    let counter = 10000;
    const counterElement = document.querySelector('.counter');
    
    setInterval(() => {
        counter += Math.floor(Math.random() * 3);
        counterElement.textContent = counter;
    }, 5000);
});  
    </script>
</body>
</html>