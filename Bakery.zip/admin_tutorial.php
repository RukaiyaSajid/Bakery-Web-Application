<?php
session_start();
include('../server/connection.php');

// Fetch tutorials
$live_sessions = $conn->query("SELECT * FROM tutorials WHERE is_live=1 ORDER BY scheduled_time DESC");
$recorded_videos = $conn->query("SELECT * FROM tutorials WHERE is_live=0 ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Manage Tutorials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .sidebar {min-height: 100vh; background-color: #343a40; position: fixed; top: 0; z-index: 1020;}
        .sidebar .nav-link { color: rgba(255,255,255,0.75); }
        .sidebar .nav-link.active, .sidebar .nav-link:hover { color: #fff; background-color: #495057; }
        .main-content { padding: 40px 20px 20px 20px; }
        .tutorial-section { background: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); padding: 24px; margin-bottom: 24px; }
        .table th, .table td { vertical-align: middle; }
        @media (max-width: 991px) {
            .main-content { padding: 20px 5px; }
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar Navigation -->
        <nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar py-4">
            <div class="position-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item mb-2">
                        <a class="nav-link" href="admin_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_blog.php">
                            <i class="fas fa-blog me-2"></i>Blog Posts
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_products.php">
                            <i class="fas fa-box-open me-2"></i>Products - Cakes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_savory_products.php">
                            <i class="fas fa-drumstick-bite me-2"></i>Products - Savory
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_giftbox_products.php">
                            <i class="fas fa-gift me-2"></i>Products - Giftbox
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active text-white" href="admin_tutorial.php">
                            <i class="fas fa-chalkboard-teacher me-2"></i>Tutorials
                        </a>
                    </li>
                    <li class="nav-item mt-3">
                        <a class="nav-link text-danger" href="/Bakery/admin_logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 main-content">
            <div class="container-fluid">
                <h2 class="mb-4">Manage Tutorials</h2>
                <div class="row g-4">
                    <div class="col-lg-6">
                        <div class="tutorial-section">
                            <h4 class="mb-3">Live Sessions</h4>
                            <a href="add_tutorial.php?type=live" class="btn btn-success btn-sm mb-2"><i class="fas fa-plus"></i> Add Live Session</a>
                            <table class="table table-bordered table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Scheduled Time</th>
                                        <th>Zoom Link</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php while($row = $live_sessions->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['scheduled_time']); ?></td>
                                        <td><a href="<?php echo htmlspecialchars($row['zoom_link']); ?>" target="_blank">Join</a></td>
                                        <td>
                                            <a href="edit_tutorial.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <a href="delete_tutorial.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this session?')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="tutorial-section">
                            <h4 class="mb-3">Recorded Tutorials</h4>
                            <a href="add_tutorial.php?type=recorded" class="btn btn-success btn-sm mb-2"><i class="fas fa-plus"></i> Add Recorded Video</a>
                            <table class="table table-bordered table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Video Path</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php while($row = $recorded_videos->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><a href="<?php echo htmlspecialchars($row['recording_path']); ?>" target="_blank">View</a></td>
                                        <td>
                                            <a href="edit_tutorial.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <a href="delete_tutorial.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this video?')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>