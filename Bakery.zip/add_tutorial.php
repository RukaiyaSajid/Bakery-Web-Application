<?php
session_start();
include('../server/connection.php');

$type = $_GET['type'] ?? 'live';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $is_live = $_POST['is_live'];
    $scheduled_time = $_POST['scheduled_time'] ?? null;
    $zoom_link = $_POST['zoom_link'] ?? null;
    $recording_path = $_POST['recording_path'] ?? null;

    if (!$name) $errors[] = "Name is required.";
    if ($is_live && !$scheduled_time) $errors[] = "Scheduled time required for live.";
    if ($is_live && !$zoom_link) $errors[] = "Zoom link required for live.";
    if (!$is_live && !$recording_path) $errors[] = "Recording path required for recorded.";

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO tutorials (name, is_live, scheduled_time, zoom_link, recording_path, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("sisss", $name, $is_live, $scheduled_time, $zoom_link, $recording_path);
        $stmt->execute();
        header("Location: admin_tutorial.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Tutorial</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Add <?php echo $type === 'live' ? 'Live Session' : 'Recorded Video'; ?></h2>
    <a href="admin_tutorial.php" class="btn btn-secondary mb-3">Back</a>
    <?php if ($errors): ?>
        <div class="alert alert-danger"><?php echo implode('<br>', $errors); ?></div>
    <?php endif; ?>
    <form method="post">
        <input type="hidden" name="is_live" value="<?php echo $type === 'live' ? 1 : 0; ?>">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <?php if ($type === 'live'): ?>
            <div class="mb-3">
                <label>Scheduled Time</label>
                <input type="datetime-local" name="scheduled_time" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Zoom Link</label>
                <input type="url" name="zoom_link" class="form-control" required>
            </div>
        <?php else: ?>
            <div class="mb-3">
                <label>Recording Path (URL or file path)</label>
                <input type="text" name="recording_path" class="form-control" required>
            </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-success">Add</button>
    </form>
</div>
</body>
</html>