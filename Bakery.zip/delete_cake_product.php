<?php
// filepath: c:\xampp\htdocs\Bakery\admindashboard\delete_cake_product.php
session_start();

require_once '../server/connection.php';
$id = intval($_POST['products_id'] ?? 0);
if ($id) {
    $conn->query("DELETE FROM products WHERE products_id=$id");
    $_SESSION['success'] = "Cake product deleted successfully!";
}
header("Location: admin_products.php");
exit;