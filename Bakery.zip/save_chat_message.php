<?php
require_once '../includes/config.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$sessionId = $input['session_id'] ?? '';
$message = $input['message'] ?? '';
$type = $input['type'] ?? '';
$userId = $input['user_id'] ?? null;

if (empty($sessionId) || empty($message) || empty($type)) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

$sql = "INSERT INTO chat_messages (session_id, user_id, message, type, created_at) VALUES (?, ?, ?, ?, NOW())";
$stmt = $conn->prepare($sql);
$stmt->bind_param("siss", $sessionId, $userId, $message, $type);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to save message']);
}
?>