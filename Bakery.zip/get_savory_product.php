<?php
// Include the database connection
include('connection.php');

$stmt = $conn->prepare("SELECT products_id, products_name, products_image, products_price FROM products Where category='savory'");

$stmt->execute();

$products = $stmt->get_result();


