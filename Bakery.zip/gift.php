<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Products - Gift Box</title>
  <link rel="icon" href="img/favicon.ico">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="styles.css">

  <style>
    /* General Styling */
    body, html {
  font-family: 'Segoe UI', 'Arial', 'sans-serif';
}

    .container {
      margin: 120px auto;
      width: 90%;
      max-width: 1200px;
    }


    .nav-links {
      list-style: none;
      display: flex;
      gap: 15px;
      margin: 0;
      padding: 0;
      position: relative;
    }

    .nav-links li {
      position: relative;
    }

    .nav-links a {
      text-decoration: none;
      color: black;
      padding: 10px 15px;
      display: block;
    }

    .nav-links a:hover {
      color: #BA954D;
    }
    .container {
      margin: 120px auto;
      width: 90%;
      max-width: 1200px;
    }

   h1 {
      font-size: 24px;
      text-align: center;
      margin-bottom: 20px;
    }
    .tabs {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
    }

    .tabs a {
      text-decoration: none;
      color: black;
      padding: 10px 20px;
      font-weight: bold;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin: 0 5px;
    }

  
    .product-tabs {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
    }

    .product-tabs a {
      text-decoration: none;
      color: black;
      font-weight: bold;
      padding: 10px 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin: 0 5px;

    }

    .product-tabs a:hover {
      background-color: #BA954D;
      color: white;
    }

    .steps-container {
      display: flex;
      justify-content: space-between;
      margin-top: 40px;
    }

    /* Progress Bar */
    .progress-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: relative;
      margin-bottom: 30px;
    }

    .progress-bar::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 0;
      transform: translateY(-50%);
      width: 100%;
      height: 5px;
      background-color: #ddd;
      z-index: 0;
    }

    .progress-bar .progress {
      position: absolute;
      top: 50%;
      left: 0;
      transform: translateY(-50%);
      height: 5px;
      background-color: #BA954D;
      z-index: 1;
      width: 0%;
      transition: width 0.4s ease;
    }

    .step {
      z-index: 2;
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 33%;
    }

    .step .circle {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background-color: #ddd;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 5px;
    }

    .step.active .circle,
    .step.completed .circle {
      background-color: #BA954D;
    }

    .step .label {
      font-size: 14px;
      color: #777;
    }

    .step.active .label,
    .step.completed .label {
      color: #BA954D;
    }

    /* Step Content */
    .step-content {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      display: none;
    }

    .step-content.active {
      display: block;
    }

    .buttons {
  display: flex;
  align-items: center;
  background-color: #fff;
  padding: 10px 20px;
  border-bottom: 1px solid #ddd;
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
  justify-content: space-between;
    }

    .buttons button {
      padding: 10px 20px;
      margin-right: 40px;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      background-color: #BA954D;
      color: white;
    }

    .buttons button:hover {
      background-color: #96783A;
    }

    .buttons button:disabled {
      background-color: #ddd;
      cursor: not-allowed;
    }

    .quantity-controls {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 10px;
      margin: 10px 0;
    }

    .quantity-controls button {
      background-color: #BA954D;
      color: white;
      border: none;
      padding: 5px 10px;
      border-radius: 5px;
      cursor: pointer;
      transition: 0.3s;
    }

    .quantity-controls button:hover {
      background-color: #96783A;
    }

    .quantity-controls span {
      font-size: 14px;
      font-weight: bold;
    }

    .add-button {
      background-color: #BA954D;
      color: white;
      border: none;
      padding: 8px 15px;
      border-radius: 5px;
      cursor: pointer;
      margin-top: 10px;
      display: block;
      margin-left: auto;
      margin-right: auto;
    }

    .add-button:hover {
      background-color: #96783A;
    }
    .card-section {
      text-align: left;
      margin: 20px 0;
      border: solid 1px #ddd;
      border-radius: 8px;
    }

    .card-section h3 {
      margin-bottom: 10px;
      padding-left: 20px;
    }

    .card-section img {
      width: 100px;
      height: 100px;
      margin: 20px;
      border: 1px solid #ddd;
      border-radius: 5px;
      cursor: pointer;
      transition: 0.3s;
    }

    .card-section img.selected {
      border-color: #BA954D;
    }

    .message-section {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      margin: 20px;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
    }

    .message-section h3 {
      font-size: 14px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .message-section textarea {
      width: 100%;
      max-width: 820px;
      height: 80px;
      border: none;
      background-color: #f1f1f1;
      padding: 10px;
      font-size: 14px;
      border-radius: 5px;
      outline: none;
      resize: none;
    }
.delivery{
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      margin: 20px;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
}
#delivery-date{
      width: 100%;
      max-width: 820px;
      height: 80px;
      border: none;
      background-color: #f1f1f1;
      padding: 10px;
      font-size: 14px;
      border-radius: 5px;
      outline: none;
      resize: none;
}
    .next-button {
      background-color: #BA954D;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      margin: 40px auto;
      display: block;
    }

    .next-button:hover {
      background-color: #96783A;
    }
    /* Scrollbar styles */
::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
    background: #BA954D;
}

  
  </style>
</head>
<body>

  <!-- Header -->
  <header>
    <nav class="navbar">
        <div class="logo">  
            <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
           </div>  
      <ul class="nav-links">
        <li><a href="home.php">Home </a></li>
        <li class="active-link">
          <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Products</a>
          <div class="dropdown">
            <a href="Products- cakes.php">Cake</a>
            <a href="Products- savory.php">Savory</a>
            <a href="gift.php">Giftbox</a>
            <a href="customize.php">Customize</a>
          </div>
        </li>            
        <li><a href="tutorial.php">Tutorials </a></li>
        <li><a href="blog.php">Blog </a></li>
        <li><a href="about.php">About Us </a></li>
        <li><a href="contact.php">Contact Us </a></li>
      </ul>
      <div class="icons">
        <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>        
          <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
          
        </div>
      </div>    
    </nav>
  </header>

  <!-- Main Content -->
  <div class="container">
    <h1>Products - Gift Box</h1>
    <div class="product-tabs">
      <a href="Products- cakes.html">Cakes</a>
      <a href="Products- savory.html">Savories</a>
      <a href="gift.html" style="background-color: #96783A; color: #fff;">Gift Box</a>
      <a href="customize.html">Customize</a>
    </div>

    <p>Customize your one-of-a-kind gift box in 3 simple steps! We’ll pack your gifts with exceptional care, handwritten messages, and deliver to anywhere in Sri Lanka. The box size will be determined by the number/size of gift items selected. Simply scroll down and add gift items to your box. You are required to add at least 3 and up to 10 products.</p>

    <div class="step-container">
      <!-- Progress Bar -->
      <div class="progress-bar">
        <div class="progress"></div>
        <div class="step active" data-step="1">
          <div class="circle">1</div>
          <div class="label">Select Gift Items</div>
        </div>
        <div class="step" data-step="2">
          <div class="circle">2</div>
          <div class="label">Select a Card</div>
        </div>
        <div class="step" data-step="3">
          <div class="circle">3</div>
          <div class="label">Select Delivery Date</div>
        </div>
      </div>

      <!-- Step Content -->
      <div class="step-content active" id="step-1">
        <h2>Step 1: Select Gift Items</h2>
        <p>Customize your gift box by selecting items from the catalog.</p>
        <div class="container">
          <div class="filters">
            <select id="filter-category">
              <option value="all">All Categories</option>
              <option value="snacks">Snacks</option>
              <option value="chocolates">Chocolates</option>
              <option value="cake">Cakes</option>
              <option value="savory">Savories</option>
            </select>
            <input type="text" id="search-input" placeholder="Search for products...">
          </div>
          <div class="selected-items" id="selected-products"></div>
          <div id="reset-container" style="display: none;">
            <button class="reset-btn" id="reset-btn">Reset</button>
          </div>
          <div class="products" id="products"></div>
        </div>
        <div id="message-container" style="display: flex;
      justify-content: center;
      align-items: center;
      position: fixed; /* Make sure it appears on top */
      top: 80%; /* Center vertically */
      left: 50%; /* Center horizontally */
      transform: translate(-50%, -50%); /* Adjust the position by 50% of its own width/height */
      padding: 20px;
      text-align: center;
      opacity: 0.7;
      z-index: 1000; ">
        <p id="message-text" style="font-size: 16px; font-weight: bold; padding: 10px;"></p>
      </div>

      </div>
  
      <div class="step-content" id="step-2">
        <h2>Step 2: Select a Card</h2>
        <p>Choose a card to include with your gift box.</p>
        <div class="card-section">
          <h3>Select a Card <span style="color: red;">*</span></h3>
          <img src="img/p1.jpg" alt="Card 1" data-card="1">
          <img src="img/p2.jpg" alt="Card 2" data-card="2">
          <img src="img/p3.jpg" alt="Card 3" data-card="3">
          <img src="img/p4.png" alt="Card 4" data-card="4">
          <img src="img/p5.png" alt="Card 5" data-card="5">
          <img src="img/p6.png" alt="Card 6" data-card="6">
          <img src="img/p7.png" alt="Card 7" data-card="7">
          <img src="img/p8.png" alt="Card 8" data-card="8">
        </div>
        <div class="message-section">
          <h3>Greeting Card Message (Leave blank if you wish to write it yourself)</h3>
          <textarea rows="4" cols="50"></textarea>
        </div>
      </div>

      <div class="step-content" id="step-3">
        <h2>Step 3: Select Delivery Date</h2>
        <p>Choose the delivery date for your gift box.</p>
        <div class="delivery">
          <input type="date" id="delivery-date">
        </div>
      </div>

      <!-- Navigation Buttons -->
      <div class="buttons">
        <button id="prev-btn" disabled>Previous</button>
        <button id="next-btn">Next</button>
      </div>
    </div>
  </div>

  <?php
require_once 'server/connection.php';
$products = [];
$result = $conn->query("SELECT * FROM giftbox_products WHERE status='active' ORDER BY giftbox_product_id DESC");
while ($row = $result->fetch_assoc()) {
    $products[] = [
        'id' => (int)$row['giftbox_product_id'],
        'name' => $row['name'],
        'category' => $row['category'],
        'price' => (float)$row['price'],
        'image' => 'img/' . $row['image']
    ];
}
?>

  <script>
    let currentStep = 1;
    const steps = document.querySelectorAll('.step');
    const stepContents = document.querySelectorAll('.step-content');
    const progress = document.querySelector('.progress');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const productContainer = document.getElementById('products');
    const selectedProductsContainer = document.getElementById('selected-products');
    const filterCategory = document.getElementById('filter-category');
    const searchInput = document.getElementById('search-input');
    const resetContainer = document.getElementById('reset-container');
    const resetBtn = document.getElementById('reset-btn');

    let selectedProducts = [];
    const products = <?php echo json_encode($products); ?>;


    function renderProducts() {
      productContainer.innerHTML = "";
      const searchText = searchInput.value.toLowerCase();
      const category = filterCategory.value;
      const filteredProducts = products.filter(product => {
        return (
          (category === "all" || product.category === category) &&
          product.name.toLowerCase().includes(searchText)
        );
      });
      filteredProducts.forEach(product => {
        const productEl = document.createElement("div");
        productEl.className = "product";
        productEl.innerHTML = `
          <img src="${product.image}" alt="${product.name}">
          <h4>${product.name}</h4>
          <p>Price: LKR ${product.price}</p>
          <button onclick="addToSelected(${product.id})">Add</button>
        `;
        productContainer.appendChild(productEl);
      });
    }

    function renderSelectedProducts() {
      selectedProductsContainer.innerHTML = "";
      selectedProducts.forEach(product => {
        const selectedEl = document.createElement("div");
        selectedEl.className = "selected-item";
        selectedEl.innerHTML = `
          <span class="quantity">${product.quantity}</span>
          <img src="${product.image}" alt="${product.name}">
          <button class="remove" onclick="removeFromSelected(${product.id})">&times;</button>
          <div class="quantity-controls">
            <button onclick="decreaseQuantity(${product.id})">-</button>
            <button onclick="increaseQuantity(${product.id})">+</button>
          </div>
        `;
        selectedProductsContainer.appendChild(selectedEl);
      });
      resetContainer.style.display = selectedProducts.length > 0 ? "block" : "none";
    }

    function addToSelected(productId) {
      const product = products.find(p => p.id === productId);
      const exists = selectedProducts.find(p => p.id === productId);
      if (exists) {
        exists.quantity += 1;
      } else {
        selectedProducts.push({ ...product, quantity: 1 });
      }
      renderSelectedProducts();
    }

    function increaseQuantity(productId) {
      const product = selectedProducts.find(p => p.id === productId);
      product.quantity += 1;
      renderSelectedProducts();
    }

    function decreaseQuantity(productId) {
      const product = selectedProducts.find(p => p.id === productId);
      if (product.quantity > 1) {
        product.quantity -= 1;
      } else {
        removeFromSelected(productId);
      }
      renderSelectedProducts();
    }

    function removeFromSelected(productId) {
      selectedProducts = selectedProducts.filter(p => p.id !== productId);
      renderSelectedProducts();
    }

    // Reset all selected items
    resetBtn.addEventListener("click", () => {
      selectedProducts = [];
      renderSelectedProducts();
    });

    // Handle step navigation and include delivery date validation in Step 3
    function updateSteps() {
      steps.forEach((step, index) => {
        const stepIndex = index + 1;
        step.classList.toggle('active', stepIndex === currentStep);
        step.classList.toggle('completed', stepIndex < currentStep);
      });
      stepContents.forEach(content => {
        content.classList.toggle('active', content.id === `step-${currentStep}`);
      });
      prevBtn.disabled = currentStep === 1;
      nextBtn.textContent = currentStep === steps.length ? 'Finish' : 'Next';
      const progressWidth = ((currentStep - 1) / (steps.length - 1)) * 100;
      progress.style.width = `${progressWidth}%`;
    }

    const messageContainer = document.getElementById("message-container");
    const messageText = document.getElementById("message-text");

    function showMessage(message, type) {
      const colors = { warning: "white", info: "white" };
      const background = { warning: "red", info: "black" };
      messageText.textContent = message;
      messageText.style.color = colors[type];
      messageText.style.backgroundColor = background[type];
      messageContainer.style.display = "block";
      setTimeout(() => {
        messageContainer.style.display = "none";
      }, 3000);
    }

    nextBtn.addEventListener("click", () => {
      if (currentStep === 1) {
        if (selectedProducts.length < 3) {
          showMessage("⚠ At least choose 3 items", "warning");
          return;
        }
      }
      // Step 3: Validate delivery date for same-day orders if after noon
      if (currentStep === 3) {
        const deliveryDateInput = document.getElementById("delivery-date").value;
        if (deliveryDateInput) {
          const selectedDate = new Date(deliveryDateInput);
          const today = new Date();
          if (
            selectedDate.getFullYear() === today.getFullYear() &&
            selectedDate.getMonth() === today.getMonth() &&
            selectedDate.getDate() === today.getDate()
          ) {
            if (today.getHours() >= 12) {
              alert("Your order can not be placed for this day", "warning");
              return;
            }
          }
        }
      }
      if (currentStep < steps.length) {
        currentStep++;
        updateSteps();
      } else {
        // Final step: "Finish" button pressed
            // Get selected card number
    const selectedCard = document.querySelector('.card-section img.selected');
    const cardNumber = selectedCard ? selectedCard.getAttribute('data-card') : null;
    // Get greeting message
    const greetingMessage = document.querySelector('.message-section textarea').value;

    // Get delivery date
    const deliveryDate = document.getElementById("delivery-date").value;

    // Calculate total price
    const totalPrice = selectedProducts.reduce((sum, item) => sum + item.price * item.quantity, 0);
    // Save the gift pack details to localStorage
    const giftPack = {
      name: "Giftbox",
      items: selectedProducts,
      cardNumber: cardNumber,
      greetingMessage: greetingMessage,
      deliveryDate: deliveryDate,
      price: totalPrice,
      quantity: 1
    };
    localStorage.setItem("giftPack", JSON.stringify(giftPack));
// Update cart icon
    document.querySelector('.cart-quantity').textContent = 1;
      addGiftboxToCart(); // Send to cart.php
        // Calculate total gift packs and update the cart icon
        document.querySelector('.cart-quantity').textContent = 1; // Only 1 gift pack is added

      }
    });

    prevBtn.addEventListener('click', () => {
      if (currentStep > 1) {
        currentStep--;
        updateSteps();
      }
    });

    // Initialize the page
    renderProducts();
    updateSteps();

    // Add card selection functionality
    const cards = document.querySelectorAll('.card-section img');
    cards.forEach(card => {
      card.addEventListener('click', () => {
        cards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
      });
    });

// Add event listeners to filter and search inputs
filterCategory.addEventListener('change', renderProducts);
searchInput.addEventListener('input', renderProducts);

// Filter products based on the selected category and search input
function renderProducts() {
  productContainer.innerHTML = ""; // Clear the existing products
  const searchText = searchInput.value.toLowerCase(); // Get the search query
  const category = filterCategory.value; // Get the selected category
  
  // Filter products based on category and search text
  const filteredProducts = products.filter(product => {
    return (
      (category === "all" || product.category === category) && // Check category
      product.name.toLowerCase().includes(searchText) // Check search query
    );
  });
  
  // Display the filtered products
  filteredProducts.forEach(product => {
    const productEl = document.createElement("div");
    productEl.className = "product";
    productEl.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <h4>${product.name}</h4>
      <p>Price: LKR ${product.price}</p>
      <button onclick="addToSelected(${product.id})">Add</button>
    `;
    productContainer.appendChild(productEl);
  });
}

// In gift.php or where your Finish button is rendered
document.getElementById('finish-btn').addEventListener('click', function() {
    addGiftboxToCart();
});
function addGiftboxToCart() {
    // Get the giftPack from localStorage
    const giftPack = JSON.parse(localStorage.getItem('giftPack'));
    if (!giftPack) return;

    const formData = new FormData();
    formData.append('add_giftbox_to_cart', '1');
    formData.append('giftPack', JSON.stringify(giftPack));

    fetch('cart.php', {
        method: 'POST',
        body: formData
    }).then(() => {
        window.location.href = 'cart.php';
    });
}

</script>


</body>
</html>
