    // Array of banner image URLs
    const bannerImages = [
      'img/chocolate-cake-with-dried-fruit.jpg',
      'img/pie.jpg',
      'img/pizza.jpg',
      'img/bun.jpg'
    ];

    let currentImageIndex = 0;
    const bannerElement = document.querySelector('.banner img');

    // Preload images
    bannerImages.forEach((image) => {
      const img = new Image();
      img.src = image;
    });

    // Set the first image immediately
    bannerElement.src = bannerImages[currentImageIndex];

    // Function to change the banner image
    function changeBannerImage() {
      currentImageIndex = (currentImageIndex + 1) % bannerImages.length; // Loop through the images
      bannerElement.src = bannerImages[currentImageIndex];
    }

    // Change the banner image every 5 seconds
    setInterval(changeBannerImage, 5000);



let cartCount = 0;



  