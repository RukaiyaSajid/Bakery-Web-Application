<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Products - Savory</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
  <style>
    .search-area {
      align-items: center;
      background-color: #fff;
      display: flex;
      justify-content: center;
      padding: 40px;
      margin-top: 20px;
      margin-bottom: 10px;
    }

    #searchInput {
      height: 40px;
      max-width: 650px;
      width: 75%;
      flex: 1;
      padding: 5px 12px;
      border: none;
      border-radius: 20px;
      border: 1px solid #ccc;
    }

    #searchIcon {
      border-radius: 50%;
      margin-left: 20px;
      padding: 5px 5px;
      justify-content: center;
      background-color: #BA954D;
      cursor: pointer;
      width: 30px;
      height: 30px;
      transition: 0.6s;
    }

    #searchIcon:hover {
      background-color: #cfcfcfc0;
    }
    .cover-image {
            position: relative;
            width: 100%;
            height: 300px; 
            overflow: hidden;
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .cover-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .titletext {
            color: #ffffff;
            position: absolute;
            top: 60%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 70px;
            font-weight: bold;
        }

    .products-container {
      padding: 20px;
      margin: 80px auto;
      text-align: center;
    }

    .product-categories {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
    }

    .product-categories a {
      text-decoration: none;
      color: #BA954D;
      font-weight: bold;
      padding: 10px 20px;
      border: 1px solid #BA954D;
      border-radius: 5px;
    }

    .product-categories a:hover {
      background-color: #BA954D;
      color: white;
    }

    .product-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin-top: 20px;
    }

    .product-item {
      background-color: white;
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 15px;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .product-item img {
      width: 100px;
      height: 100px;
      object-fit: cover;
      margin-bottom: 10px;
    }

    .product-item p {
      margin: 5px 0;
    }

    .product-item button {
      background-color: #BA954D;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      cursor: pointer;
      margin-top: 10px;
    }
    .product-grid  a{
      text-decoration: none;
      color: #000;
    }
    .product-item button:hover {
      background-color: #96783A;
    }

    
  

  </style>
    
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.php">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>

      </div>
    </div>    
  </nav>
</header>

      <div class="cover-image">
        <img src="img/sav.jpg" alt="Cover Image">
        <div class="titletext">Products
        </div>
      </div>

      <div class="search-area">
        <input type="text" id="searchInput" placeholder="Search by keyword...">
        <img src="img/search.png" alt="Search" id="searchIcon">
      </div>

<div class="products-container">
  <div class="product-categories">
    <a href="Products- cakes.php">Cakes</a>
    <a href="#" style="background-color: #96783A; color: #fff;">Savories</a>
    <a href="gift.html">Gift Box</a>
    <a href="customize.html">Customize</a>
  </div>

  <div class="product-grid">
  <?php include('server/get_savory_product.php') ?>

<?php while($row = $products->fetch_assoc()){ ?>

  <div class="product-item">
      <img src="img/<?php echo $row['products_image'];?>" alt="<?php echo $row ['products_name'] ?>">
      <p class="Name"><?php echo $row ['products_name'] ?></p>
    <p class="Price">LKR <?php echo $row ['products_price'] ?></p>
    <button onclick="window.location.href='savory.php?products_id=<?php echo $row['products_id'];?>'">Buy</button>
  </div>
  <?php } ?>

  </div>

<footer>
  <div class="footer-links">
    <a href="refund.html">Refund Policy</a>
    <a href="term.html">Terms & Conditions</a>
    <a href="privacy.html">Privacy Policy</a>
  </div>
  <div class="footer-social">
    <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
  </div>
  <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
</footer>


  </div>
  <script>
      document.getElementById('searchIcon').addEventListener('click', function() {
    var searchQuery = document.getElementById('searchInput').value.trim().toLowerCase();
    var products = document.querySelectorAll('.product-item');

    products.forEach(function(product) {
        var productName = product.querySelector('.Name').textContent.trim().toLowerCase();
        
        if (productName.includes(searchQuery)) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
});
  
  
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

  
</body>
</html>
