<?php
require_once 'functions.php';
@include 'server/connection.php';

$errors = [];
$success = false;

$token = $_GET['token'] ?? '';

if (empty($token)) {
    echo "<script>alert('No token provided'); window.location.href='login.php';</script>";
    exit;
}

$check = mysqli_query($conn, "SELECT * FROM users WHERE reset_token='$token' AND token_expiry > NOW()");
if (mysqli_num_rows($check) == 0) {
    echo "<script>alert('Invalid or expired token'); window.location.href='login.php';</script>";
    exit;
}

if (isset($_POST['update_password'])) {
    $newpass = $_POST['new_password'];
    $cpass = $_POST['confirm_password'];

    if ($newpass !== $cpass) {
        $errors['password'] = "Passwords do not match!";
    } else {
        $hashed = password_hash($newpass, PASSWORD_DEFAULT);
        mysqli_query($conn, "UPDATE users SET password='$hashed', reset_token=NULL, token_expiry=NULL WHERE reset_token='$token'");
        echo "<script>alert('Password updated successfully!'); window.location.href='login.php';</script>";
        exit;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Password</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #f8f9fa;
    }
    .container {
      max-width: 500px;
      margin: 50px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    h1 {
      text-align: center;
      margin-bottom: 20px;
    }
    .inputBox {
      margin-bottom: 15px;
    }
    .inputBox span {
      display: block;
      margin-bottom: 5px;
      font-weight: 600;
    }
    .inputBox input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .btn {
      width: 100%;
      padding: 10px;
      background-color: #BA954D;
      border: none;
      border-radius: 4px;
      color: #fff;
      font-weight: 600;
      cursor: pointer;
    }
    .btn:hover {
      background-color: #96783A;
    }
    .error {
      color: red;
      font-size: 0.9em;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
   <div class="container">
      <h1>Reset Password</h1>
      <?php if (!empty($errors['password'])): ?>
        <div class="error"><?= htmlspecialchars($errors['password']) ?></div>
      <?php endif; ?>
<form method="post">
   <div class="inputBox" style="position:relative;">
      <span>New Password</span>
      <input type="password" name="new_password" id="new_password" required>
      <span class="toggle-eye" onclick="togglePassword('new_password', this)" style="position:absolute; right:10px; top:38px; cursor:pointer;">
        <i class="fas fa-eye"></i>
      </span>
   </div>
   <div class="inputBox" style="position:relative;">
      <span>Confirm Password</span>
      <input type="password" name="confirm_password" id="confirm_password" required>
      <span class="toggle-eye" onclick="togglePassword('confirm_password', this)" style="position:absolute; right:10px; top:38px; cursor:pointer;">
        <i class="fas fa-eye"></i>
      </span>
   </div>
   <input type="submit" name="update_password" value="Update Password" class="btn">
</form>
   </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
<script>
function togglePassword(fieldId, el) {
  const input = document.getElementById(fieldId);
  const icon = el.querySelector('i');
  if (input.type === "password") {
    input.type = "text";
    icon.classList.remove('fa-eye');
    icon.classList.add('fa-eye-slash');
  } else {
    input.type = "password";
    icon.classList.remove('fa-eye-slash');
    icon.classList.add('fa-eye');
  }
}
</script>
</body>
</html>