<?php
session_start();
include('../server/connection.php');

$period = $_GET['period'] ?? 'month';
$date = $_GET['date'] ?? date('Y-m-d');

$where = "";
if ($period == 'day') {
    $where = "DATE(created_at) = '" . $conn->real_escape_string($date) . "'";
} elseif ($period == 'week') {
    $week_start = date('Y-m-d', strtotime('monday this week', strtotime($date)));
    $week_end = date('Y-m-d', strtotime('sunday this week', strtotime($date)));
    $where = "DATE(created_at) BETWEEN '$week_start' AND '$week_end'";
} else { // month
    $month = date('m', strtotime($date));
    $year = date('Y', strtotime($date));
    $where = "MONTH(created_at) = '$month' AND YEAR(created_at) = '$year'";
}

// Order completion rate, average delivery time, and cancelled orders for period
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE $where")->fetch_assoc()['count'] ?? 0;
$completed_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='Completed' AND $where")->fetch_assoc()['count'] ?? 0;
$cancelled_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='Cancelled' AND $where")->fetch_assoc()['count'] ?? 0;
$completion_rate = $total_orders > 0 ? round(($completed_orders / $total_orders) * 100, 2) : 0;
$avg_delivery = $conn->query("SELECT AVG(DATEDIFF(delivery_date, created_at)) as avg_days FROM orders WHERE delivery_date IS NOT NULL AND $where")->fetch_assoc()['avg_days'] ?? 0;
?>
<p><strong>Order Completion Rate:</strong> <?php echo $completion_rate; ?>%</p>
<p><strong>Average Delivery Time:</strong> <?php echo round($avg_delivery, 2); ?> days</p>
<p><strong>Cancelled Orders:</strong> <?php echo $cancelled_orders; ?></p>