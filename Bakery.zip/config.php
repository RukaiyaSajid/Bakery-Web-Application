<?php
/**
 * Configuration file for Bakery Delivery Service
 * 
 * Contains database connection and global settings
 */

// Database configuration
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'bakery_db';

// Create database connection
$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8
$conn->set_charset("utf8");

// Timezone setting
date_default_timezone_set('UTC');

// Site configuration
$config = [
    'site_name' => 'The Butterhedge Bakery',
    'site_url' => 'http://localhost/Bakery',
    'admin_email' => 'admin@butterhedge.com',
    'site_phone' => '072 404 0949',
    'site_address' => ' Vystwyke road, Colombo, Sri Lanka',
    'items_per_page' => 12,
    'free_shipping_threshold' => 1000.00, // Free shipping for orders over $75
    'default_shipping_cost' => 350.00,
    'currency' => 'LKR',
    'supported_languages' => ['en', 'si', 'ta'],
];

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Initialize session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include common functions
require_once 'functions.php';
?>