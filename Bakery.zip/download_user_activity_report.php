<?php
session_start();
include('../server/connection.php');

$period = $_GET['period'] ?? 'month';
$date = $_GET['date'] ?? date('Y-m-d');

$where = "";
if ($period == 'day') {
    $where = "DATE(created_at) = '" . $conn->real_escape_string($date) . "'";
} elseif ($period == 'week') {
    $week_start = date('Y-m-d', strtotime('monday this week', strtotime($date)));
    $week_end = date('Y-m-d', strtotime('sunday this week', strtotime($date)));
    $where = "DATE(created_at) BETWEEN '$week_start' AND '$week_end'";
} else { // month
    $month = date('m', strtotime($date));
    $year = date('Y', strtotime($date));
    $where = "MONTH(created_at) = '$month' AND YEAR(created_at) = '$year'";
}

// New users in period
$new_users = $conn->query("SELECT user_id, user_name, email, created_at FROM users WHERE $where");

// Active users (placed orders in period)
$active_users = $conn->query("SELECT DISTINCT users.user_id, users.user_name, users.email FROM users JOIN orders ON users.user_id = orders.user_id WHERE $where");

// Most active users (by order count in period)
$most_active = $conn->query("SELECT users.user_id, users.user_name, users.email, COUNT(*) as orders FROM users JOIN orders ON users.user_id = orders.user_id WHERE $where GROUP BY users.user_id ORDER BY orders DESC LIMIT 3");

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=user_activity_report.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['Section', 'User ID', 'User Name', 'Email', 'Orders/Created At']);

fputcsv($output, ['New Users']);
while ($row = $new_users->fetch_assoc()) {
    fputcsv($output, ['New User', $row['user_id'], $row['user_name'], $row['email'], $row['created_at']]);
}

fputcsv($output, []);
fputcsv($output, ['Active Users']);
while ($row = $active_users->fetch_assoc()) {
    fputcsv($output, ['Active User', $row['user_id'], $row['user_name'], $row['email'], '']);
}

fputcsv($output, []);
fputcsv($output, ['Most Active Users']);
while ($row = $most_active->fetch_assoc()) {
    fputcsv($output, ['Most Active', $row['user_id'], $row['user_name'], $row['email'], $row['orders']]);
}

fclose($output);
exit;