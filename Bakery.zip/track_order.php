<?php
// filepath: c:\xampp\htdocs\Bakery\server\track_order.php
require_once 'connection.php';

$order_id = intval($_GET['order_id'] ?? 0);
$order_number = $status = $updated_at = $details = '';
$error = '';

if (!$order_id) {
    $error = "Invalid order ID.";
} else {
    $stmt = $conn->prepare("SELECT order_number, status, created_at FROM orders WHERE order_id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if ($result) {
        $order_number = $result['order_number'];
        $status = ucfirst($result['status']);
        $updated_at = $result['created_at'];
        // You can add more logic for details/status here
        if ($result['status'] === 'delivered') {
            $details = "Your order has been delivered!";
        } elseif ($result['status'] === 'cancelled') {
            $details = "Your order was cancelled.";
        } else {
            $details = "Your order is being processed.";
        }
    } else {
        $error = "Order not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Track Order</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
body {
  background: #f8f8f8;
  font-family: 'Poppins', sans-serif;
  margin: 0;
  padding: 0;
}
.track-order-container {
  max-width: 420px;
  margin: 60px auto 0 auto;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(186, 149, 77, 0.10);
  padding: 36px 28px 28px 28px;
  text-align: center;
}
.track-order-title {
  color: #96783A;
  font-size: 2rem;
  margin-bottom: 18px;
  letter-spacing: 1px;
}
.track-order-info {
  margin: 18px 0 0 0;
  color: #6d5c2c;
  font-size: 1.1rem;
}
.track-order-status {
  font-size: 1.2rem;
  font-weight: 600;
  margin: 18px 0 10px 0;
  color: #BA954D;
}
.track-order-details {
  background: #f4f1ea;
  border-radius: 8px;
  padding: 16px 12px;
  margin-top: 18px;
  color: #555;
  font-size: 1rem;
}
.track-order-updated {
  color: #888;
  font-size: 0.98rem;
  margin-top: 10px;
}
@media (max-width: 600px) {
  .track-order-container {
    padding: 18px 6px 16px 6px;
  }
  .track-order-title {
    font-size: 1.3rem;
  }
}
  </style>
</head>
<body>
  <div class="track-order-container">
    <div class="track-order-title">Track Your Order</div>
    <?php if ($error): ?>
      <div class="track-order-details" style="color:red;"><?php echo htmlspecialchars($error); ?></div>
    <?php else: ?>
      <div class="track-order-info"><strong>Order #:</strong> <?php echo htmlspecialchars($order_number); ?></div>
      <div class="track-order-status">Status: <?php echo htmlspecialchars($status); ?></div>
      <div class="track-order-details">
        <?php echo htmlspecialchars($details); ?>
      </div>
      <div class="track-order-updated">Last updated: <?php echo htmlspecialchars($updated_at); ?></div>
    <?php endif; ?>
  </div>
</body>
</html>