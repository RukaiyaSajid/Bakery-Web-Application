<?php
require_once '../includes/config.php';
require_once '../includes/session.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$message = trim($input['message'] ?? '');
$sessionId = $input['session_id'] ?? '';
$userId = $input['user_id'] ?? null;

if (empty($message)) {
    echo json_encode(['success' => false, 'error' => 'Message cannot be empty']);
    exit;
}

// Save user message
if ($sessionId) {
    saveBakeryMessage($sessionId, $message, 'user', $userId);
}

// Process message and generate response
$response = processBakeryMessage($message, $userId);

// Save bot response
if ($sessionId && $response['response']) {
    saveBakeryMessage($sessionId, $response['response'], 'bot', null);
}

echo json_encode($response);

function processBakeryMessage($message, $userId) {
    global $conn;
    $messageLower = strtolower($message);
    $response = ['success' => true, 'response' => '', 'actions' => []];

    // Specific recipe request (e.g. "I want Chocolate cake recipe")
    if (preg_match('/([a-zA-Z\s]+)\s+recipe/i', $message, $matches)) {
        $recipeName = trim($matches[1]);
        if ($recipeName) {
            $stmt = $conn->prepare("SELECT * FROM recipes WHERE LOWER(title) LIKE CONCAT('%', ?, '%') LIMIT 1");
            $recipeNameLower = strtolower($recipeName);
            $stmt->bind_param('s', $recipeNameLower);
            $stmt->execute();
            $result = $stmt->get_result();
            $recipe = $result->fetch_assoc();
            if ($recipe) {
                $response['response'] = "Here's the recipe for <b>" . htmlspecialchars($recipe['title']) . "</b>!";
                $response['actions'][] = [
                    'type' => 'show_recipes',
                    'data' => [$recipe]
                ];
                return $response;
            } else {
                $response['response'] = "Sorry, I couldn't find a recipe for that. Please try another name.";
                return $response;
            }
        }
    }
    // Only show all recipes if user asks for 'recipes' or 'show me recipes' (not a specific one)
    if (preg_match('/\b(recipes|show me recipes|baking recipes|cake recipes|bread recipes)\b/i', $message)) {
        $recipes = getBakeryRecipes(3);
        if (!empty($recipes)) {
            $response['response'] = "Here are some delicious recipes you might like:";
            $response['actions'][] = [
                'type' => 'show_recipes',
                'data' => $recipes
            ];
        } else {
            $response['response'] = "You can find many great recipes in our recipe section!";
        }
        return $response;
    }

    // Specific baking tips request (e.g. "what to do while baking", "baking tips")
    if (preg_match('/(baking tips|what to do while baking|tips for baking|advice for baking|baking advice|improve baking|help baking|baking help|baking guidance|baking suggestion)/i', $message)) {
        $tips = getBakeryTips(5);
        if (!empty($tips)) {
            $response['response'] = "Here are some helpful baking tips:";
            $response['actions'][] = [
                'type' => 'show_tips',
                'data' => $tips
            ];
        } else {
            $response['response'] = "Check out our baking tips section for helpful advice!";
        }
        return $response;
    }
    // Only show all tips if user asks for 'tips' or 'show me tips' (not a specific baking tip)
    if (preg_match('/\b(tips|show me tips|baking tips)\b/i', $message)) {
        $tips = getBakeryTips(5);
        if (!empty($tips)) {
            $response['response'] = "Here are some helpful tips:";
            $response['actions'][] = [
                'type' => 'show_tips',
                'data' => $tips
            ];
        } else {
            $response['response'] = "Check out our tips section for helpful advice!";
        }
        return $response;
    }

    // Order tracking patterns
    if (preg_match('/track.*order|order.*track|where.*order|order.*status/i', $messageLower)) {
        // Extract order number if provided
        if (preg_match('/(?:order|#)\s*([a-z0-9-]+)/i', $message, $matches)) {
            $orderNumber = $matches[1];
            $orderData = getBakeryOrderByNumber($orderNumber, $userId);
            if ($orderData) {
                $response['response'] = "Here's the tracking information for your order:";
                $response['actions'][] = [
                    'type' => 'track_order',
                    'data' => $orderData
                ];
            } else {
                $response['response'] = "I couldn't find that order. Please check the order number or make sure it belongs to your account.";
            }
        } else if ($userId) {
            // Show recent orders for logged-in users
            $orders = getBakeryUserRecentOrders($userId);
            if (!empty($orders)) {
                $response['response'] = "Here are your recent orders:";
                $response['actions'][] = [
                    'type' => 'show_orders',
                    'data' => $orders
                ];
            } else {
                $response['response'] = "You don't have any orders yet. Would you like to browse our products?";
            }
        } else {
            $response['response'] = "To track your order, please provide your order number (e.g., 'Track order BAK-2025-123456') or log in to see your orders.";
        }
        return $response;
    }

    // Product recommendations
    if (preg_match('/recommend|suggest|products|popular|best|trending|product.*recommendation/i', $messageLower)) {
        $products = getBakeryFeaturedProducts(3);
        if (!empty($products)) {
            $response['response'] = "Here are some of our most popular bakery items:";
            $response['actions'][] = [
                'type' => 'show_products',
                'data' => $products
            ];
        } else {
            $response['response'] = "I'd recommend checking out our featured collection on the homepage!";
        }
        return $response;
    }

    // Greeting patterns
    if (preg_match('/^(hi|hello|hey|good morning|good afternoon|good evening)/i', $messageLower)) {
        $responses = [
            "Hello! How can I help you with your bakery needs today?",
            "Hi there! I'm here to assist you with orders, recommendations, or baking tips.",
            "Welcome to our bakery! What can I help you find today?"
        ];
        $response['response'] = $responses[array_rand($responses)];
        return $response;
    }

    // Contact/Support
    if (preg_match('/contact|support|help|phone|email|address/i', $messageLower)) {
        $siteSettings = getSiteSettings();
        $response['response'] = "Here's how you can reach us:\n\n" .
            "📞 Phone: " . $siteSettings['site_phone'] . "\n" .
            "✉️ Email: " . $siteSettings['site_email'] . "\n" .
            "📍 Address: " . $siteSettings['site_address'] . "\n\n" .
            "You can also use this chat for immediate assistance!";
        return $response;
    }

    // Delivery information
    if (preg_match('/delivery|shipping|how long|when.*arrive/i', $messageLower)) {
        $response['response'] = "Our delivery options:\n\n" .
            "🏃 Same Day Delivery: Orders before 12 PM (350.00)\n\n" .
            "Free delivery on orders over 1000!";
        return $response;
    }

    // Default responses for unrecognized patterns
    $responses = [
        "I'm here to help! You can ask me about:\n• Order tracking\n• Product recommendations\n• Baking recipes\n• Delivery information\n• Contact details",
        "I can help you with orders, product suggestions, recipes, and more. What would you like to know?",
        "Not sure I understood that. Try asking about order tracking, our products, recipes, or delivery options."
    ];
    $response['response'] = $responses[array_rand($responses)];
    return $response;
}

function getBakeryOrderByNumber($orderNumber, $userId = null) {
    global $conn;
    
    $sql = "SELECT * FROM orders WHERE order_number = ?";
    $params = [$orderNumber];
    $types = "s";
    
    // If user is logged in, ensure order belongs to them
    if ($userId) {
        $sql .= " AND user_id = ?";
        $params[] = $userId;
        $types .= "i";
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

function getBakeryUserRecentOrders($userId, $limit = 5) {
    global $conn;
    
    $sql = "SELECT order_id as order_number, status, total_amount, created_at 
            FROM orders 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $userId, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getBakeryFeaturedProducts($limit = 3) {
    global $conn;
    
    $sql = "SELECT * FROM products ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getBakeryRecipes($limit = 3) {
    global $conn;
    
    $sql = "SELECT * FROM recipes ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getBakeryTips($limit = 3) {
    global $conn;
    
    $sql = "SELECT * FROM baking_tips ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

function saveBakeryMessage($sessionId, $message, $type, $userId) {
    global $conn;
    
    $sql = "INSERT INTO chat_messages (session_id, user_id, message, type, created_at) VALUES (?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siss", $sessionId, $userId, $message, $type);
    $stmt->execute();
}
?>