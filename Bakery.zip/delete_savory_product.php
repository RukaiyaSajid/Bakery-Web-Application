<?php
// filepath: c:\xampp\htdocs\Bakery\admindashboard\delete_savory_product.php
session_start();   
require_once '../server/connection.php';
$id = intval($_POST['products_id'] ?? 0);
if ($id) {
    $conn->query("DELETE FROM products WHERE products_id=$id");
    $_SESSION['success'] = "Savory product deleted successfully!";
}
header("Location: admin_savory_products.php");
exit;