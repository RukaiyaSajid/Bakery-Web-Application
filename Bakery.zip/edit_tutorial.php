<?php
session_start();
include('../server/connection.php');

$id = $_GET['id'] ?? null;
if (!$id) die('Invalid ID');

$tutorial = $conn->query("SELECT * FROM tutorials WHERE id=$id")->fetch_assoc();
if (!$tutorial) die('Tutorial not found');

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $is_live = $_POST['is_live'];
    $scheduled_time = $_POST['scheduled_time'] ?? null;
    $zoom_link = $_POST['zoom_link'] ?? null;
    $recording_path = $_POST['recording_path'] ?? null;

    if (!$name) $errors[] = "Name is required.";
    if ($is_live && !$scheduled_time) $errors[] = "Scheduled time required for live.";
    if ($is_live && !$zoom_link) $errors[] = "Zoom link required for live.";
    if (!$is_live && !$recording_path) $errors[] = "Recording path required for recorded.";

    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE tutorials SET name=?, is_live=?, scheduled_time=?, zoom_link=?, recording_path=? WHERE id=?");
        $stmt->bind_param("sisssi", $name, $is_live, $scheduled_time, $zoom_link, $recording_path, $id);
        $stmt->execute();
        header("Location: admin_tutorial.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Tutorial</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Edit Tutorial</h2>
    <a href="admin_tutorial.php" class="btn btn-secondary mb-3">Back</a>
    <?php if ($errors): ?>
        <div class="alert alert-danger"><?php echo implode('<br>', $errors); ?></div>
    <?php endif; ?>
    <form method="post">
        <input type="hidden" name="is_live" value="<?php echo $tutorial['is_live']; ?>">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($tutorial['name']); ?>" required>
        </div>
        <?php if ($tutorial['is_live']): ?>
            <div class="mb-3">
                <label>Scheduled Time</label>
                <input type="datetime-local" name="scheduled_time" class="form-control" value="<?php echo date('Y-m-d\TH:i', strtotime($tutorial['scheduled_time'])); ?>" required>
            </div>
            <div class="mb-3">
                <label>Zoom Link</label>
                <input type="url" name="zoom_link" class="form-control" value="<?php echo htmlspecialchars($tutorial['zoom_link']); ?>" required>
            </div>
        <?php else: ?>
            <div class="mb-3">
                <label>Recording Path (URL or file path)</label>
                <input type="text" name="recording_path" class="form-control" value="<?php echo htmlspecialchars($tutorial['recording_path']); ?>" required>
            </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</body>
</html>