<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles.css">

  <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    height: 100vh;
    background-color: #fff;
}

.main-container {
    width: 100%;
    max-width: 1200px;
    padding: 20px;
    box-sizing: border-box;
}

.contact-container {
    margin-top: 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 40px;
}

.left-side {
    flex: 1;
}

.left-side h1 {
    font-size: 64px;
    line-height: 1.2;
    margin: 20px;

}

.left-side p {
    margin: 20px;
    font-size: 16px;
    color: #555;
}

.right-side {
    flex: 1;
    display: flex;
    justify-content: flex-end;
}

.right-side img {
    max-width: 100%;
    height: auto;
}

.contusops {
    max-width: 1200px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 auto; /* Center horizontally */
    flex-wrap: wrap;
            width: 100%;
            max-width: 1200px;
            
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 20px;
    padding-top: 50px;
}

.card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    width: 150px;
    height: 150px;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: transform 1s ease;
    flex-shrink: 0; /* Prevent cards from shrinking */
}

.card img {
    max-width: 50px;
    height: auto;
    margin-bottom: 20px;
}

.card h2 {
    font-size: 20px;
    color: #333;
    margin: 0;
}

.card:hover {
    transform: translateY(-10px);
}

@media (max-width: 768px) {
    .contact-container {
        flex-direction: column;
        align-items: flex-start;
    }

    .right-side {
        justify-content: center;
        margin-top: 600px;
    }

    .contusops {
        flex-direction: column;
    }

    .card {
        margin: 10px 0;
    }


    
}


/* Scrollbar styles */
::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
    background: #BA954D;
}
.messagecont {

    max-width: 600px;
    width: 100%;
    margin: 40px auto;
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 5px 5px 20px 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    height: 300px;


    display: block;
            
            
           
            
}

.messages {
    box-shadow: inset 0 2px 4px rgba(0, 0, 0.2, 0.2);
    background-color: #c9c9c938;
    padding: 10px;
    position: relative;
    margin-bottom: 10px;
    border-radius: 10px 10px 0px 0px;
    color: rgb(0, 0, 0);
    word-wrap: break-word;
    clear: both;
    height: 240px;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
    
}

.message {
   
    float: right;
    padding: 10px 15px;
    margin-bottom: 10px;
    border-radius: 5px;
    color: #333;
    box-shadow: 0 2px 2px rgba(0, 0, 0, 0.1);
}

.user-message {
    max-width:260px ;
    margin-left: 100%;
    background-color: #e1f5fe;
    text-align: right;
}

.bot-message {
    max-width:260px ;
    float: left;
    background-color: #ffecb3;
    text-align: left;
}

.input-section {
    display: flex;
    gap: 10px;
}

#message-input {
    flex: 1;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    outline: none;
}

#send-btn {
    padding: 10px 20px;
    background-color: #BA954D;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
    outline: none;
}

#send-btn:hover {
    background-color: #96783A;
}

@media (max-width: 768px) {
    .contact-container {
        flex-direction: column;
        align-items: flex-start;
    }

    .right-side {
        justify-content: center;
        margin-top: 20px;
    }

    .contusops {
        flex-direction: column;
    }

    .card {
        margin: 10px 0;
    }

    .input-section {
        flex-direction: column;
    }

    #send-btn {
        margin-top: 10px;
        width: 100%;
    }
}.messagemain{
    align-content: center;
    align-items: center;
    margin-top: 40px;
    background-color: rgb(216, 216, 216);
    }
    .messagetitle{
    text-align: center;
    }

        .visits-container {
        margin-top: 40px;
        width: 100%;
        margin: 0px auto;
        background: #ffffff;
      
        border-radius: 8px;
       
        
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-bottom: 40px;
    }
    
    .visits-container h2 {
        font-size: 24px;
        padding-bottom: 40px;
    }
    
    .visits-box {

        max-width: 1200px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 auto; /* Center horizontally */
    flex-wrap: wrap;
    width: 100%;
    max-width: 1200px;           
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 0px;
    
    }
    
    .visits-box .map {
        align-content: center;
        width: 240px;
        height: 240px;
        background-color: #ececec;
        border-radius: 8px 0px 0px 8px;
        
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .visits-box .address {
        
        height: 200px;
        display: flex;
        padding: 20px;
        justify-content: center;
        font-size: 16px;
        color: #555555;
        background-color: #69696921;
        border-radius: 0px 8px 8px 0px;
        
        
    }
    
    @media (max-width: 768px) {
        .visits-box {
            flex-direction: column;
            
        }
        .visits-box .address{
            border-radius: 0px 0px 8px 8px;
        }
    
        .visits-box .map {
            margin-right: 0;
            width: 228px;
            border-radius: 8px 8px 0px 0px;
          
        }
    }
    .address {
  
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    background-color: #000;
    position: relative;
    }
    .addressp{
         font-size: 16px;
        line-height: 24px;
        margin-bottom: 10px;
       
    }
    .visith{
        margin-top: 40px;
    }
    .address .addressbtncontainer {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-top: 10px;
}

.address .addressbtncontainer img {
    border-radius: 20%;
    background-color: rgba(41, 41, 41, 0.322);
    padding: 2px;
    width: 25px;
    cursor: pointer;
    transition: 1s;
}
.address .addressbtncontainer img:hover{
    scale: 1.05;
    background-color: rgba(41, 41, 41, 0.13);
}
.main1contactus{
    margin-bottom: 75px;
}

  </style>
</head>
<body>
<!-- Header -->
<header>
    <nav class="navbar">
        <div class="logo">  
            <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
           </div>  
      <ul class="nav-links">
        <li><a href="home.php">Home </a></li>
        <li class="active-link">
          <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Products</a>
          <div class="dropdown">
            <a href="Products- cakes.php">Cake</a>
            <a href="Products- savory.php">Savory</a>
            <a href="gift.php">Giftbox</a>
            <a href="customize.php">Customize</a>
          </div>
        </li>            
        <li><a href="tutorial.php">Tutorials </a></li>
        <li><a href="blog.php">Blog </a></li>
        <li><a href="about.php">About Us </a></li>
        <li><a href="contact.php">Contact Us </a></li>
      </ul>
      <div class="icons">
        <a href="cart.php" class="cart-icon">
          <i class="fas fa-shopping-cart"></i>
          <span class="cart-quantity">0</span>
        </a>        
          <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>

        </div>
      </div>    
    </nav>
  </header>



<div class="main-container">
    <div class="main1contactus">
        <div class="contact-container">
            <div class="left-side">
                <h1>Get in touch<br>with us</h1>
            </div>
            <div class="right-side">
                <img src="img/cont.png" alt="Logo">
            </div>
        </div>

        <div class="contusops">
            <div class="card">
                <img src="img/icons8-phone-100.png" alt="Tell Us">
                <h2>Tell Us</h2>
                <p>072 404 0949</p>
            </div>
            <div class="card">
                <img src="img/icons8-email-100.png" alt="Email Us">
                <h2>Email Us</h2>
                <p>info@gmail.com</p>
            </div>
            <div class="card">
                <img src="img/icons8-fax-100.png" alt="Fax Us">
                <h2>Fax Us</h2>
                <p>+94 11 234 5678</p>
            </div>
        </div>



    <div class="messagemain"> 
        <h2 class="messagetitle">Message Us</h2>
    
        <div class="messagecont">
        <div class="messages">
            <!-- No default messages here -->
        </div>
        <form id="contact-form" method="POST" action="save_message.php" style="margin:0;">
  <div class="input-section">
    <input type="text" id="message-input" name="message" placeholder="Type your message..." required>
    <button id="send-btn" type="submit">Send</button>
  </div>
</form>
    </div>
    </div>
    <div class="visits-container">
        <h2 class="visith">Visit Us</h2>
        <div class="visits-box">
            <div class="map">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3163.3755517367637!2d79.86172231530744!3d6.911781895000248!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae25bdf67f9e95f%3A0x9c9c0d6a12e9edb7!2s245%2C%203%20De%20Fonseka%20Pl%2C%20Colombo%2000400%2C%20Sri%20Lanka!5e0!3m2!1sen!2sus!4v1631097218071!5m2!1sen!2sus"
                    width="100%"
                    height="100%"
                    style="border:0;"
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
            <div class="address">
                <p class="addressp">
                    245<br> 3 De Fonseka Pl<br> Colombo 00400<br>
                <br>
               Opers at 7.00am - 5.00am

                </p>
                <div class="addressbtncontainer">
                    <img class="copy" src="img/copy.png" alt="Copy" onclick="copyLocation()">
                    <img class="go" src="img/go.png" alt="Go" onclick="navigateToLocation()">
                </div>

            </div>
        </div>


    </div>
    </div>

    <script>
    
        function toggleContent(button) {
            const allSections = document.querySelectorAll('.tnscont .section-content');
            const currentSection = button.parentElement.nextElementSibling;
    
            // Close all sections
            allSections.forEach(section => {
                if (section !== currentSection) {
                    section.style.display = 'none';
                    section.previousElementSibling.querySelector('button').textContent = 'Read More';
                }
            });
    
            // Toggle the current section
            const isVisible = currentSection.style.display === 'block';
            currentSection.style.display = isVisible ? 'none' : 'block';
            button.textContent = isVisible ? 'Read More' : 'Read Less';
        }
    
    
    
    
        let lastMessageTime = 0;
        const botResponseInterval = 30 * 60 * 1000; // 30 minutes in milliseconds
    
        document.getElementById('send-btn').addEventListener('click', function() {
            var userMessage = document.getElementById('message-input').value;
            if (userMessage.trim() === '') {
                return;
            }
    
            var userMessageDiv = document.createElement('div');
            userMessageDiv.className = 'message user-message';
            userMessageDiv.textContent = userMessage;
    
            document.querySelector('.messages').appendChild(userMessageDiv);
            document.getElementById('message-input').value = '';
    
            var currentTime = new Date().getTime();
            if (currentTime - lastMessageTime >= botResponseInterval) {
                var botMessageDiv = document.createElement('div');
                botMessageDiv.className = 'message bot-message';
                botMessageDiv.textContent = 'Thank you for reaching out to us. Our team will review your message and get back to you shortly.';
    
                document.querySelector('.messages').appendChild(botMessageDiv);
                lastMessageTime = currentTime;
            }
        });
    </script>
    <script>
        function copyLocation() {
            var text = "245, 3 De Fonseka Pl, Colombo 00400";
            navigator.clipboard.writeText(text).then(function() {
                console.log('Copied to clipboard: ' + text);
                alert('Copied to clipboard: ' + text);
            }, function(err) {
                console.error('Could not copy text: ', err);
            });
        }
    
        function navigateToLocation() {
            var address = "245, 3 De Fonseka Pl, Colombo 00400";
            var url = "https://www.google.com/maps/dir/?api=1&destination=" + encodeURIComponent(address);
            window.open(url, '_blank');
        }
    </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>
