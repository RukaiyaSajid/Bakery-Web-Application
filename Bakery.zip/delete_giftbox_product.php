<?php
// filepath: c:\xampp\htdocs\Bakery\admindashboard\delete_giftbox_product.php
require_once '../server/connection.php';
$id = intval($_POST['giftbox_product_id'] ?? 0);
if ($id) {
    $conn->query("DELETE FROM giftbox_products WHERE giftbox_product_id=$id");
}
header("Location: admin_giftbox_products.php");
exit;