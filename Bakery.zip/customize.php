<?php session_start(); ?>
<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_custom_cake'])) {
    // Handle image upload
    $imageData = null;
    if (isset($_FILES['custom_image']) && $_FILES['custom_image']['tmp_name']) {
        $img_name = uniqid('custom_cake_') . '.' . pathinfo($_FILES['custom_image']['name'], PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['custom_image']['tmp_name'], "img/$img_name");
        $imageData = $img_name;
    }

    $flavor = $_POST['flavor'] ?? '';
    $greeting = $_POST['greeting'] ?? '';
    $greetColor = $_POST['greetColor'] ?? '';
    $price = 6500; // Set your price logic here

    // Add to session cart
    $product_id = 'custom_' . time();
    $_SESSION['cart'][$product_id] = [
        'products_id' => $product_id,
        'products_image' => $imageData,
        'products_name' => 'Customize Cake',
        'products_price' => $price,
        'product_quantity' => 1,
        'flavor' => $flavor,
        'greeting' => $greeting,
        'greetColor' => $greetColor
    ];

    // Redirect to cart page
    header("Location: cart.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Products - Customize</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles.css">

  <style>
        .header {
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #845d2a;
      color: white;
      padding: 20px;
    }
    .header img{
        max-width: 220px;
        float: left;
        border: solid #fff;
        border-radius: 10px;
        margin-right: 15px;
    }
    .header{
        margin: 100px auto;
        text-align: left;

    }
    .header_text h1{
       font-size: 32px;
       text-align: left;
 
    }
    .header_text p{
        font-size: 16px;
    }
    .container {
      max-width: 1200px;
      margin-top: 10PX;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    h1 {
      font-size: 24px;
      text-align: center;
      margin-bottom: 20px;
      color: #fff;
    }

    .section {
      margin-bottom: 40px;
    }

    .section h2 {
      font-size: 20px;
      color: #333;
      margin-bottom: 15px;
    }

    .section .file-upload {
      text-align: center;
      margin-bottom: 20px;
    }

    .file-upload{
        border: dashed #ccc;
        padding: 20px;
    }
    .file-upload:hover{
        border: dashed #96783A;
    }
    .section .file-upload input[type="file"] {
      margin: 0;
      padding: 10px;
      background-color: #BA954D;
      color: white;
      border: none;
      cursor: pointer;
      font-size: 16px;
    }

    .section .file-upload input[type="file"]:hover {
      background-color: #96783A;
    }

    .section .file-upload span {
      display: block;
      margin-top: 10px;
      font-size: 14px;
      color: #999;
    }

    .select-flavor {
      display: flex;
      justify-content: space-around;
      margin-bottom: 20px;
    }

    .select-flavor .flavor-option {
      text-align: center;
      flex: 1;
      padding: 10px;
    }
    .flavor-option:hover{
        transform: translateY(-5px);

    }

    .select-flavor .flavor-option img {
      width: 150px;
      height: 125px;
      object-fit: fill;
      border-radius: 8px;
    }

    .select-flavor input[type="radio"] {
      margin-top: 10px;
    }

    .section .greeting-input {
      margin-top: 20px;
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border-radius: 5px;
      border: 1px solid #ccc;
      background-color: #f1f1f1;
    }
    #greetingText{
      width: 100%;
      max-width: 1170px;
      height: 80px;
      border: none;
      background-color: #f1f1f1;
      padding: 10px;
      font-size: 14px;
      font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
      border-radius: 5px;
      outline: none;
      resize: none;
    }

    .greeting-color {
      margin-top: 20px;
      text-align: left;
    }

  .greeting-color label {
  display: inline-block;
  width: 20px;
  height: 20px;
  margin-right: 60px;
  border-radius: 50%;
  cursor: pointer;
}

.greeting-color input[type="radio"]:checked + label {
  border: 2px solid #333;
}

    .greeting-color input[type="radio"] {
      margin: 0 10px;
    }

    .button-container {
      display: flex;
      justify-content: center;
      margin-top: 40px;
    }

    .continue-button {
      padding: 15px 30px;
      background-color: #BA954D;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 18px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .continue-button:hover {
      background-color: #96783A;
    }

    #orderSummary {
      display: none; /* Initially hide the order summary */
      text-align: center;
      margin-top: 100px;    
      background-color: #fff;
      border: 1px solid #ccc;
      border-radius: 5px; 
      padding-bottom: 10px;    
    }

    .order-summary img {
      width: 200px;
      height: 200px;
      object-fit: cover;
      border-radius: 8px;
      margin-bottom: 20px;
    }

    .order-summary p {
      font-size: 18px;
      margin: 10px 0;
    }

  </style>
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.html"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li class="active-nav"><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.html">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>

  
  <!-- Main Container -->
  <div class="container">
    <div class="header ">
      <img src="img/custom.jpg" alt="customaize">
      <div class="header_text">
          <h1>Print Your Own Image on the Cake</h1>
          <p>There is something so special about sending your loved one a personalized gift. Now you can have any image you chose printed on a cake. You can use one of your own photographs. We always uses high-quality ingredients and world-class icing printers. The cake you have carefully chosen will be delivered in an elegant bakery box.</p>
  
      </div>
      </div>
  
    <!-- Step 1: Upload Image -->
    <div class="section">
      <h2>1. Upload My Picture</h2>
      <div class="file-upload">
        <input type="file" id="imageUpload" onchange="updateImageLabel()" />
        <span>No file selected</span>
      </div>
    </div>

    <!-- Step 2: Select Flavor -->
    <div class="section">
      <h2>2. Select Flavor</h2>
      <div class="select-flavor">
        <div class="flavor-option">
          <img src="img/chocolate-cake.jpg" alt="Chocolate Cake" />
          <input type="radio" id="chocolate" name="flavor" value="Chocolate">          
          <label for="chocolate">Chocolate</label>
        </div>
        <div class="flavor-option">
          <img src="img/vanilla-cake.jpg" alt="Vanilla Cake" />
          <input type="radio" id="vanilla" name="flavor" value="Vanilla">          
          <label for="vanilla">Vanilla</label>
        </div>
        <div class="flavor-option">
          <img src="img/Ribbon-cake.jpg" alt="Ribbon Cake" />
          <input type="radio" id="Ribbon" name="flavor" value="Ribbon">          
          <label for="Ribbon">Ribbon</label>
        </div>
      </div>
    </div>

    <!-- Step 3: Greeting on the Cake -->
    <div class="section">
      <h2>3. Greeting to Write on Cake</h2>
      <textarea class="greeting-input" id="greetingText" placeholder="Enter your message here" maxlength="20"></textarea>
      <div class="greeting-color">
        <h3>Greeting Color:</h3>       
         <input type="radio" id="red" name="greeting-color" value="red" style="display: none;" />
        <label for="red" style="background-color: red; width: 30px; height: 30px; border-radius: 50%; display: inline-block; cursor: pointer;"></label>
    
        <input type="radio" id="yellow" name="greeting-color" value="yellow" style="display: none;" />
        <label for="yellow" style="background-color: yellow; width: 30px; height: 30px; border-radius: 50%; display: inline-block; cursor: pointer;"></label>
    
        <input type="radio" id="blue" name="greeting-color" value="blue" style="display: none;" />
        <label for="blue" style="background-color: blue; width: 30px; height: 30px; border-radius: 50%; display: inline-block; cursor: pointer;"></label>
    
        <input type="radio" id="green" name="greeting-color" value="green" style="display: none;" />
        <label for="green" style="background-color: green; width: 30px; height: 30px; border-radius: 50%; display: inline-block; cursor: pointer;"></label>
    </div>
    
    </div>

    <!-- Continue Button -->
    <div class="button-container">
      <button class="continue-button" onclick="continueOrder()">Continue</button>
    </div>
  </div>

  <!-- Order Summary -->
  <div id="orderSummary" class="order-summary">
    <h3>Your Image Selection:</h3>
    <img id="orderImage" src="" alt="Your selected image">
    <p id="orderFlavor">Flavor: </p>
    <p id="orderGreeting">Greeting: </p>
    <p id="greeetingColor">Greeting Color:</p>
    <p>Price: 6,500</p>
    <!--Add to Cart button form  -->
<form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="add_custom_cake" value="1">
    <input type="file" name="custom_image" id="formImage" style="display:none;" required>
    <input type="hidden" name="flavor" id="formFlavor">
    <input type="hidden" name="greeting" id="formGreeting">
    <input type="hidden" name="greetColor" id="formGreetColor">
    <button type="submit" class="continue-button">Add to Cart</button>
</form>

  </div>

  <script>
    // Function to update the file label when a user selects an image
    function updateImageLabel() {
      const fileInput = document.getElementById('imageUpload');
      const label = fileInput.nextElementSibling;
      if (fileInput.files.length > 0) {
        label.textContent = fileInput.files[0].name;
      } else {
        label.textContent = "No file selected";
      }
    }

    // Function to handle the "Continue" button click
    function continueOrder() {
      const imageFile = document.getElementById('imageUpload').files[0];
      const flavor = document.querySelector('input[name="flavor"]:checked');
      const greeting = document.getElementById('greetingText').value;
      const greetColor = document.querySelector('input[name="greeting-color"]:checked');


      if (!imageFile || !flavor || !greeting || !greetColor) {
        alert('Please complete all steps!');
        return;
      }

      // Hide the form and show the order summary
      document.querySelector('.container').style.display = 'none';
      document.getElementById('orderSummary').style.display = 'block';

      // Display the selected details
      document.getElementById('orderImage').src = URL.createObjectURL(imageFile);
      document.getElementById('orderFlavor').textContent = `Flavor: ${flavor.value}`;
      document.getElementById('orderGreeting').textContent = `Greeting: ${greeting}`;
      document.getElementById('greeetingColor').textContent = `Greeting: ${greetColor.value}`;

      // After continueOrder() logic, before showing order summary:
      document.getElementById('formFlavor').value = flavor.value;
      document.getElementById('formGreeting').value = greeting;
      document.getElementById('formGreetColor').value = greetColor.value;
     document.getElementById('formImage').files = document.getElementById('imageUpload').files;
    
    const dataTransfer = new DataTransfer();
  dataTransfer.items.add(imageFile);
  formImageInput.files = dataTransfer.files;
    }

    // Function to handle the "Add to Cart" button click
    function addToCart() {
      // Retrieve customized cake details
      const imageFile = document.getElementById('imageUpload').files[0];
      const flavor = document.querySelector('input[name="flavor"]:checked').value;
      const greeting = document.getElementById('greetingText').value;
      const greetColor = document.querySelector('input[name="greeting-color"]:checked').value;
  // Convert the image file to a Data URL to store in localStorage
  const reader = new FileReader();
  reader.onload = function (event) {
    const product = {
      name: `Custom Cake - ${flavor}`,
      image: event.target.result, // Store image as Base64 URL
      greeting: greeting,
      greetColor: greetColor,
      price: "LKR 6500", // Hardcoded price, can be dynamic
      quantity: 1
    };

    // Get existing cart data or initialize an empty cart
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Add the customized cake to the cart
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));

    // Update cart quantity in the navbar dynamically
    updateCartQuantity();

  };
  reader.readAsDataURL(imageFile); // Convert image file to Base64
}

// Function to update cart quantity in the navbar
function updateCartQuantity() {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  const cartQuantity = document.querySelector('.cart-quantity');
  
  if (cart.length > 0) {
    cartQuantity.style.display = "block";
    cartQuantity.textContent = cart.length;
  } else {
    cartQuantity.style.display = "none";
  }
}

// Ensure cart quantity updates on page load
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>


