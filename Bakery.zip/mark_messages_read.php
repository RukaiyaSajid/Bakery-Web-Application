<?php
require_once '../includes/config.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$sessionId = $input['session_id'] ?? '';
$userId = $input['user_id'] ?? null;

if (empty($sessionId)) {
    echo json_encode(['success' => false, 'error' => 'Missing session ID']);
    exit;
}

$sql = "UPDATE chat_messages SET is_read = 1 WHERE session_id = ? AND type = 'bot' AND is_read = 0";
if ($userId) {
    $sql .= " AND user_id = ?";
}

$stmt = $conn->prepare($sql);
if ($userId) {
    $stmt->bind_param("si", $sessionId, $userId);
} else {
    $stmt->bind_param("s", $sessionId);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to mark messages as read']);
}
?>