<?php session_start(); ?>
<?php

include('server/connection.php');

if(isset ($_GET['products_id'])){

$product_id = $_GET['products_id'];
$stmt = $conn->prepare("SELECT * FROM products WHERE products_id= ?");
$stmt->bind_param("i",$product_id);

$stmt->execute();

$products = $stmt->get_result();



}else{

  header ('location: Products-savory.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Product details</title>
  <link rel="icon" href="img/favicon.ico">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="styles.css">

  <style>
    h1 {
      font-size: 24px;
      margin: 20px;
      color: #333;
    }

    #product-details {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
      margin: 20px;
      border-radius: 8px;
    }

    #product-details img {
      width: 200px;
      height: 200px;
      object-fit: cover;
      border-radius: 8px;
      margin-right: 20px;
    }

    #product-details div {
      flex: 1;
    }
    .cover-image {
            position: relative;
            width: 100%;
            height: 300px; 
            overflow: hidden;
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .cover-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .titletext {
            color: #ffffff;
            position: absolute;
            top: 60%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 70px;
            font-weight: bold;
        }

    .cover-image {
      position: relative;
      width: 100%;
      height: 300px;
      overflow: hidden;
      border-top-left-radius: 0px;
      border-top-right-radius: 0px;
    }

    .cover-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .titletext {
      color: #ffffff;
      position: absolute;
      top: 60%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 70px;
      font-weight: bold;
    }

    h2 {
      font-size: 28px;
      margin-bottom: 10px;
      color: #333;
    }

    p {
      font-size: 16px;
      margin-bottom: 10px;
      color: #666;
    }

    strong {
      font-weight: bold;
      color: #333;
    }

    .add-to-cart {
      background-color: #BA954D;
      color: white;
      border: none;
      width: 150px;
      padding: 12px 20px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s ease;
      margin-top: 10px;
    }

    .add-to-cart:hover {
      background-color: #96783A;
    }

    input[type="text"], select {
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-top: 10px;
      width: 100%;
      max-width: 400px;
    }

    input[type="number"], select {
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-top: 10px;
      width: 8%;
    }

   
    #product-details .price {
      font-size: 24px;
      font-weight: bold;
      color: #BA954D;
    }

    #product-details .description {
      font-size: 16px;
      color: #333;
      margin-top: 10px;
    }

    #product-details div {
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
    }
  </style>
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.html"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.html">Giftbox</a>
          <a href="customize.html">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.html">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.html">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>        
        <a href="account.html" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>
    <div class="cover-image">
        <img src="img/bun.jpg" alt="Cover Image">
        <div class="titletext">Products
        </div>
      </div>

  <h1>Product Details</h1>
  <div id="product-details">
  <?php while($row = $products->fetch_assoc()){ ?>


  <img src="img/<?php echo $row['products_image'];?>" alt="<?php echo $row['products_name'];?>">
      <div>
        <h2><?php echo $row['products_name'];?></h2>
        <p><?php echo $row['products_description'];?></p>
        <p><strong>Price: </strong> <?php echo $row['products_price'];?></p>
        <form method="POST" action="cart.php">
        <input type="hidden" name="products_id" value="<?php echo $row['products_id'];?>"/>
        <input type="hidden" name="products_image" value="<?php echo $row['products_image'];?>"/>
        <input type="hidden" name="products_name" value="<?php echo $row['products_name'];?>"/>
        <input type="hidden" name="products_price" value="<?php echo $row['products_price'];?>"/>
        
        <label for="customMessage">Free Customized Wording (optional):</label>
            <div>    <input type="text" id="customMessage" name="customize_message" placeholder="Enter your message here">
        </div>

        <label for="quantity">Quantity:</label>
            <div>    <input type="number" name="product_quantity" value="1" />
        </div>
        <button class="add-to-cart" 
        data-id="<?php echo $row['products_id']; ?>"
        data-name="<?php echo $row['products_name']; ?>"
        data-price="<?php echo $row['products_price']; ?>"
        data-image="<?php echo $row['products_image']; ?>">
    Add to cart
</button> 
        </form>

      </div>
      <?php } ?>

      </div>

  <footer>
    <div class="footer-links">
      <a href="refund.html">Refund Policy</a>
      <a href="term.html">Terms & Conditions</a>
      <a href="privacy.html">Privacy Policy</a>
    </div>
    <div class="footer-social">
      <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
      <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
      <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
    </div>
    <p style="color: #fff;">Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>

  </footer>
  
  <script>

document.addEventListener("DOMContentLoaded", function() {
    // Add to cart functionality
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const productId = this.getAttribute('data-id');
            const productName = this.getAttribute('data-name');
            const productPrice = this.getAttribute('data-price');
            const productImage = this.getAttribute('data-image');
            
            // Send AJAX request to add to cart
            fetch('add_to_cart.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        product_id: productId,
        quantity: document.querySelector('input[name="product_quantity"]').value,
        customize_message: document.querySelector('input[name="customize_message"]').value

    })
})
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    // Update cart quantity
                    document.querySelector('.cart-quantity').textContent = data.cart_count;
                    // Show success message
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    });
});

</script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>
