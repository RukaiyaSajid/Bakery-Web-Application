<?php
session_start();
require_once 'connection.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: cart.php');
    exit;
}

$orderId = (int)$_POST['order_id'];
$paymentMethod = $_POST['payment_method'] ?? '';

// Validate
if (empty($paymentMethod)) {
    $_SESSION['error'] = "Please select a payment method.";
    header("Location: payment.php?order_id=$orderId");
    exit;
}

// Update order status
$stmt = $conn->prepare("UPDATE orders SET status = 'processing', payment_method = ? WHERE order_id = ?");
$stmt->bind_param("si", $paymentMethod, $orderId);
$stmt->execute();

// Redirect to confirmation page
header("Location: order_confirmation.php?order_id=$orderId");
exit;
?>