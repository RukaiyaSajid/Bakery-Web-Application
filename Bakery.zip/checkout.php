<?php session_start(); ?>
<?php
session_start();
require_once 'server/connection.php';

// Get cart data from session
$cart = $_SESSION['cart'] ?? [];
$orderTotal = 0;

// Calculate order total
foreach ($cart as $item) {
    $orderTotal += $item['products_price'] * $item['product_quantity'];
}
$delivery = $orderTotal > 1000 ? 0 : 350;
$orderTotal += $delivery;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles.css">

  <style>
    

    /* Checkout Page */
    .checkout-container {
      display: flex;
      justify-content: center;
      padding: 40px;
      margin-top: 100px;
    }

    .checkout-form {
      display: flex;
      flex-direction: column;
      width: 500px;
      padding: 20px;
      background-color: #f9f9f9;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .checkout-form label {
      font-size: 14px;
      font-weight: bold;
      margin-top: 10px;
    }

    .checkout-form input,
    .checkout-form select {
      padding: 10px;
      font-size: 14px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .checkout-form .submit-btn {
      background-color: #BA954D;
      color: white;
      font-size: 16px;
      padding: 12px;
      cursor: pointer;
      border: none;
      border-radius: 5px;
      margin-top: 10px;
    }

    .checkout-form .submit-btn:hover {
      background-color: #96783A;
    }

    .order-summary {
      background-color: #fff;
      padding: 20px;
      margin-left: 40px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      width: 300px;
      border-radius: 8px;
    }

    .order-summary h2 {
      font-size: 20px;
      margin-bottom: 20px;
    }

    .order-summary p {
      font-size: 14px;
      margin: 10px 0;
    }

    .order-summary .total {
      font-weight: bold;
      color: #BA954D;
      font-size: 16px;
      margin-top: 20px;
    }
  </style>
</head>
<body>

<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.php"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.php">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
  <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>


  <!-- Checkout Page -->
<div class="checkout-container">
    <!-- Billing Details Form -->
<form id="checkoutForm" class="checkout-form" method="POST" action="server/process_checkout.php" novalidate>
      <h1>Billing Details</h1>
      <div id="formError" class="alert alert-danger" style="display:none;"></div>

      <label for="firstName">First Name <span style="color:red;">*</span></label>
      <input type="text" id="firstName" name="firstName" required>

      <label for="lastName">Last Name <span style="color:red;">*</span></label>
      <input type="text" id="lastName" name="lastName" required>

      <label for="country">Country/Region <span style="color:red;">*</span></label>
      <select id="country" name="country" required>
        <option value="Sri Lanka">Sri Lanka</option>
        <option value="India">India</option>
        <option value="Pakistan">Pakistan</option>
      </select>

      <label for="address">House Number and Street Name</label>
      <input type="text" id="address" name="address">

      <label for="apartment">Apartment, Suit, Unit, etc. (Optional)</label>
      <input type="text" id="apartment" name="apartment">

      <label for="town">Town/City <span style="color:red;">*</span></label>
      <input type="text" id="town" name="town" required>

      <label for="postalCode">Postal Code/ZIP <span style="color:red;">*</span></label>
      <input type="text" maxlength="5" id="postalCode" name="postalCode" required>

      <label for="phone">Phone <span style="color:red;">*</span></label>
      <input type="text" maxlength="10" id="phone" name="phone" required>

      <label for="orderDate">Delivery Date <span style="color:red;">*</span></label>
      <input type="date" id="orderDate" name="orderDate" required>

      <label for="preOrderDate">Pre-Order Date <span style="color:red;">*</span></label>
      <input type="date" id="preOrderDate" name="preOrderDate" required>

      <label for="notes">Notes about Order, e.g. Special Notes</label>
      <textarea id="notes" name="notes"></textarea>
      <button type="submit" class="submit-btn">Place Order</button>
    </form>

    <!-- Your Order Summary -->
    <div class="order-summary">
      <h2>Your Order</h2>
      <div id="orderProducts">
        <?php foreach ($cart as $item): ?>
          <div class="order-item">
            <p><?php echo htmlspecialchars($item['products_name']); ?> × <?php echo $item['product_quantity']; ?></p>
            <p>LKR <?php echo number_format($item['products_price'] * $item['product_quantity'], 2); ?></p>
          </div>
        <?php endforeach; ?>
      </div>
      <p>Subtotal: LKR <?php echo number_format($orderTotal - $delivery, 2); ?></p>
      <p>Delivery: LKR <?php echo number_format($delivery, 2); ?></p>
      <p class="total">Total: LKR <?php echo number_format($orderTotal, 2); ?></p>
    </div>
</div>
<footer>
  <div class="footer-links">
    <a href="refund.html">Refund Policy</a>
    <a href="term.html">Terms & Conditions</a>
    <a href="privacy.html">Privacy Policy</a>
  </div>
  <div class="footer-social">
    <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
  </div>
  <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
</footer>

  <script>

    // Example cart data
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Populate order summary with cart data
    const productName = cart[0] ? cart[0].name : 'No Product';
    const productAmount = cart[0] ? cart[0].price : 'LKR 0';
    const totalAmount = cart.reduce((total, product) => total + (parseFloat(product.price) * product.quantity), 0);


    // Update the cart icon quantity
    const cartQuantity = cart.reduce((total, product) => total + product.quantity, 0);
    const cartQuantityElement = document.querySelector('.cart-quantity');
    cartQuantityElement.textContent = cartQuantity;
    cartQuantityElement.style.display = cartQuantity > 0 ? 'block' : 'none';

document.getElementById('checkoutForm').addEventListener('submit', function(e) {
    const required = ['firstName', 'lastName', 'town', 'postalCode', 'phone'];
    let valid = true;

    required.forEach(field => {
        if (!document.getElementById(field).value.trim()) {
            valid = false;
        }
    });

    // Custom validation for order date and pre-order date
    const orderDate = document.getElementById('orderDate').value;
    const preOrderDate = document.getElementById('preOrderDate').value;
    const now = new Date();
    const currentHour = now.getHours();

    if (orderDate === preOrderDate && currentHour >= 12) {
        const errorDiv = document.getElementById('formError');
        errorDiv.textContent = "You can't place the order for this day. Please select another day.";
        errorDiv.style.display = 'block';
        e.preventDefault();
        return;
    }

    if (!valid) {
        const errorDiv = document.getElementById('formError');
        errorDiv.textContent = 'Please fill the required fields';
        errorDiv.style.display = 'block';
        e.preventDefault();
    } else {
        document.getElementById('formError').style.display = 'none';
    }
});
</script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>
