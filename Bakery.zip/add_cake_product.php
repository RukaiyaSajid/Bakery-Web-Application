<?php
// filepath: c:\xampp\htdocs\Bakery\admindashboard\add_cake_product.php
session_start();
require_once '../server/connection.php';

$name = $_POST['products_name'] ?? '';
$price = $_POST['products_price'] ?? 0;
$stock = $_POST['stock'] ?? 0;
$desc = $_POST['products_description'] ?? '';
$image = $_FILES['products_image'] ?? null;

if ($name && $price && $stock && $desc && $image && $image['tmp_name']) {
    $img_name = uniqid('cake_') . '.' . pathinfo($image['name'], PATHINFO_EXTENSION);
    move_uploaded_file($image['tmp_name'], "../img/$img_name");
    $stmt = $conn->prepare("INSERT INTO products (products_name, products_price, stock, products_image, products_description, category) VALUES (?, ?, ?, ?, ?, 'cake')");
    $stmt->bind_param("sdiss", $name, $price, $stock, $img_name, $desc);
    $stmt->execute();
    $_SESSION['success'] = "Cake product added successfully!";
}
header("Location: admin_products.php");
exit();