<?php
session_start();
require_once '../server/connection.php';

// Debug logging
error_log("Updating order #".$_POST['order_id']." to status: ".$_POST['status']);

$order_id = intval($_POST['order_id'] ?? 0);
$status = $_POST['status'] ?? '';

$allowed_statuses = ['Pending', 'Processing', 'Completed', 'Delivered', 'Cancelled'];

if ($order_id && in_array($status, $allowed_statuses)) {
    $stmt = $conn->prepare("UPDATE orders SET status=?, updated_at=NOW() WHERE order_id=?");
    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();
}

header('Location: admin_dashboard.php');
exit;