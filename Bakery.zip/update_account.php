<?php
session_start();
require_once 'connection.php';

$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) { header('Location: /Bakery/login.php'); exit; }

$email = $_POST['updateEmail'] ?? '';
$phone = $_POST['updatePhone'] ?? '';
$password = $_POST['changePassword'] ?? '';
// TODO: Add 2FA handling

if ($email) {
    $stmt = $conn->prepare("UPDATE users SET email=? WHERE user_id=?");
    $stmt->bind_param("si", $email, $user_id);
    $stmt->execute();
}
if ($phone) {
    $stmt = $conn->prepare("UPDATE users SET phone=? WHERE user_id=?");
    $stmt->bind_param("si", $phone, $user_id);
    $stmt->execute();
}
if ($password) {
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password=? WHERE user_id=?");
    $stmt->bind_param("si", $hashed, $user_id);
    $stmt->execute();
}
header('Location: /Bakery/account.php');
exit;