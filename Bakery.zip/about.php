<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About us </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        .cover-image {
            position: relative;
            width: 100%;
            height: 400px;
            overflow: hidden;
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .cover-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .titletext {
            color: #ffffff;
            position: absolute;
            top: 60%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 70px;
            font-weight: bold;
        }

        .container {
            width: 80%;
            margin: auto;
            display: flex;
            flex-direction: column;
            align-items: left;
            padding: 20px 0;
        }

        .content {
            display: flex;
            justify-content: space-between;
            width: 100%;
            gap: 20px;
        }

        .text-area {
            width: 65%;
            padding: 20px;
        }

        .images {
            width: 30%;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .images img {
            width: 450px;
            height: 450px;
            background: #bbb;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .content {
                flex-direction: column;
                align-items: center;
                gap: 20px;
            }

            .text-area {
                width: 100%;
                padding: 15px;
            }

            .images {
                width: 100%;
                display: flex;
                justify-content: center;
            }

            .images img {
                width: 80%;
                height: auto;
            }
        }

        @media (max-width: 576px) {
            .titletext {
                font-size: 50px;
            }

            .container {
                width: 90%;
            }
        }

    </style>
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.html"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li class="active-nav"><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.php">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.html">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>



    <div class="cover-image">
        <img src="img/a.jpg" alt="Cover Image">
        <div class="titletext">About Us</div>
    </div>

    <div class="container">
        <h3>Our Story</h3>
        <div class="content">
            <div class="text-area">
                <p>
                    Butterhedge is the vision of passionate bakers who wanted to bring the finest handcrafted delights to dessert lovers everywhere. With years of experience in the culinary and pastry industry, our team set out to create a bakery that blends tradition with innovation, offering a unique selection of baked goods that cater to every taste. What started as a small home-based business has now flourished into a well-loved name, known for its commitment to quality, creativity, and customer satisfaction. Whether you crave classic pastries, custom-designed cakes, or artisanal bread, we ensure that each creation is made with the finest ingredients and a touch of love.
                </p>
                <p>
                    With a dedicated team of skilled bakers and friendly staff, we strive to provide not just exceptional products but also an unforgettable experience. Keeping up with modern trends and technology, Butterhedge offers an interactive online platform where customers can browse our catalog, customize their orders, enroll in virtual cooking sessions, and receive personalized baking tips through our chatbot assistant. From personalized gift boxes to same-day delivery services, we are here to make every occasion special. Whether it’s a wedding, birthday, or just a moment of indulgence, Butterhedge is ready to serve you with the best. We invite you to be part of our journey and experience the joy of baking with us!
                </p>
            </div>
            <div class="images">
                <img src="img/a1.jpg" alt="Image">
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-links">
            <a href="refund.html">Refund Policy</a>
            <a href="term.html">Terms & Conditions</a>
            <a href="privacy.html">Privacy Policy</a>
        </div>
        <div class="footer-social">
            <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
        </div>
        <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
