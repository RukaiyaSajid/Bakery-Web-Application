<?php
// Include database connection
include('server/connection.php');

if (!isset($_GET['id'])) {
    header('Location: blog.php');
    exit;
}

$post_id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM blog_posts WHERE blog_id = ?");
$stmt->bind_param("i", $post_id);
$stmt->execute();
$post = $stmt->get_result()->fetch_assoc();

if (!$post) {
    header('Location: blog.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Cheesecake</title>
<link rel="icon" href="img/favicon.ico">

<link rel="icon" href="img/favicon.ico">

<style>
  body {
    background-image: url(bio/wall1.jpg);
    display: flex;
    justify-content: center;
    height: 100vh;
    margin: 0;
    background-repeat: no-repeat;
    background-size: cover;
  }
  .card {
    display: flex;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    border-radius: 20px;
    overflow: hidden;
    width: 70%;
    min-width: 600px;
    margin: 20px;
    position: relative;
    background-color: rgb(255, 251, 240);
  }
  .image-section {
    min-height: 300px;
    min-width: 200px;
    flex: 1;
    background-image: url(img/b1.jpg);
    background-size: cover;
    background-position: center;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
  }
  .biography-texts {
    text-align: justify;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    font-size: 20px;
    flex: 2;
    padding: 30px;
    overflow-y: auto;
  }
  .biography-texts h1 {
    font-size: 48px;
    text-align: center;
  }
  .controls {
    display: flex;
    margin-top: 20px;

  }
  button {
    
    padding: 10px;
    font-size: 18px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin-right: 10px;
    background: none;
    border: none;
    width: 30px;
    height: 30px;
    border-radius: 5px;
    background-position: center;
    background-repeat: no-repeat;
  }
  .view-counter {
    margin-top: 10px;
    color: rgb(134, 134, 134);
    font-size: 15px;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;

  }
  .back-button {
      justify-content: center;
      display: flex;
      position: absolute;
      height: 25px;
      width: 17px;
      top: 10px;
      right: 10px;
      background-color: #181818;
      color: #ffffff;
      padding: 5px 10px;
      border-radius: 5px;
      text-decoration: none;
  }
    .back-button:hover {
    background-color: #303030;
  }
  @media (max-width: 992px) {
    .card {
      width: 90%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .image-section {
      width: 100%;
      min-height: 250px;
      border-radius: 10px;
    }

    .biography-texts {
      width: 90%;
      font-size: 16px;
      padding: 15px;
    }

    .biography-texts h1 {
      font-size: 30px;
    }
  }

  @media (max-width: 768px) {
    .card {
      width: 80%;
      flex-direction: column;
      align-items: center;
      justify-content: center;

    }

    .image-section {
      width: 100%;
      min-height: 250px;
      border-radius: 10px;
    }

    .biography-texts {
      font-size: 15px;
      padding: 10px;
      width: 90%;

    }

    .biography-texts h1 {
      font-size: 28px;
    }
  }

  @media (max-width: 576px) {
     .card {
      width: 50%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin: 60px;
    }

    .image-section {
      width: 80%;
      height: 100px;
      border-radius: 10px;
    }

    .biography-texts {
      font-size: 14px;
      padding: 10px;
      width: 80%;

    }

    .biography-texts h1 {
      font-size: 24px;
    }
  }

  @media (max-width: 475px) {
    .card {
      width: 40%;
      height: 950px;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin-right: 50px;
    }

    .image-section {
      width: 60%;
      height: 60px;
      border-radius: 10px;
      align-items: center;
      justify-content: center;
    }

    .biography-texts {
      font-size: 14px;
      padding: 20px;
      width: 60%;

    }

    .biography-texts h1 {
      font-size: 22px;
    }
  }

</style>
</head>
<body>
<a href="blog.php" class="back-button">
        <img src="img/back.png" alt="back Icon">
    </a>
    <div class="card">
        <div class="image-section" style="background-image: url('<?php echo $post['image_path']; ?>')">
            <!-- Image will be displayed as background -->
        </div>
        <div class="biography-texts">
            <h1><?php echo htmlspecialchars($post['title']); ?></h1>
            <div class="view-counter">
                <span id="page-views"><?php echo date('F j, Y', strtotime($post['created_at'])); ?></span>
            </div>
            <div id="bio-text">
                <?php echo nl2br(htmlspecialchars($post['full_content'])); ?>
            </div>
        </div>
    </div>

</body>
</html>
</body>
</html>
