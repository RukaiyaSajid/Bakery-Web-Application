<?php
session_start();
include('../server/connection.php');

$id = $_GET['id'] ?? null;
if ($id) {
    $conn->query("DELETE FROM tutorials WHERE id=$id");
}
header("Location: admin_tutorial.php");
exit;