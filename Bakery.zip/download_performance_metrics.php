<?php
session_start();
include('../server/connection.php');

$period = $_GET['period'] ?? 'month';
$date = $_GET['date'] ?? date('Y-m-d');

$where = "";
if ($period == 'day') {
    $where = "DATE(created_at) = '" . $conn->real_escape_string($date) . "'";
} elseif ($period == 'week') {
    $week_start = date('Y-m-d', strtotime('monday this week', strtotime($date)));
    $week_end = date('Y-m-d', strtotime('sunday this week', strtotime($date)));
    $where = "DATE(created_at) BETWEEN '$week_start' AND '$week_end'";
} else { // month
    $month = date('m', strtotime($date));
    $year = date('Y', strtotime($date));
    $where = "MONTH(created_at) = '$month' AND YEAR(created_at) = '$year'";
}

// Metrics
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE $where")->fetch_assoc()['count'] ?? 0;
$completed_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='Completed' AND $where")->fetch_assoc()['count'] ?? 0;
$cancelled_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='Cancelled' AND $where")->fetch_assoc()['count'] ?? 0;
$completion_rate = $total_orders > 0 ? round(($completed_orders / $total_orders) * 100, 2) : 0;
$avg_delivery = $conn->query("SELECT AVG(DATEDIFF(delivery_date, created_at)) as avg_days FROM orders WHERE delivery_date IS NOT NULL AND $where")->fetch_assoc()['avg_days'] ?? 0;

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=performance_metrics_report.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['Metric', 'Value']);
fputcsv($output, ['Order Completion Rate (%)', $completion_rate]);
fputcsv($output, ['Average Delivery Time (days)', round($avg_delivery, 2)]);
fputcsv($output, ['Cancelled Orders', $cancelled_orders]);
fputcsv($output, ['Total Orders', $total_orders]);
fputcsv($output, ['Completed Orders', $completed_orders]);
fclose($output);
exit;