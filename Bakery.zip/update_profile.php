<?php
session_start();
require_once 'connection.php';

$user_id = $_SESSION['user_id'] ?? 0;
$name = $_POST['editName'] ?? '';
$email = $_POST['editEmail'] ?? '';
$phone = $_POST['editPhone'] ?? '';
$password = $_POST['editPassword'] ?? '';

$password_changed = false;

// Update profile info
$stmt = $conn->prepare("UPDATE users SET user_name=?, email=?, user_contact=? WHERE user_id=?");
$stmt->bind_param("sssi", $name, $email, $phone, $user_id);
$stmt->execute();

// Update password if provided
if (!empty($password)) {
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password=? WHERE user_id=?");
    $stmt->bind_param("si", $hashed, $user_id);
    $stmt->execute();
    $password_changed = true;
}

// Send email if password changed
if ($password_changed) {
    $to = $email;
    $subject = "Your password has been changed";
    $time = date('Y-m-d H:i:s');
    $message = "Hello $name,\n\nYour password was changed on $time.\nIf you did not make this change, please contact support immediately.";
    $headers = "From: no-reply@yourbakery.com\r\n";
    mail($to, $subject, $message, $headers);
}

header("Location: ../account.php?success=1");
exit;
?>