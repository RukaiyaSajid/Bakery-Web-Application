<?php
require_once 'functions.php';
@include 'server/connection.php';
session_start();

$step = 1;
$error = '';
$success = '';

if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']); 
}

// Step 1: Check email
if (isset($_POST['check_email'])) {
    $email = trim($_POST['email']);
    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($check) > 0) {
        $_SESSION['reset_email'] = $email;
        $step = 2;
    } else {
        $error = "Email not found in our records. Please check the email address.";
    }
}

// Step 2: Reset password
if (isset($_POST['reset_password'])) {
    if (!isset($_SESSION['reset_email'])) {
        $error = "Session expired or invalid request. Please start over.";
        $step = 1;
    } else {
        $newpass = $_POST['new_password'];
        $cpass = $_POST['confirm_password'];

        if ($newpass !== $cpass) {
            $error = "Passwords do not match! Please try again.";
            $step = 2; 
        } else {
            $hashed = password_hash($newpass, PASSWORD_DEFAULT);
            $email = $_SESSION['reset_email'];
            $update = mysqli_query($conn, "UPDATE users SET password='$hashed' WHERE email='$email'");
            if ($update) {
                unset($_SESSION['reset_email']); 
                $_SESSION['success'] = "Password reset successful! You can now log in with your new password.";
                header("Location: login.php");
                exit();
            } else {
                $error = "Failed to update password. Please try again later.";
                $step = 2; 
            }
        }
    }
} else if (isset($_SESSION['reset_email'])) {
    $step = 2;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | The Butterhedge Bakery</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'popins', sans-serif;
            background: #f8f9fa;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .forgot-password-container {
            max-width: 400px;
            width: 100%;
            background: #fff;
            padding: 36px 28px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.07);
            text-align: center;
        }
        .forgot-password-header h1 {
            color: #96783A;
            font-size: 2em;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .forgot-password-header p {
            font-size: 0.95em;
            color: #555;
            margin-bottom: 18px;
        }
        .form-group {
            margin-bottom: 22px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 7px;
            color: #555;
            font-weight: 600;
        }
        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: 90%;
            padding: 11px 14px;
            border: 1px solid #888686ff;
            border-radius: 7px;
            font-size: 1em;
            color: #333;
        }
        .btn-primary {
            width: 100%;
            padding: 13px 0;
            background: #BA954D;
            color: #fff;
            border: none;
            border-radius: 7px;
            font-size: 1.08em;
            font-weight: 700;
            cursor: pointer;
            margin-bottom: 10px;
            transition: background 0.2s;
        }
        .btn-primary:hover {
            background: #96783A;
        }
        .message-box {
            padding: 10px 15px;
            border-radius: 7px;
            margin-bottom: 15px;
            font-size: 0.97em;
            text-align: center;
        }
        .message-box.error {
            background: #ffe0e0;
            color: #cc0000;
            border: 1px solid #cc0000;
        }
        .message-box.success {
            background: #e0ffe0;
            color: #008000;
            border: 1px solid #00cc00;
        }
        .back-to-login {
            margin-top: 18px;
            font-size: 0.97em;
            color: #555;
        }
        .back-to-login a {
            color: #96783A;
            text-decoration: none;
            font-weight: 500;
        }
        .back-to-login a:hover {
            text-decoration: underline;
            color: #BA954D;
        }
    </style>
</head>
<body>
    <div class="forgot-password-container">
        <div class="forgot-password-header">
            <h1><i class="fas fa-key"></i> Forgot Password</h1>
            <p>
                <?php if ($step == 1): ?>
                    Enter your registered email address to reset your password.
                <?php elseif ($step == 2): ?>
                    Set your new password below.
                <?php endif; ?>
            </p>
        </div>
        <?php if (!empty($error)): ?>
            <div class="message-box error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
            <div class="message-box success">
                <i class="fas fa-check-circle"></i>
                <span><?php echo htmlspecialchars($success); ?></span>
            </div>
        <?php endif; ?>
        <?php if ($step == 1): ?>
            <form method="post" action="">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="you@example.com" required autocomplete="email">
                </div>
                <button type="submit" name="check_email" class="btn-primary">
                    Next <i class="fas fa-arrow-right"></i>
                </button>
            </form>
        <?php elseif ($step == 2): ?>
            <form method="post" action="">
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" id="new_password" name="new_password"  required autocomplete="new-password">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password"  required autocomplete="new-password">
                </div>
                <button type="submit" name="reset_password" class="btn-primary">
                    Reset Password <i class="fas fa-key"></i>
                </button>
            </form>
        <?php endif; ?>
        <div class="back-to-login">
            <p>Remember your password? <a href="login.php">Back to Login</a></p>
        </div>
    </div>
</body>
</html>