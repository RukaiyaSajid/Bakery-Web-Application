<?php
<?php
session_start();
include('../server/connection.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
    $conn->query("UPDATE orders SET status='Accepted' WHERE order_id=$order_id");
    header('Location: admin_dashboard.php');
    exit;
}
?>