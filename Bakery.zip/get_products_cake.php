<?php
//Getting from the products as Featured products
// Include the database connection
include('connection.php');

$stmt = $conn->prepare("SELECT products_id, products_name, products_image FROM products Where category='cake' LIMIT 8");

$stmt->execute();

$featured_products = $stmt->get_result();


