<?php
// filepath: c:\xampp\htdocs\Bakery\admindashboard\edit_giftbox_product.php
require_once '../server/connection.php';
$id = intval($_GET['giftbox_product_id'] ?? 0);
$product = $conn->query("SELECT * FROM giftbox_products WHERE giftbox_product_id=$id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $price = $_POST['price'] ?? 0;
    $stock = $_POST['stock'] ?? 0;
    $category = $_POST['category'] ?? '';
    $desc = $_POST['description'] ?? '';
    $status = $_POST['status'] ?? 'active';
    $img_name = $product['image'];
    if (!empty($_FILES['image']['tmp_name'])) {
        $img_name = uniqid('giftbox_') . '.' . pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['image']['tmp_name'], "../img/$img_name");
    }
    $stmt = $conn->prepare("UPDATE giftbox_products SET name=?, price=?, stock=?, category=?, description=?, image=?, status=? WHERE giftbox_product_id=?");
    $stmt->bind_param("sdissssi", $name, $price, $stock, $category, $desc, $img_name, $status, $id);
    $stmt->execute();
    header("Location: admin_giftbox_products.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Giftbox Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Edit Giftbox Product</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" required>
        </div>
        <div class="mb-3">
            <label>Price</label>
            <input type="number" name="price" class="form-control" value="<?php echo htmlspecialchars($product['price']); ?>" required>
        </div>
        <div class="mb-3">
            <label>Stock</label>
            <input type="number" name="stock" class="form-control" value="<?php echo htmlspecialchars($product['stock']); ?>" required>
        </div>
        <div class="mb-3">
            <label>Category</label>
            <select name="category" class="form-control" required>
                <option value="snacks" <?php if($product['category']=='snacks') echo 'selected'; ?>>Snacks</option>
                <option value="chocolates" <?php if($product['category']=='chocolates') echo 'selected'; ?>>Chocolates</option>
                <option value="cake" <?php if($product['category']=='cake') echo 'selected'; ?>>Cake</option>
                <option value="savory" <?php if($product['category']=='savory') echo 'selected'; ?>>Savory</option>
                <option value="giftbox" <?php if($product['category']=='giftbox') echo 'selected'; ?>>Giftbox</option>
                <!-- Add more categories as needed -->
            </select>
        </div>
        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="3" required><?php echo htmlspecialchars($product['description']); ?></textarea>
        </div>
        <div class="mb-3">
            <label>Image</label>
            <input type="file" name="image" class="form-control" accept="image/*">
            <?php if($product['image']): ?>
                <img src="../img/<?php echo $product['image']; ?>" style="width:80px; margin-top:10px;">
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control">
                <option value="active" <?php if($product['status']=='active') echo 'selected'; ?>>Active</option>
                <option value="inactive" <?php if($product['status']=='inactive') echo 'selected'; ?>>Inactive</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update Giftbox</button>
        <a href="admin_giftbox_products.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>