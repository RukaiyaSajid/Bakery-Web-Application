<?php
// filepath: c:\xampp\htdocs\Bakery\admindashboard\edit_savory_product.php
session_start();

require_once '../server/connection.php';
$id = intval($_GET['products_id'] ?? 0);
$product = $conn->query("SELECT * FROM products WHERE products_id=$id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['products_name'] ?? '';
    $price = $_POST['products_price'] ?? 0;
    $stock = $_POST['stock'] ?? 0;
    $desc = $_POST['products_description'] ?? '';
    $img_name = $product['products_image'];
    if (!empty($_FILES['products_image']['tmp_name'])) {
        $img_name = uniqid('savory_') . '.' . pathinfo($_FILES['products_image']['name'], PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['products_image']['tmp_name'], "../img/$img_name");
    }
    $stmt = $conn->prepare("UPDATE products SET products_name=?, products_price=?, stock=?, products_image=?, products_description=? WHERE products_id=?");
    $stmt->bind_param("sdissi", $name, $price, $stock, $img_name, $desc, $id);
    $stmt->execute();
    $_SESSION['success'] = "Cake product updated successfully!";
    header("Location: admin_savory_products.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Savory Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Edit Savory Product</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="products_name" class="form-control" value="<?php echo htmlspecialchars($product['products_name']); ?>" required>
        </div>
        <div class="mb-3">
            <label>Price</label>
            <input type="number" name="products_price" class="form-control" value="<?php echo htmlspecialchars($product['products_price']); ?>" required>
        </div>
        <div class="mb-3">
            <label>Stock</label>
            <input type="number" name="stock" class="form-control" value="<?php echo htmlspecialchars($product['stock']); ?>" required>
        </div>
        <div class="mb-3">
            <label>Description</label>
            <textarea name="products_description" class="form-control" rows="3" required><?php echo htmlspecialchars($product['products_description']); ?></textarea>
        </div>
        <div class="mb-3">
            <label>Image</label>
            <input type="file" name="products_image" class="form-control" accept="image/*">
            <?php if($product['products_image']): ?>
                <img src="../img/<?php echo $product['products_image']; ?>" style="width:80px; margin-top:10px;">
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary">Update Savory</button>
        <a href="admin_savory_products.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>