<?php
session_start();
include('../server/connection.php');

$period = $_GET['period'] ?? 'month';
$date = $_GET['date'] ?? date('Y-m-d');

$where = "";
if ($period == 'day') {
    $where = "DATE(created_at) = '" . $conn->real_escape_string($date) . "'";
} elseif ($period == 'week') {
    $week_start = date('Y-m-d', strtotime('monday this week', strtotime($date)));
    $week_end = date('Y-m-d', strtotime('sunday this week', strtotime($date)));
    $where = "DATE(created_at) BETWEEN '$week_start' AND '$week_end'";
} else { // month
    $month = date('m', strtotime($date));
    $year = date('Y', strtotime($date));
    $where = "MONTH(created_at) = '$month' AND YEAR(created_at) = '$year'";
}

$total_sales = $conn->query("SELECT COALESCE(SUM(total_amount),0) as sum FROM orders WHERE status='Completed' AND $where")->fetch_assoc()['sum'] ?? 0;
$avg_order = $conn->query("SELECT COALESCE(AVG(total_amount),0) as avg FROM orders WHERE status='Completed' AND $where")->fetch_assoc()['avg'] ?? 0;
$top_products = $conn->query("SELECT products_name, COUNT(*) as sold FROM order_items JOIN products ON order_items.product_id = products.products_id JOIN orders ON order_items.order_id = orders.order_id WHERE orders.status='Completed' AND $where GROUP BY products_name ORDER BY sold DESC LIMIT 5");

?>
<p><strong>Total Sales (Completed Orders):</strong> LKR <?php echo number_format($total_sales, 2); ?></p>
<p><strong>Average Order Value:</strong> LKR <?php echo number_format($avg_order, 2); ?></p>
<h6>Top Selling Products:</h6>
<ul>
    <?php while($row = $top_products->fetch_assoc()): ?>
        <li><?php echo htmlspecialchars($row['products_name']); ?> (<?php echo $row['sold']; ?> sold)</li>
    <?php endwhile; ?>
</ul>