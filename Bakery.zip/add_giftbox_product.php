<?php
// filepath: c:\xampp\htdocs\Bakery\admindashboard\add_giftbox_product.php
require_once '../server/connection.php';

$name = $_POST['name'] ?? '';
$price = $_POST['price'] ?? 0;
$stock = $_POST['stock'] ?? 0;
$category = $_POST['category'] ?? '';
$description = $_POST['description'] ?? '';
$status = $_POST['status'] ?? 'active';
$image = $_FILES['image'] ?? null;

if ($name && $price && $stock && $category && $description && $image && $image['tmp_name']) {
    $img_name = uniqid('giftbox_') . '.' . pathinfo($image['name'], PATHINFO_EXTENSION);
    move_uploaded_file($image['tmp_name'], "../img/$img_name");
    $stmt = $conn->prepare("INSERT INTO giftbox_products (name, price, stock, category, description, image, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdissss", $name, $price, $stock, $category, $description, $img_name, $status);
    $stmt->execute();
}
header("Location: admin_giftbox_products.php");
exit;