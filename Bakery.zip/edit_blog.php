<?php
session_start();
include('../server/connection.php');

$id = $_GET['id'] ?? null;
if (!$id) die('Invalid blog ID.');

$post = $conn->query("SELECT * FROM blog_posts WHERE blog_id=$id")->fetch_assoc();
if (!$post) die('Blog post not found.');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $preview_text = $_POST['preview_text'];
    $full_content = $_POST['full_content'];
    $image_path = $post['image_path'];

    // Handle new image upload
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "img/";
        $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
        $new_filename = uniqid() . '.' . $imageFileType;
        $target_path = $target_dir . $new_filename;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_path)) {
            $image_path = $target_path;
        }
    }

    $stmt = $conn->prepare("UPDATE blog_posts SET title=?, image_path=?, preview_text=?, full_content=? WHERE blog_id=?");
    $stmt->bind_param("ssssi", $title, $image_path, $preview_text, $full_content, $id);
    if ($stmt->execute()) {
        header("Location: admin_blog.php");
        exit;
    } else {
        $error_message = "Error updating post: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Blog Post</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Edit Blog Post</h2>
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($post['title']); ?>" required>
        </div>
        <div class="mb-3">
            <label>Current Image</label><br>
            <img src="<?php echo $post['image_path']; ?>" style="max-width:100px;">
        </div>
        <div class="mb-3">
            <label>Change Image (optional)</label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>
        <div class="mb-3">
            <label>Preview Text</label>
            <textarea name="preview_text" class="form-control" rows="3" required><?php echo htmlspecialchars($post['preview_text']); ?></textarea>
        </div>
        <div class="mb-3">
            <label>Full Content</label>
            <textarea name="full_content" class="form-control" rows="10" required><?php echo htmlspecialchars($post['full_content']); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update Post</button>
        <a href="admin_blog.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>