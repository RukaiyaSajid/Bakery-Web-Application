<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// Database connection
include('../server/connection.php');

// Quick Stats Queries
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0;
$pending_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='Pending'")->fetch_assoc()['count'] ?? 0;
$completed_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='Completed'")->fetch_assoc()['count'] ?? 0;
$total_revenue = $conn->query("SELECT COALESCE(SUM(total_amount),0) as sum FROM orders WHERE status='Completed'")->fetch_assoc()['sum'] ?? 0;
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'] ?? 0;
$low_stock = $conn->query("SELECT products_name, stock FROM products WHERE stock < 10 ORDER BY stock ASC LIMIT 5");

// Recent Activities
$latest_orders = $conn->query("
    SELECT 
        orders.*, 
        users.user_name, 
        users.email, 
        od.first_name, 
        od.last_name, 
        od.country, 
        od.address, 
        od.apartment, 
        od.town, 
        od.postal_code, 
        od.phone,
        oi.kilogram, 
        oi.customize_message, 
        od.notes, 
        od.order_date,
        oi.quantity,
        oi.product_id,
        p.category,
        p.products_name
    FROM orders 
    JOIN users ON orders.user_id = users.user_id 
    JOIN order_details od ON orders.order_id = od.order_id 
    JOIN order_items oi ON orders.order_id = oi.order_id
    JOIN products p ON oi.product_id = p.products_id
    ORDER BY orders.created_at DESC 
    LIMIT 5
");
if ($latest_orders === false) {
    die("SQL Error: " . $conn->error);
}
$latest_users = $conn->query("
    SELECT 
        u.user_name, 
        u.user_contact,
        u.email,
        od.address, 
        od.apartment, 
        od.town, 
        od.country, 
        od.postal_code,
        od.first_name,
        od.last_name,
        o.created_at
    FROM users u
    JOIN orders o ON u.user_id = o.user_id
    JOIN order_details od ON o.order_id = od.order_id
    WHERE o.order_id = (
     SELECT order_id FROM orders WHERE user_id = u.user_id ORDER BY created_at DESC LIMIT 1
    )
    ORDER BY u.created_at DESC
    LIMIT 5
");
$latest_messages = $conn->query("
    SELECT chat_messages.*, users.user_name, users.email 
    FROM chat_messages 
    JOIN users ON chat_messages.user_id = users.user_id 
    ORDER BY chat_messages.created_at DESC 
    LIMIT 5
");
if ($latest_orders === false) {
    die("SQL Error: " . $conn->error);
}
$latest_messages = $conn->query("
    SELECT chat_messages.*, users.user_name, users.email 
    FROM chat_messages 
    JOIN users ON chat_messages.user_id = users.user_id 
    ORDER BY chat_messages.created_at DESC 
    LIMIT 10
");

// Sales Data for Chart (last 30 days)
$sales_data = [];
$result = $conn->query("SELECT DATE(updated_at) as date, SUM(total_amount) as total FROM orders WHERE status='Completed' AND updated_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(updated_at) ORDER BY date ASC");
while($row = $result->fetch_assoc()) {
    $sales_data[$row['date']] = $row['total'];
}
$dates = [];
$totals = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $dates[] = $date;
    $totals[] = isset($sales_data[$date]) ? (float)$sales_data[$date] : 0;
}

// Fetch contact messages
$messages = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
    body { background-color: #f8f9fa; }
    .sidebar {min-height: 100vh; background-color: #343a40; position: fixed; top: 0; z-index: 1020;}
    .sidebar .nav-link { color: rgba(255,255,255,0.75); }
    .sidebar .nav-link.active, .sidebar .nav-link:hover { color: #fff; background-color: #495057; }
    .main-content { padding: 20px; }
    .stat-card { min-height: 120px; }
    .low-stock { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block sidebar bg-dark">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="admin_dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
 
                    <li class="nav-item">
                        <a class="nav-link" href="admin_blog.php">
                            <i class="fas fa-blog me-2"></i>Blog Posts
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_products.php">
                            <i class="fas fa-box-open me-2"></i>Products - Cakes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_savory_products.php">
                            <i class="fas fa-drumstick-bite me-2"></i>Products - Savory
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="admin_giftbox_products.php">
                            <i class="fas fa-gift me-2"></i>Products - Giftbox
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_tutorial.php">
                            <i class="fas fa-chalkboard-teacher me-2"></i>Tutorials
                        </a>
                    </li>
                    <li class="nav-item mt-3">
                        <a class="nav-link text-danger" href="/Bakery/admin_logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
             <h2 class="my-4">Admin Dashboard</h2>
            <!-- Quick Stats -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <h6>Total Orders</h6>
                            <h3><i class="fas fa-shopping-cart"></i> <?php echo $total_orders; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <h6>Pending Orders</h6>
                            <h3><i class="fas fa-hourglass-half"></i> <?php echo $pending_orders; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <h6>Completed Orders</h6>
                            <h3><i class="fas fa-check-circle"></i> <?php echo $completed_orders; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <h6>Total Revenue</h6>
                            <h3><i class="fas fa-dollar-sign"></i> <?php echo number_format($total_revenue, 2); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <h6>Number of Users</h6>
                            <h3><i class="fas fa-users"></i> <?php echo $total_users; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <h6>Low Stock Alerts</h6>
                            <ul class="mb-0">
                                <?php while($row = $low_stock->fetch_assoc()): ?>
                                    <li class="low-stock"><?php echo $row['products_name']; ?> (<?php echo $row['stock']; ?> left)</li>
                                <?php endwhile; ?>
                                <?php if ($low_stock->num_rows == 0): ?>
                                    <li>No low stock items</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Recent Activities -->
                <div class="col-md-20 mb-4">
                    <div class="card h-40">
                        <div class="card-header"><strong>Latest Orders</strong></div>
                        <div class="card-body p-0">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Order Id</th>
                    <th>Status</th>
                    <th>Customer</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Quantity</th>
                    <th>Cake Weight (kg)</th>
                    <th>Customize Message</th>
                    <th>Note</th>
                    <th>Delivery Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($order = $latest_orders->fetch_assoc()): 
                    $order_date = strtotime($order['order_date']);
                    $today = strtotime(date('Y-m-d'));
                    $tomorrow = strtotime(date('Y-m-d', strtotime('+1 day')));
                    $is_close = ($order_date == $today || $order_date == $tomorrow);
                ?>
                <tr<?php echo $is_close ? ' style="background:#ffeaea;font-weight:bold;color:#c00;"' : ''; ?>>
                    <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                    <td><?php echo htmlspecialchars($order['status']); ?></td>
                    <td>
                        <i class="fas fa-user"></i> <?php echo htmlspecialchars($order['user_name'] ?? $order['email']); ?><br>
                        <small><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></small>
                    </td>
                    <td><?php echo htmlspecialchars($order['products_name']); ?></td>
                    <td><?php echo htmlspecialchars($order['category']); ?></td>
                    <td><?php echo htmlspecialchars($order['quantity']); ?></td>
                    <td><?php echo !empty($order['kilogram']) ? htmlspecialchars($order['kilogram']) : '-'; ?></td>
                    <td><?php echo !empty($order['customize_message']) ? htmlspecialchars($order['customize_message']) : '-'; ?></td>
                    <td><?php echo !empty($order['notes']) ? htmlspecialchars($order['notes']) : '-'; ?></td>
                    <td>
                        <span<?php echo $is_close ? ' style="color:red;font-weight:bold;"' : ''; ?>>
                            <?php echo date('M d, Y', strtotime($order['order_date'])); ?>
                        </span>
                    </td>
                    <td>
                        <form method="post" action="update_order_status.php" style="display:inline;">
                            <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                            <select name="status" class="form-select form-select-sm mb-1" required>
                                <option value="Pending" <?php if($order['status']=='Pending') echo 'selected'; ?>>Pending</option>
                                <option value="Processing" <?php if($order['status']=='Processing') echo 'selected'; ?>>Processing</option>
                                <option value="Completed" <?php if($order['status']=='Completed') echo 'selected'; ?>>Completed</option>
                                <option value="Delivered" <?php if($order['status']=='Delivered') echo 'selected'; ?>>Delivered</option>
                                <option value="Cancelled" <?php if($order['status']=='Cancelled') echo 'selected'; ?>>Cancelled</option>
                            </select>                                        
                            <button type="submit" class="btn btn-sm btn-primary w-100">Update</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
            <!-- Sales Graph -->
             <div>
                <div class="card mb-10 mb-4">
                <div class="card-header">
                    <h5>Sales Performance (Last 30 Days)</h5>
                </div>
                <div class="card-body">
                    <canvas id="salesChart" height="80"></canvas>
                </div>
            </div>
             </div>
            

<div class="col-md-15 mb-4">
    <div class="card h-100">
        <div class="card-header"><strong>New Users</strong></div>
        <ul class="list-group list-group-flush">
<?php while($user = $latest_users->fetch_assoc()): ?>
    <li class="list-group-item">
        <strong><?php echo htmlspecialchars($user['user_name']); ?></strong><br>
        <span><i class="fas fa-phone"></i> <?php echo htmlspecialchars($user['user_contact'] ?? 'N/A'); ?></span><br>
        <span>
            <?php
            $address = [];
            if (!empty($user['first_name']) || !empty($user['last_name'])) $address[] = trim($user['first_name'] . ' ' . $user['last_name']);
            if (!empty($user['address'])) $address[] = $user['address'];
            if (!empty($user['apartment'])) $address[] = 'Apt: ' . $user['apartment'];
            if (!empty($user['town'])) $address[] = $user['town'];
            if (!empty($user['country'])) $address[] = $user['country'];
            if (!empty($user['postal_code'])) $address[] = $user['postal_code'];
            echo implode(', ', $address);
            ?>
        </span><br>
        <small><?php echo htmlspecialchars($user['email']); ?></small>
    </li>
<?php endwhile; ?>
        </ul>
    </div>
</div>

                <div class="col-md-15 mb-4">
                    <div class="card h-40">
                        <div class="card-header"><strong>Recent Messages</strong></div>
                        <ul class="list-group list-group-flush">
                            <?php while($msg = $latest_messages->fetch_assoc()): ?>
                                <li class="list-group-item">
                                    <strong><?php echo htmlspecialchars($msg['user_name'] ?? $msg['email']); ?>:</strong>
                                    <?php echo substr($msg['message'], 0, 40); ?>... <br>
                                    <small><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></small>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                </div>
            </div>
                

            
                 <!-- Giftbox Orders Section -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5>Giftbox Orders</h5>
                </div>
                <div class="card-body">
                    <?php
        // Fetch latest Giftbox orders (where card_number is not null)
        $giftbox_orders = $conn->query("
    SELECT orders.*, users.user_name, users.email 
    FROM orders 
    JOIN users ON orders.user_id = users.user_id 
    WHERE card_number IS NOT NULL 
    ORDER BY DATE(orders.created_at) = CURDATE() DESC, orders.created_at DESC 
    LIMIT 10
");
        if ($giftbox_orders && $giftbox_orders->num_rows > 0): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Status</th>
                        <th>Card Number</th>
                        <th>Greeting Message</th>
                        <th>Delivery Date</th>
                        <th>Total Amount (LKR)</th>
                        <th>Ordered At</th>
                        <th>User</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($order = $giftbox_orders->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $order['order_id']; ?></td>
                            <td><?php echo htmlspecialchars($order['status']); ?></td>
                            <td><?php echo htmlspecialchars($order['card_number']); ?></td>
                            <td><?php echo htmlspecialchars($order['greeting_message']); ?></td>
                            <td><?php echo htmlspecialchars($order['delivery_date']); ?></td>
                            <td><?php echo number_format($order['total_amount'], 2); ?></td>
                            <td><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($order['user_name'] ?? $order['email']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No Giftbox orders yet.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Customize Cake Orders Section -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5>Customize Cake Orders</h5>
                </div>
                <div class="card-body">
                    <?php
                    $custom_orders = $conn->query("
                        SELECT orders.*, users.user_name, users.email 
                        FROM orders 
                        JOIN users ON orders.user_id = users.user_id 
                        WHERE flavor IS NOT NULL 
                        ORDER BY orders.created_at DESC 
                        LIMIT 10
                    ");                    
                    if ($custom_orders && $custom_orders->num_rows > 0): ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Flavor</th>
                                    <th>Greeting</th>
                                    <th>Color</th>
                                    <th>Image</th>
                                    <th>Price (LKR)</th>
                                    <th>Status</th>
                                    <th>Ordered At</th>
                                    <th>User</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php while($order = $custom_orders->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $order['order_id']; ?></td>
                                        <td><?php echo htmlspecialchars($order['flavor']); ?></td>
                                        <td><?php echo htmlspecialchars($order['greeting']); ?></td>
                                        <td>
                                            <span style="display:inline-block;width:20px;height:20px;border-radius:50%;background:<?php echo htmlspecialchars($order['greetColor']); ?>;border:1px solid #ccc;"></span>
                                            <?php echo htmlspecialchars($order['greetColor']); ?>
                                        </td>
                                        <td>
                                            <?php if (!empty($order['products_image'])): ?>
                                                <img src="../img/<?php echo htmlspecialchars($order['products_image']); ?>" alt="Cake Image" style="width:60px;height:60px;border-radius:8px;">
                                            <?php else: ?>
                                                <span class="text-muted">No image</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo number_format($order['total_amount'], 2); ?></td>
                                        <td><?php echo htmlspecialchars($order['status']); ?></td>
                                        <td><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></td>
                                        <td><?php echo htmlspecialchars($order['user_name'] ?? $order['email']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No Customize Cake orders yet.</p>
                    <?php endif; ?>
                </div>
            </div>

                
                 <!-- Contact Messages -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5>Contact Messages</h5>
                </div>
                <div class="card-body">
                    <?php if ($messages->num_rows > 0): ?>
                        <ul class="list-group">
                            <?php while($msg = $messages->fetch_assoc()): ?>
                                <li class="list-group-item">
                                    <strong><?php echo date('M d, Y H:i', strtotime($msg['created_at'])); ?>:</strong>
                                    <?php echo htmlspecialchars($msg['contact_message']); ?> </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php else: ?>
                        <p>No messages yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sales Report Section -->
            <div class="card mt-4">
    <div class="card-header">
        <h5>Sales Report</h5>
        <form id="salesReportForm" class="d-flex align-items-center" target="_blank" method="GET" action="download_sales_report.php">
            <select name="period" id="salesPeriod" class="form-select form-select-sm me-2" style="width:auto;">
                <option value="day">Day</option>
                <option value="week">Week</option>
                <option value="month" selected>Month</option>
            </select>
            <input type="date" name="date" id="salesDate" class="form-control form-control-sm me-2" style="width:auto;">
            <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-download"></i> Download</button>
        </form>
    </div>
    <div class="card-body" id="salesReportBody">
        <!-- Existing PHP summary here, but will be replaced by AJAX -->
        <?php
        // Total sales, average order value, and top-selling products
                    $total_sales = $conn->query("SELECT COALESCE(SUM(total_amount),0) as sum FROM orders WHERE status='Completed'")->fetch_assoc()['sum'] ?? 0;
                    $avg_order = $conn->query("SELECT COALESCE(AVG(total_amount),0) as avg FROM orders WHERE status='Completed'")->fetch_assoc()['avg'] ?? 0;
                    $top_products = $conn->query("SELECT products_name, COUNT(*) as sold FROM order_items JOIN products ON order_items.product_id = products.products_id GROUP BY products_name ORDER BY sold DESC LIMIT 5");
                    ?>
                    <p><strong>Total Sales (Completed Orders):</strong> LKR <?php echo number_format($total_sales, 2); ?></p>
                    <p><strong>Average Order Value:</strong> LKR <?php echo number_format($avg_order, 2); ?></p>
                    <h6>Top Selling Products:</h6>
                    <ul>
                        <?php while($row = $top_products->fetch_assoc()): ?>
                            <li><?php echo htmlspecialchars($row['products_name']); ?> (<?php echo $row['sold']; ?> sold)</li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>

            <!-- User Activity Report Section -->
    <div class="card mt-4">
                <div class="card-header">
                    <h5>User Activity Report</h5>
                    <form id="userActivityForm" class="d-flex align-items-center" target="_blank" method="GET" action="download_user_activity_report.php">
            <select name="period" id="userActivityPeriod" class="form-select form-select-sm me-2" style="width:auto;">
                <option value="day">Day</option>
                <option value="week">Week</option>
                <option value="month" selected>Month</option>
            </select>
            <input type="date" name="date" id="userActivityDate" class="form-control form-control-sm me-2" style="width:auto;">
            <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-download"></i> Download</button>
        </form>
                </div>
                <div class="card-body" id="userActivityBody">
                    <!-- Initial PHP summary here, but will be replaced by AJAX -->
                    <?php
                    // New users this month, active users (placed orders), and most active users
                    $new_users = $conn->query("SELECT COUNT(*) as count FROM users WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")->fetch_assoc()['count'] ?? 0;
                    $active_users = $conn->query("SELECT COUNT(DISTINCT user_id) as count FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetch_assoc()['count'] ?? 0;
                    $most_active = $conn->query("SELECT user_name, COUNT(*) as orders FROM users JOIN orders ON users.user_id = orders.user_id GROUP BY users.user_id ORDER BY orders DESC LIMIT 3");
                    ?>
                    <p><strong>New Users This Month:</strong> <?php echo $new_users; ?></p>
                    <p><strong>Active Users (Last 30 Days):</strong> <?php echo $active_users; ?></p>
                    <h6>Most Active Users:</h6>
                    <ul>
                        <?php while($row = $most_active->fetch_assoc()): ?>
                            <li><?php echo htmlspecialchars($row['user_name']); ?> (<?php echo $row['orders']; ?> orders)</li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>

            <!-- Performance Metrics Section -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5>Performance Metrics</h5>
                    <form id="performanceMetricsForm" class="d-flex align-items-center" target="_blank" method="GET" action="download_performance_metrics.php">
            <select name="period" id="performanceMetricsPeriod" class="form-select form-select-sm me-2" style="width:auto;">
                <option value="day">Day</option>
                <option value="week">Week</option>
                <option value="month" selected>Month</option>
            </select>
            <input type="date" name="date" id="performanceMetricsDate" class="form-control form-control-sm me-2" style="width:auto;">
            <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-download"></i> Download</button>
        </form>
                </div>
                <div class="card-body" id="performanceMetricsBody">
                    <!-- Initial PHP summary here, but will be replaced by AJAX -->
                    <?php
                    // Order completion rate, average delivery time, and cancelled orders
                    $total_orders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0;
                    $completed_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='Completed'")->fetch_assoc()['count'] ?? 0;
                    $cancelled_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='Cancelled'")->fetch_assoc()['count'] ?? 0;
                    $completion_rate = $total_orders > 0 ? round(($completed_orders / $total_orders) * 100, 2) : 0;
                    // Average delivery time (if you have delivery_date and created_at)
                    $avg_delivery = $conn->query("SELECT AVG(DATEDIFF(delivery_date, created_at)) as avg_days FROM orders WHERE delivery_date IS NOT NULL")->fetch_assoc()['avg_days'] ?? 0;
                    ?>
                    <p><strong>Order Completion Rate:</strong> <?php echo $completion_rate; ?>%</p>
                    <p><strong>Average Delivery Time:</strong> <?php echo round($avg_delivery, 2); ?> days</p>
                    <p><strong>Cancelled Orders:</strong> <?php echo $cancelled_orders; ?></p>
                </div>
            </div>


              </main>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const ctx = document.getElementById('salesChart').getContext('2d');
const salesChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($dates); ?>,
        datasets: [{
            label: 'Sales (LKR)',
            data: <?php echo json_encode($totals); ?>,
            borderColor: '#007bff',
            backgroundColor: 'rgba(0,123,255,0.1)',
            fill: true,
            tension: 0.3
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
        },
        scales: {
            x: { display: true, title: { display: false } },
            y: { display: true, title: { display: true, text: 'Sales (LKR)' } }
        }
    }
});

document.addEventListener('DOMContentLoaded', function() {
    // Sales Report (already present)
    const salesPeriod = document.getElementById('salesPeriod');
    const salesDate = document.getElementById('salesDate');
    const salesBody = document.getElementById('salesReportBody');
    function fetchSalesReport() {
        fetch(`fetch_sales_report.php?period=${salesPeriod.value}&date=${salesDate.value}`)
            .then(res => res.text())
            .then(html => { salesBody.innerHTML = html; });
    }
    salesPeriod.addEventListener('change', fetchSalesReport);
    salesDate.addEventListener('change', fetchSalesReport);

    // User Activity Report
    const userPeriod = document.getElementById('userActivityPeriod');
    const userDate = document.getElementById('userActivityDate');
    const userBody = document.getElementById('userActivityBody');
    function fetchUserActivityReport() {
        fetch(`fetch_user_activity_report.php?period=${userPeriod.value}&date=${userDate.value}`)
            .then(res => res.text())
            .then(html => { userBody.innerHTML = html; });
    }
    userPeriod.addEventListener('change', fetchUserActivityReport);
    userDate.addEventListener('change', fetchUserActivityReport);

    // Performance Metrics
    const perfPeriod = document.getElementById('performanceMetricsPeriod');
    const perfDate = document.getElementById('performanceMetricsDate');
    const perfBody = document.getElementById('performanceMetricsBody');
    function fetchPerformanceMetrics() {
        fetch(`fetch_performance_metrics.php?period=${perfPeriod.value}&date=${perfDate.value}`)
            .then(res => res.text())
            .then(html => { perfBody.innerHTML = html; });
    }
    perfPeriod.addEventListener('change', fetchPerformanceMetrics);
    perfDate.addEventListener('change', fetchPerformanceMetrics);
});
</script>
</body>
</html>
