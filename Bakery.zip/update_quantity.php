<?php
session_start();

if(isset($_POST['products_id']) && isset($_POST['product_quantity']) && isset($_SESSION['cart'])) {
    $product_id = $_POST['products_id'];
    $quantity = (int)$_POST['product_quantity'];
    
    if(isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['product_quantity'] = $quantity;
    }
    
    echo 'OK';
} else {
    echo 'Error';
}
?>