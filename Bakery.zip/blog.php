<?php session_start(); ?>
<?php
// Include database connection
include('server/connection.php');

// Get all blog posts
$blog_posts = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles.css">

    <style>
    .cover-image {
            position: relative;
            width: 100%;
            height: 400px; 
            overflow: hidden;
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .cover-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .titletext {
            color: #ffffff;
            position: absolute;
            top: 60%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 70px;
            font-weight: bold;
        }

        .blog-container {
          max-width: 1200px;
          display: flex;
          justify-content: center;
          align-items: center;
          margin: 0 auto; /* Center horizontally */
          flex-wrap: wrap;
          width: 100%;
          max-width: 1200px;
          grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
          gap: 20px;
          padding-top: 50px;
        }
        .blog-card {
          border-radius: 20px;
            width: 250px;
            height: 300px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            position: relative;
            font-family: 'Arial', sans-serif; 
            transition: all 0.3s ease;
            display: flexbox;

        }
        .card:hover .preview-text {
            white-space: normal; 
        }
        .blog-image {
          width: 100%; 
          display: block; 
           }
           .overlay {
            display: flex;
            text-align: center;
            position: absolute;
            bottom: 0; /* Aligns overlay to the bottom */
            background-color: rgba(71, 48, 4, 0.7);
            color: white;
            height: 40%;
            width: 100%; 
            padding: 10px; 
            transition: all 0.8s ease;
            }
        .preview-text {
            align-content: center;
            font-size: 14px;
            text-align: center;
            margin-right: 5px;
            max-width: 100%;
            max-height: 100%;
            overflow: hidden; 
            
            
            }
        
        .blog-card:hover .overlay {
            height: 95%;
        }


        .title {
            
            position: absolute;
            top: 15px;
            left: 15px; 
            font-weight: bold; 
            color: black;
            transition: opacity 0.3s ease;
            }
        .blog-card:hover .title{
            opacity: 0;
        }

    </style>
</head>
<body>
<!-- Header -->
<header>
  <nav class="navbar">
      <div class="logo">  
          <a href="home.html"> <img src="img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li><a href="home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="Products- cakes.php">Cake</a>
          <a href="Products- savory.php">Savory</a>
          <a href="gift.html">Giftbox</a>
          <a href="customize.php">Customize</a>
        </div>
      </li>            
      <li><a href="tutorial.php">Tutorials </a></li>
      <li><a href="blog.php">Blog </a></li>
      <li><a href="about.php">About Us </a></li>
      <li><a href="contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
    <a href="cart.php" class="cart-icon">
    <i class="fas fa-shopping-cart"></i>
    <span class="cart-quantity">
        <?php 
            if(isset($_SESSION['cart'])) {
                echo count($_SESSION['cart']); 
            } else {
                echo '0';
            }
        ?>
    </span>
</a>       
        <a href="account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>




        <!-- Blog Banner -->
        <div class="cover-image">
          <img src="img/b.jpg" alt="Cover Image">
          <div class="titletext">Blog
          </div>
        </div>
  
        <!-- Blog Section -->
<div class="blog-container">
    <?php while($post = $blog_posts->fetch_assoc()): ?>
    <a href="blog_post.php?id=<?php echo $post['blog_id']; ?>" style="text-decoration: none;">
        <div class="blog-card">
            <div class="blog-image">
                <img src="<?php echo $post['image_path']; ?>" alt="<?php echo htmlspecialchars($post['title']); ?>">
            </div>
            <div class="title"><?php echo htmlspecialchars($post['title']); ?></div>
            <div class="overlay">
                <p class="preview-text"><?php echo htmlspecialchars($post['preview_text']); ?></p>
            </div>
        </div>
    </a>
    <?php endwhile; ?>
</div>        
<?php include 'chatbot.php'; ?>

        <!-- Footer -->
        <footer>
          <div class="footer-links">
            <a href="refund.html">Refund Policy</a>
            <a href="term.html">Terms & Conditions</a>
            <a href="privacy.html">Privacy Policy</a>
          </div>
          <div class="footer-social">
            <a href="https://web.facebook.com/thebutterhedge/?_rdc=1&_rdr" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://www.instagram.com/_thebutterhedge_/?hl=en" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.tiktok.com/@thebutterhedgebakery" target="_blank"><i class="fab fa-tiktok"></i></a>
          </div>
          <p>Copyright &copy; 2024 The Butterhedge Bakery. Vystwyke road, Colombo, Sri Lanka, Tel: 072 404 0949</p>
        </footer>
      
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
 
</body>
</html>
