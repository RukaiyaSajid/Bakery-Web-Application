<?php
$servername = "localhost"; // or your database server address
$username = "root"; // your database username
$password = ""; // your database password
$dbname = "bakery_db"; // your database name

// Create connection
$conn = new mysqli("localhost", "root", "", "bakery_db");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
