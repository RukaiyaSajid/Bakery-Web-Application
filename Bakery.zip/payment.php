<?php
session_start();
require_once 'connection.php';

if (!isset($_GET['order_id'])) {
    $error = "No order ID provided.";
    header('Location: cart.php');
    exit;
}

$orderId = (int)$_GET['order_id'];

// Get order details
$stmt = $conn->prepare("SELECT o.*, od.* FROM orders o 
                       JOIN order_details od ON o.order_id = od.order_id
                       WHERE o.order_id = ?");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header('Location: cart.php');
    exit;
}

// Insert into order_details
$stmt2 = $conn->prepare("INSERT INTO order_details (order_id, first_name, last_name, country, address, apartment, town, postal_code, phone, order_date, pre_order_date, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt2->bind_param("isssssssssss", $order_id, $first_name, $last_name, $country, $address, $apartment, $town, $postal_code, $phone, $order_date, $pre_order_date, $notes);
$stmt2->execute();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Payment</title>
  <link rel="icon" href="img/favicon.ico">
  <link rel="stylesheet" href="styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap');

<style>
/* Payment Page Styles */
.payment-container {
    max-width: 800px;
    margin: 100px auto;
    padding: 30px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.payment-container h1 {
    color: #BA954D;
    margin-bottom: 20px;
    text-align: center;
}

.payment-methods {
    margin-top: 30px;
    padding: 20px;
    border: 1px solid #eee;
    border-radius: 8px;
}

.payment-methods h2 {
    color: #96783A;
    font-size: 1.5rem;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.form-group {
    margin: 15px 0;
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.form-group:hover {
    border-color: #BA954D;
    background-color: #f9f9f9;
}

.form-group input[type="radio"] {
    margin-right: 10px;
    accent-color: #BA954D;
}

.form-group label {
    font-size: 1.1rem;
    cursor: pointer;
}

.submit-btn {
    display: block;
    width: 100%;
    padding: 12px;
    margin-top: 20px;
    background-color: #BA954D;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 1.1rem;
    cursor: pointer;
    transition: background-color 0.3s;
}

.submit-btn:hover {
    background-color: #96783A;
}

.order-details {
    background-color: #f8f8f8;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 30px;
}

.order-details p {
    /* CardFields Section Styles */
#cardFields {
    background: #f4f1ea;
    border: 1px solid #e0d7c6;
    border-radius: 8px;
    padding: 20px 18px 10px 18px;
    margin-top: 18px;
    box-shadow: 0 2px 8px rgba(186, 149, 77, 0.07);
    transition: box-shadow 0.2s;
}

#cardFields .form-row {
    display: flex;
    flex-direction: column;
    margin-bottom: 14px;
}

#cardFields label {
    font-size: 1rem;
    color: #96783A;
    margin-bottom: 5px;
    font-weight: 500;
    letter-spacing: 0.5px;
}

#cardFields input[type="text"] {
    padding: 9px 12px;
    border: 1px solid #d2b97c;
    border-radius: 5px;
    font-size: 1rem;
    background: #fffdfa;
    color: #6d5c2c;
    transition: border-color 0.2s;
    outline: none;
}

#cardFields input[type="text"]:focus {
    border-color: #BA954D;
    background: #fffbe7;
}

@media (max-width: 600px) {
    #cardFields {
        padding: 12px 8px 6px 8px;
    }
    #cardFields .form-row {
        margin-bottom: 10px;
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .payment-container {
        margin: 80px 20px;
        padding: 20px;
    }
}  
}
</style>
</head>
<body>

  <div class="payment-methods">
    <h2>Select Payment Method</h2>
    <form id="paymentForm" action="process_payment.php" method="POST">
        <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
        
        <div class="form-group">
            <input type="radio" id="cod" name="payment_method" value="cod" checked>
            <label for="cod">Cash on Delivery</label>
        </div>
        
        <div class="form-group">
            <input type="radio" id="card" name="payment_method" value="card">
            <label for="card">Credit/Debit Card</label>
            
            <!-- Card payment fields (shown when card is selected) -->
            <div id="cardFields" style="display: none; margin-top: 15px;">
                <div class="form-row">
                    <label>Card Number</label>
                    <input type="text" maxlength="12" name="card_number" placeholder="1234 5678 9012 3456">
                </div>
                <div class="form-row">
                    <label>Expiry Date</label>
                    <input type="text" name="card_expiry" placeholder="MM/YY">
                </div>
                <div class="form-row">
                    <label>CVV</label>
                    <input type="text" maxlength="3" name="card_cvv" placeholder="123">
                </div>
            </div>
        </div>
        
        <button type="submit" class="submit-btn">Complete Payment</button>
    </form>
</div>    
  <script>
document.addEventListener('DOMContentLoaded', function() {
    // Show/hide card fields based on payment method selection
    document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
        radio.addEventListener('change', function() {
            const cardFields = document.getElementById('cardFields');
            cardFields.style.display = this.value === 'card' ? 'block' : 'none';
        });
    });
    
    // Handle form submission
    const paymentForm = document.getElementById('paymentForm');
    paymentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate payment method
        const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
        if (!paymentMethod) {
            alert('Please select a payment method');
            return;
        }
        
        // If card payment, validate card details
        if (paymentMethod.value === 'card') {
            const cardNumber = document.querySelector('input[name="card_number"]').value;
            const cardExpiry = document.querySelector('input[name="card_expiry"]').value;
            const cardCvv = document.querySelector('input[name="card_cvv"]').value;
            
            if (!cardNumber || !cardExpiry || !cardCvv) {
                alert('Please enter all card details');
                return;
            }
            
            // In a real implementation, you would:
            // 1. Tokenize the card with a payment gateway
            // 2. Process the payment
            // 3. Then submit the form
        }
        
        // Submit the form
        this.submit();
    });
});
</script> 

</body>
</html>
