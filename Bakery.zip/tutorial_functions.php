<?php
require_once 'server/connection.php';

function getUpcomingTutorials() {
    global $conn;
    
    $result = $conn->query("SELECT * FROM tutorials WHERE scheduled_time > NOW() OR is_live = 1 ORDER BY scheduled_time ASC");
    if (!$result) {
        die("Query failed: " . $conn->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getRecordedTutorials() {
    global $conn;
    
    $result = $conn->query("SELECT * FROM tutorials WHERE recording_path IS NOT NULL ORDER BY created_at DESC");
    if (!$result) {
        die("Query failed: " . $conn->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}
?>