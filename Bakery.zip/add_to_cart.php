<?php
session_start();
require_once 'includes/config.php'; // Make sure this file sets up $conn
require_once 'server/connection.php'; 
$response = ['success' => false, 'message' => '', 'cart_count' => 0, 'error' => ''];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $product_id = $input['product_id'] ?? null;
    $product_quantity = $input['quantity'] ?? 1;
	$kilogram = $input['kilogram'] ?? '';
	$customize_message = $input['customize_message'] ?? '';

    if ($product_id) {
        // Fetch product details from database
        $stmt = $conn->prepare("SELECT products_id, products_name, products_price, products_image FROM products WHERE products_id = ? AND status = 'active'");
        $stmt->bind_param('i', $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();

        if ($product) {
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }

            if (isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id]['product_quantity'] += $product_quantity;
                $_SESSION['cart'][$product_id]['kilogram'] = $kilogram;
                $_SESSION['cart'][$product_id]['customize_message'] = $customize_message;
                $response['message'] = 'Product quantity updated in cart';
            } else {
                $_SESSION['cart'][$product_id] = [
                    'products_id' => $product['products_id'],
                    'products_name' => $product['products_name'],
                    'products_price' => $product['products_price'],
                    'products_image' => $product['products_image'],
                    'product_quantity' => $product_quantity,
                    'kilogram' => $kilogram,
                    'customize_message' => $customize_message
                ];
                $response['message'] = 'Product added to cart';
            }
            
            $response['success'] = true;
            $response['cart_count'] = count($_SESSION['cart']);
        } else {
            $response['error'] = 'Product not found or inactive';
            $response['message'] = 'Product not found or inactive';
        }
    } else {
        $response['error'] = 'Invalid product';
        $response['message'] = 'Invalid product';
    }
} else {
    $response['error'] = 'Invalid request';
    $response['message'] = 'Invalid request';
}

error_log(print_r($_SESSION['cart'], true));

header('Content-Type: application/json');
echo json_encode($response);
?>