<?php
session_start();
include('../server/connection.php');

$id = $_GET['id'] ?? null;
if ($id) {
    $conn->query("DELETE FROM blog_posts WHERE blog_id=$id");
}
header("Location: admin_blog.php");
exit;