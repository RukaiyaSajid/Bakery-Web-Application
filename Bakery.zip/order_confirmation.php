<?php
session_start();
require_once 'connection.php';

if (!isset($_GET['order_id'])) {
    header('Location: cart.php');
    exit;
}

$orderId = (int)$_GET['order_id'];

// Get order details
$stmt = $conn->prepare("SELECT o.*, od.* FROM orders o 
                       JOIN order_details od ON o.order_id = od.order_id
                       WHERE o.order_id = ?");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if (!$order) {
    header('Location: cart.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="/Bakery/styles.css">

<style>
    /* Order Confirmation Styles */
.confirmation-container {
    max-width: 800px;
    margin: 100px auto;
    padding: 40px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.confirmation-container h1 {
    color: #BA954D;
    font-size: 2.2rem;
    margin-bottom: 20px;
}

.confirmation-container p {
    font-size: 1.2rem;
    color: #555;
    margin-bottom: 30px;
}

.order-summary {
    background-color: #f8f8f8;
    padding: 25px;
    border-radius: 8px;
    margin: 30px 0;
    text-align: left;
}

.order-summary h2 {
    color: #96783A;
    font-size: 1.5rem;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #ddd;
}

.order-summary p {
    font-size: 1.1rem;
    margin: 10px 0;
    color: #333;
}

.btn {
    display: inline-block;
    padding: 12px 30px;
    background-color: #BA954D;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 1.1rem;
    transition: background-color 0.3s;
    margin-top: 20px;
}

.btn:hover {
    background-color: #96783A;
    color: white;
}

/* Animation for confirmation checkmark */
.checkmark {
    width: 80px;
    height: 80px;
    margin: 0 auto 20px;
    border-radius: 50%;
    display: block;
    stroke-width: 5;
    stroke: #BA954D;
    stroke-miterlimit: 10;
    animation: fill 0.4s ease-in-out 0.4s forwards, scale 0.3s ease-in-out 0.9s both;
}

.checkmark-circle {
    stroke-dasharray: 166;
    stroke-dashoffset: 166;
    stroke-width: 5;
    stroke-miterlimit: 10;
    stroke: #BA954D;
    fill: none;
    animation: stroke 0.6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
}

.checkmark-check {
    transform-origin: 50% 50%;
    stroke-dasharray: 48;
    stroke-dashoffset: 48;
    animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards;
}

@keyframes stroke {
    100% {
        stroke-dashoffset: 0;
    }
}

@keyframes scale {
    0%, 100% {
        transform: none;
    }
    50% {
        transform: scale3d(1.1, 1.1, 1);
    }
}

@keyframes fill {
    100% {
        box-shadow: inset 0 0 0 100px rgba(186, 149, 77, 0.1);
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .confirmation-container {
        margin: 80px 20px;
        padding: 20px;
    }
    
    .confirmation-container h1 {
        font-size: 1.8rem;
    }
}
</style>
</head>
<body>
    <!-- Header -->
  <header>
  <nav class="navbar">
      <div class="logo">  
          <a href="/Bakery/home.php"> <img src="/Bakery/img/butterhedge.jpg" alt="logo Image"> </a>
         </div>  
    <ul class="nav-links">
      <li><a href="/Bakery/home.php">Home </a></li>
      <li class="active-link">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Products</a>
        <div class="dropdown">
          <a href="/Bakery/Products- cakes.php">Cake</a>
          <a href="/Bakery/Products- savory.php">Savory</a>
          <a href="/Bakery/gift.html">Giftbox</a>
          <a href="/Bakery/customize.html">Customize</a>
        </div>
      </li>            
      <li><a href="/Bakery/tutorial.php">Tutorials </a></li>
      <li><a href="/Bakery/blog.php">Blog </a></li>
      <li><a href="/Bakery/about.php">About Us </a></li>
      <li><a href="/Bakery/contact.php">Contact Us </a></li>
    </ul>
    <div class="icons">
      <a href="/Bakery/cart.php" class="cart-icon">
        <i class="fas fa-shopping-cart"></i>
        <span class="cart-quantity">0</span>
      </a>        
        <a href="/Bakery/account.php" class="account-icon"><i class="fas fa-user"></i></a>
        
      </div>
    </div>    
  </nav>
</header>  
    <div class="confirmation-container">
    <h1>Thank You for Your Order!</h1>
    <p>Your order #<?php echo htmlspecialchars($order['order_number']); ?> has been successfully processed.</p>
    
    <div class="order-summary">
        <h2>Order Summary</h2>
        <p>Total Amount: LKR <?php echo number_format($order['total_amount'], 2); ?></p>
        <p>Payment Method: <?php echo strtoupper($order['payment_method']); ?></p>
        <p>Status: <?php echo ucfirst($order['status']); ?></p>
    </div>
    
    <a href="/Bakery/home.php" class="btn">Continue Shopping</a>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // You can add any interactive elements or animations here
    
    // Example: Print order functionality
    const printBtn = document.getElementById('print-btn');
    if (printBtn) {
        printBtn.addEventListener('click', function() {
            window.print();
        });
    }
    
    // Example: Countdown timer for order processing
    const orderStatus = document.querySelector('.order-summary p:nth-child(4)').textContent;
    if (orderStatus.includes('processing')) {
        // You could add a countdown or status update timer here
        console.log('Order is processing...');
    }
    
    // Example: Add a nice checkmark animation
    const checkmark = document.createElement('div');
    checkmark.innerHTML = `
        <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
            <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
            <path class="checkmark-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
        </svg>
    `;
    document.querySelector('.confirmation-container').prepend(checkmark);
});
</script>
</body>
</html>